<?php

namespace Application\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

class ReparationController extends AbstractActionController
{
    public function pickerAction()
    {
        $colorMapper = $this->getServiceLocator()->get('color_mapper');

        $deviceUrl  = $this->params()->fromRoute('device');
        $brandUrl   = $this->params()->fromRoute('brand');
        $modelUrl   = $this->params()->fromRoute('model');
        $colorUrl   = $this->params()->fromRoute('color');
        $failureUrl = $this->params()->fromRoute('failure');
        $simplehtml = $this->params()->fromRoute('simplehtml');

        $device     = $this->deviceMapper->findByUrl($deviceUrl);
        $deviceLang = $this->deviceLangMapper->findByDeviceAndLang($device->getId(), $this->langId);

        if ($device) {
            $view = new ViewModel(array(
                'device'        => $deviceUrl,
                'deviceObj'     => $device,
                'brand'         => $brandUrl,
                'brandObj'      => null,
                'model'         => $modelUrl,
                'modelObj'      => null,
                'color'         => $colorUrl,
                'colorObj'      => null,
                'failure'       => $failureUrl,
                'failureObj'    => null,
            ));

            $brandView = $this->forward()->dispatch('Reparation', array(
                'action'      => 'selectRequestBrand',
                'device'      => $device,
                'deviceLang'  => $deviceLang,
                'focus'       => $brandUrl,
                'simplethtml' => $simplehtml,
            ));

            if (!$brandUrl && $simplehtml) {
                $brandView->setTerminal(true);
                return ($brandView);
            }

            $view->addChild($brandView, 'brands');

            if ($brandUrl) {

                $brand     = $this->brandMapper->findByUrlAndDeviceId($brandUrl, $device->getId());
                $brandLang = $this->brandLangMapper->findByBrandAndLang($brand->getId(), $this->langId);

                if ($brand && $brand->getDeviceId() == $device->getId()) {
                    $view->setVariable('brandObj', $brand);
                    $modelView = $this->forward()->dispatch('Reparation', array(
                        'action'     => 'selectRequestModel',
                        'device'     => $device,
                        'deviceLang' => $deviceLang,
                        'brand'      => $brand,
                        'brandLang'  => $brandLang,
                        'focus'      => $modelUrl,
                        'simplehtml' => $simplehtml,
                    ));

                    if (!$modelUrl && $simplehtml) {
                        $modelView->setTerminal(true);

                        return ($modelView);
                    }

                    $view->addChild($modelView, 'models');

                    if ($modelUrl) {

                        $model     = $this->modelMapper->findByUrlAndBrandId($modelUrl, $brand->getId());
                        $modelLang = $this->modelLangMapper->findByModelAndLang($model->getId(), $this->langId);

                        if ($model && $model->getBrandId() == $brand->getId()) {
                            $view->setVariable('modelObj', $model);
                            $colorTricks = $colorMapper->findByModelId($model->getId())->current();
                            $colorUrl    = $colorTricks->getUrl();
                            $colorView = $this->forward()->dispatch('Reparation', array(
                                'action'     => 'selectRequestColor',
                                'device'     => $device,
                                'deviceLang' => $deviceLang,
                                'brand'      => $brand,
                                'brandLang'  => $brandLang,
                                'model'      => $model,
                                'modelLang'  => $modelLang,
                                'focus'      => $colorUrl,
                                'simplehtml' => $simplehtml,
                            ));

                            if (!$colorUrl && $simplehtml) {
                                $colorView->setTerminal(true);

                                return ($colorView);
                            }

                            $view->addChild($colorView, 'colors');

                            if ($colorUrl) {
                                $color = $colorMapper->findByUrlAndModelId($colorUrl, $model->getId());
                                if ($color && $color->getModelId() == $model->getId()) {
                                    $view->setVariable('colorObj', $color);

                                    $failureView = $this->forward()->dispatch('Reparation', array(
                                        'action'     => 'selectRequestFailure',
                                        'device'     => $device,
                                        'deviceLang' => $deviceLang,
                                        'brand'      => $brand,
                                        'brandLang'  => $brandLang,
                                        'model'      => $model,
                                        'modelLang'  => $modelLang,
                                        'color'      => $color,
                                        'focus'      => $failureUrl,
                                        'simplehtml' => $simplehtml,
                                    ));

                                    if (!$failureUrl && $simplehtml) {
                                        $failureView->setTerminal(true);

                                        return ($failureView);
                                    }

                                    $view->addChild($failureView, 'failures');

                                    if ($failureUrl) {

                                        $failure     = $this->failureMapper->findByColorIdAndUrlAndActivated($color->getId(), $failureUrl);
                                        $failureLang = $this->failureLangMapper->findByFailureAndLang($failure->getId(), $this->langId);

                                        if ($failure && $failure->getColorId() == $color->getId()) {
                                            $view->setVariable('failureObj', $failure);
                                            $failure2View = $this->forward()->dispatch('Reparation', array(
                                                'action'     => 'selectRequestFailureMore',
                                                'device'     => $device,
                                                'deviceLang' => $deviceLang,
                                                'brand'      => $brand,
                                                'brandLang'  => $brandLang,
                                                'model'      => $model,
                                                'modelLang'  => $modelLang,
                                                'color'      => $color,
                                                'failure'    => $failure,
                                                'failureLang'=> $failureLang,
                                                'focus'      => $failureUrl,
                                                'simplehtml' => $simplehtml,
                                                'langId'     => $this->langId,
                                            ));

                                            if ($simplehtml) {
                                                $failure2View->setTerminal(true);

                                                return ($failure2View);
                                            }

                                            $view->addChild($failure2View, 'failures2');
                                        } else {
                                            return $this->notFoundAction();
                                        }
                                    }
                                } else {
                                    return $this->notFoundAction();
                                }
                            }
                        } else {
                            return $this->notFoundAction();
                        }
                    }
                } else {
                    return $this->notFoundAction();
                }
            }
        } else {
            return $this->notFoundAction();
        }

        return($view);
    }

    public function selectRequestBrandAction()
    {
        $focus      = $this->params()->fromRoute('focus');
        $simplehtml = $this->params()->fromRoute('simplehtml');
        $device     = $this->params()->fromRoute('device');
        $deviceLang = $this->deviceLangMapper->findByDeviceAndLang($device->getId(), $this->langId);
        $brandList  = $this->brandMapper->fetchByDeviceId($device->getId());

        return (array(
            'device'     => $device,
            'deviceLang' => $deviceLang,
            'brandList'  => $brandList,
            'focus'      => $focus,
            'simplehtml' => $simplehtml
        ));
    }

    public function selectRequestModelAction()
    {
        $focus       = $this->params()->fromRoute('focus');
        $simplehtml  = $this->params()->fromRoute('simplehtml');
        $device      = $this->params()->fromRoute('device');
        $brand       = $this->params()->fromRoute('brand');
        $brandLang   = $this->brandLangMapper->findByBrandAndLang($brand->getId(), $this->langId);
        $modelList   = $this->modelMapper->findByBrandId($brand->getId());
        return (array(
            'device'     => $device,
            'brand'      => $brand,
            'brandLang'  => $brandLang,
            'modelList'  => $modelList,
            'focus'      => $focus,
            'simplehtml' => $simplehtml));
    }

    public function selectRequestColorAction()
    {
        $focus       = $this->params()->fromRoute('focus');
        $simplehtml  = $this->params()->fromRoute('simplehtml');
        $device      = $this->params()->fromRoute('device');
        $brand       = $this->params()->fromRoute('brand');
        $model       = $this->params()->fromRoute('model');
        $modelLang   = $this->modelLangMapper->findByModelAndLang($model->getId(), $this->langId);
        $colorMapper = $this->getServiceLocator()->get('color_mapper');
        $colorList   = $colorMapper->findByModelId($model->getId());

        return (array(
            'device'     => $device,
            'brand'      => $brand,
            'model'      => $model,
            'modelLang'  => $modelLang,
            'colorList'  => $colorList,
            'focus'      => $focus,
            'simplehtml' => $simplehtml
        ));
    }

    public function selectRequestFailureAction()
    {
        $focus              = $this->params()->fromRoute('focus');
        $simplehtml         = $this->params()->fromRoute('simplehtml');
        $device             = $this->params()->fromRoute('device');
        $brand              = $this->params()->fromRoute('brand');
        $model              = $this->params()->fromRoute('model');
        $modelLang          = $this->modelLangMapper->findByModelAndLang($model->getId(), $this->langId);
        $color              = $this->params()->fromRoute('color');
        $failureList        = $this->failureMapper->findByColorIdAndActivated($color->getId());
        $failureAndLangList = array();
        foreach ($failureList as $index => $failure) {
            $failureLang = $this->failureLangMapper->findByFailureAndLang($failure->getId(), $this->langId); 
            $failureAndLangList[$index] = array(
                'failure'     => $failure,
                'failureLang' => $failureLang,
            );
        }
        $domiForm = $this->getServiceLocator()->get('domicile_mail_form');

        return (array(
            'device'             => $device,
            'domiForm'           => $domiForm,
            'brand'              => $brand,
            'model'              => $model,
            'modelLang'          => $modelLang,
            'color'              => $color,
            'failureAndLangList' => $failureAndLangList,
            'focus'              => $focus,
            'simplehtml'         => $simplehtml
        ));
    }

    public function selectRequestFailureMoreAction()
    {
        $focus       = $this->params()->fromRoute('focus');
        $simplehtml  = $this->params()->fromRoute('simplehtml');
        $device      = $this->params()->fromRoute('device');
        $brand       = $this->params()->fromRoute('brand');
        $model       = $this->params()->fromRoute('model');
        $color       = $this->params()->fromRoute('color');

        $failureList        = $this->failureMapper->findByColorIdAndActivated($color->getId());
        $failureAndLangList = array();
        
        foreach ($failureList as $index => $failure) {
            $failureLang = $this->failureLangMapper->findByFailureAndLang($failure->getId(), $this->langId); 
            $failureAndLangList[$index] = array(
                'failure'     => $failure,
                'failureLang' => $failureLang,
            );
        }
        $domiForm = $this->getServiceLocator()->get('domicile_mail_form');

        return (array(
            'device'             => $device,
            'domiForm'           => $domiForm,
            'brand'              => $brand,
            'model'              => $model,
            'color'              => $color,
            'failureAndLangList' => $failureAndLangList,
            'focus'              => $focus,
            'simplehtml'         => $simplehtml,
            'langId'             => $this->langId,
        ));
    }

    /**
     * Constructor to inject translator and lang in all actions.
     */
    protected $lang;
    protected $langId;
    protected $deviceMapper;
    protected $deviceLangMapper;   
    protected $brandMapper;
    protected $brandLangMapper;
    protected $modelMapper;
    protected $modelLangMapper;
    protected $failureMapper;
    protected $failureLangMapper;
    public function __construct(
        $lang = null,
        $langId = null,
        $deviceMapper = null,
        $deviceLangMapper = null,
        $brandMapper = null,
        $brandLangMapper = null,
        $modelMapper = null,
        $modelLangMapper = null,
        $failureMapper = null,
        $failureLangMapper = null
    )
    {

        if (!is_null($lang)) {
            $this->lang = $lang;
        }

        if (!is_null($langId)) {
            $this->langId = $langId;
        }

        if (!is_null($deviceMapper)) {
            $this->deviceMapper = $deviceMapper;
        }

        if (!is_null($deviceLangMapper)) {
            $this->deviceLangMapper = $deviceLangMapper;
        }

        if (!is_null($brandMapper)) {
            $this->brandMapper = $brandMapper;
        }

        if (!is_null($brandLangMapper)) {
            $this->brandLangMapper = $brandLangMapper;
        }

        if (!is_null($modelMapper)) {
            $this->modelMapper = $modelMapper;
        }

        if (!is_null($modelLangMapper)) {
            $this->modelLangMapper = $modelLangMapper;
        }

        if (!is_null($failureMapper)) {
            $this->failureMapper = $failureMapper;
        }

        if (!is_null($failureLangMapper)) {
            $this->failureLangMapper = $failureLangMapper;
        }
    }
}
