<?php

namespace Application\Controller;

use Application\Entity\Device;
use Application\Form\FailureSearchForm;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\JsonModel;
use Zend\View\Model\ViewModel;
use Zend\Mvc\I18n\Translator;

/**
 * IndexController.
 *
 * This file is the base controller
 *
 * @author       Alexandre Hermann <hermann.alexandre@ahwebdev.fr>
 */
class IndexController extends AbstractActionController
{
    /**
     * the index action.
     */
    public function indexAction()
    {
        $sl = $this->getServiceLocator();
        //fetch brand list
        $formSearchFailureSmartphone = $this->getFormDevice('reparation-smartphone');
        $formSearchFailureTablet = $this->getFormDevice('reparation-tablette');
        $formSearchFailureWatch = $this->getFormDevice('reparation-watch');

        //map
        $mapPoints = $sl->get('mappoint_mapper')->fetchAll();
        $mapPointsJson = json_encode($mapPoints->toArray());

        //sliders
        $sliders = $sl->get('slider_mapper')->fetchAll($this->lang);
        if (0 === $sliders->count()){
            $sliders = $sl->get('slider_mapper')->fetchAll($sl->get('Config')['translation']['defaultLanguage']);
        }

        //get all featured with 
        $featuredFailures = $sl->get('featured_failure_mapper')->fetchAll();
        $featuredFailures->buffer();
        $featuredFailuresWithLang = array();
        foreach ($featuredFailures as $index => $featured) {
            $failure     = $sl->get('failure_mapper')->findById($featured->getFailureId());
            $failureLang = $sl->get('failure_lang_mapper')->findByFailureAndLang($failure->getId(), $this->langId);
            $featured->setFailure($failure);
            $color  = $sl->get('color_mapper')->findById($failure->getColorId());
            $model  = $sl->get('model_mapper')->findById($color->getModelId());
            $brand  = $sl->get('brand_mapper')->findById($model->getBrandId());
            $device = $sl->get('device_mapper')->findById($brand->getDeviceId());
            $url    = $sl->get('failure_manager')->getFailureUrl(array(
                'lang'    => $this->lang,
                'device'  => $device,
                'brand'   => $brand,
                'model'   => $model,
                'failure' => $failure,
            ));
            $featured->setUrl($url);
            $featuredFailuresWithLang[$index] = array(
                "featured"     => $featured,
                "featuredLang" => $failureLang,
            );

        }

        return array(
            'formSearchFailureSmartphone' => $this->renderFormSearchFailure($formSearchFailureSmartphone),
            'formSearchFailureTablet' => $this->renderFormSearchFailure($formSearchFailureTablet),
            'formSearchFailureWatch' => $this->renderFormSearchFailure($formSearchFailureWatch),
            'mapPointsJson' => $mapPointsJson,
            'sliders' => $sliders,
            'featuredFailuresWithLang' => $featuredFailuresWithLang
        );
    }

    /**
     * Get a from from a device type.
     *
     * @param string $device
     *
     * @return FailureSearchForm
     */
    protected function getFormDevice($device)
    {
        $deviceServiceRef = str_replace('reparation-', '', $device);
        $form = $this->getServiceLocator()->get('search_failure_' . $deviceServiceRef . '_form');

        $action = $this->url()->fromRoute('application/failureAjaxSearch', array('device' => $device, 'lang' => $this->lang));
        // $action = explode("/", $action);
        // $action[1] = $this->lang;
        // $action = implode('/', $action);

        $form->setAttribute('action', $action);
        $datas = $this->getServiceLocator()->get('failure_manager')->getDataFromOptions(array(
            'device' => $device,
            'lang' => $this->lang
        ));

        $form->setOption('searchData', $datas);

        return $form;
    }

    /**
     * Render a search form.
     *
     * @param FailureSearchForm $form
     * @param array             $searchData
     *
     * @return type
     */
    protected function renderFormSearchFailure($form, array $searchData = null)
    {
        if (!$searchData) {
            $searchData = array(
                'failureUrl' => $this->url()->fromRoute('application/reparation', array(
                    'device' => $form->getDeviceUrl(),
                )),
            );
        }

        $formRender = new ViewModel(array(
            'form' => $form,
            'searchData' => $searchData,
            'buttonText' => $this->translator->translate('homepage_panel_button'),
        ));
        $formRender->setTemplate('application/index/form-search-failure');

        return $this->getServiceLocator()->get('viewrenderer')->render($formRender);
    }

    /**
     * Listen the ajax search failure form, construct the form
     * and return the new form and attached data in the json.
     *
     * @return JsonModel
     */
    public function ajaxFailureSearchAction()
    {
        $request = $this->getRequest();
        //only post on route
        if (!$request->isPost() || !$request->isXmlHttpRequest()) {
            return $this->notFoundAction();
        }
        $device = $this->getServiceLocator()->get('device_mapper')->findByUrl($this->params()->fromRoute('device'));
        if (!$device instanceof Device) {
            return $this->notFoundAction();
        }

        $form = $this->getFormDevice($device->getUrl());

        $form->setData($request->getPost());
        if ($form->isValid()) {
            $options = $form->getData();
            $options['device'] = $device->getUrl();
            $searchData = $this->getServiceLocator()->get('failure_manager')->getDataFromOptions($options);
            $form->setOption('searchData', $searchData);
        }

        return new JsonModel(array(
            'form' => $this->renderFormSearchFailure($form, $searchData),
        ));
    }

    public function boutiquesAction()
    {
        $mapPointsResult = $this->getServiceLocator()->get('mappoint_mapper')->fetchAll();
        $mapPointsResult->buffer();
        $mapPointsJson = json_encode($mapPointsResult->toArray());

        $mapPoints = array();
        foreach ($mapPointsResult as $point) {
            $mapPoints[] = $point;
        }
        return array(
            'mapPoints' => $mapPoints,
            'mapPointsJson' => $mapPointsJson,
        );
    }
	
	/**
	* Redirection to the external recrutement system	
	* Menu item action
	*/
	public function recrutementAction(){
		return $this->redirect()->toUrl('http://www.wefixrh.net/wordpress/');			
	}

    /**
     * the cgv action.
     */
    public function cgvAction()
    {
        
    }

    /**
     * The presentation action.
     */
    public function presentationAction()
    {
        
    }

    /**
     * the Faq action.
     */
    public function faqAction()
    {
        
    }

    /**
     * The information legal action.
     */
    public function legalAction()
    {
        
    }

    /**
     * The pro action.
     */
    public function proAction()
    {
        
    }

	
    /**
     * The contact action.
     *
     * @return array
     */
    public function contactAction()
    {
        $contactForm = $this->getServiceLocator()->get('contact_form');

        $request = $this->getRequest();

        $success = false;

        if ($request->isPost()) {
            $contactForm->setData($request->getPost());
            if ($contactForm->isValid()) {
                $success = 1;
                $mailer = $this->getServiceLocator()->get('mail_service');
                $message = $mailer->createHtmlMessage('contact@wefix.net', 'Contact WeFix', 'template/contact', $contactForm->getData());
                $mailer->send($message);
            } else {
                $success = 2;
            }
        }

        return(array('contactForm' => $contactForm, 'success' => $success));
    }

    /**
     * Constructor to inject translator and lang in all actions.
     */
    protected $translator;
    protected $lang;
    protected $langId;
    public function __construct(Translator $translator = null, $lang = null, $langId = null)
    {
        if (!is_null($translator)) {
            $this->translator = $translator;
        }

        if (!is_null($lang)) {
            $this->lang = $lang;
        }

        if (!is_null($langId)) {
            $this->langId = $langId;
        }
    }
}
