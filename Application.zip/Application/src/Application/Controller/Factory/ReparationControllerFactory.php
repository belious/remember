<?php

namespace Application\Controller\Factory;

use Zend\ServiceManager\FactoryInterface,
    Zend\ServiceManager\ServiceLocatorInterface,  
    Zend\ServiceManager\Exception\ServiceNotCreatedException,
    Application\Controller\ReparationController;

class ReparationControllerFactory implements FactoryInterface
{
    public function createService(ServiceLocatorInterface $serviceLocator)
    {
        $sm          = $serviceLocator->getServiceLocator();
        $routerMatch = $sm->get('router')->match($sm->get('request'));

        $promo    = $routerMatch->getParam("promo");



        $controller = new ReparationController(
            $promo
        );
        return $controller;
    }
}