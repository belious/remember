<?php

namespace Application\Controller\Factory;

use Zend\ServiceManager\FactoryInterface,
    Zend\ServiceManager\ServiceLocatorInterface,  
    Zend\ServiceManager\Exception\ServiceNotCreatedException,
    Application\Controller\IndexController,
    Zend\Mvc\I18n\Translator;

class IndexControllerFactory implements FactoryInterface
{
    public function createService(ServiceLocatorInterface $serviceLocator)
    {
        $sm = $serviceLocator->getServiceLocator();
        $routerMatch = $sm->get('router')->match($sm->get('request'));

        try {
            $translator = $sm->get('translator');
            $lang = $routerMatch->getParam("lang");

            if (!$lang){
                $browserLang = \Locale::acceptFromHttp($_SERVER['HTTP_ACCEPT_LANGUAGE']);
                $browserLang = substr($browserLang, 0,2);
                $config = $serviceLocator->getServiceLocator()->get('Config');
                if (!in_array($browserLang, $config['translation']['available'])) {
                    $lang = $config['translation']['defaultLanguage'];
                } else {
                    $lang = $browserLang;
                }
            }

            $langMapper = $sm->get('lang_mapper');
            $langId     = $langMapper->findByLang($lang)->getId();
            $translator->setLocale($langMapper->findByLang($lang)->getLocale());
        } catch (ServiceNotCreatedException $e) {
            $translator = null;
        } catch (ExtensionNotLoadedException $e) {
            $translator = null;
        }

        $controller = new IndexController($translator, $lang, $langId);
        return $controller;
    }
}