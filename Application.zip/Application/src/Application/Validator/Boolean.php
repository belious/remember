<?php

namespace Application\Validator;

use Zend\Validator\AbstractValidator;

class Boolean extends AbstractValidator
{
    const ERROR_NOT_BOOLEAN = 'notBoolean';

    protected $messageTemplates = array(
        self::ERROR_NOT_BOOLEAN => 'Not boolean',
    );

    public function isValid($value)
    {
        if ($value !== true && $value !== false) {
            $this->error(self::ERROR_NOT_BOOLEAN);

            return false;
        }

        return true;
    }
}
