<?php

namespace Application\Service;

use Zend\ServiceManager\ServiceLocatorInterface;

abstract class Order
{
    public static function priceFailure($failureLang)
    {
        return ($failureLang->getPrice());
    }

    public static function generate($orderId, $failureList = array(), $serviceLocator)
    {
        $brandMapper       = $serviceLocator->get('brand_mapper');
        $modelMapper       = $serviceLocator->get('model_mapper');
        $colorMapper       = $serviceLocator->get('color_mapper');
        $deviceMapper      = $serviceLocator->get('device_mapper');
        $deviceLangMapper  = $serviceLocator->get('device_lang_mapper');
        $failureLangMapper = $serviceLocator->get('failure_lang_mapper');
        $routerMatch       = $serviceLocator->get('router')->match($serviceLocator->get('request'));
        $lang              = $routerMatch->getParam("lang");
        $langMapper        = $serviceLocator->get('lang_mapper');
        $langId            = $langMapper->findByLang($lang)->getId();

        $bestFailure = null;

        foreach ($failureList as $failure) {
            if ($bestFailure == null || \Application\Service\Order::priceFailure($failureLangMapper->findByFailureAndLang($bestFailure->getId(), $langId)) < \Application\Service\Order::priceFailure($failureLangMapper->findByFailureAndLang($failure->getId(), $langId))) {
                $bestFailure = $failure;
            }
        }

        $computedList = array();

        foreach ($failureList as $failure) {
            $computedFailure = new \Application\Entity\OrderFailure();
            $computedFailure->setOrderId($orderId);
            $computedFailure->setName($failure->getName());
            $computedFailure->setFailureId($failure->getId());

            if ($failure->getId() == $bestFailure->getId()) {
                $computedFailure->setPrice(\Application\Service\Order::priceFailure(
                    $failureLangMapper->findByFailureAndLang($failure->getId(), $langId)
                ));
            } else {
                $computedFailure->setPrice(round(\Application\Service\Order::priceFailure(
                    $failureLangMapper->findByFailureAndLang($failure->getId(), $langId)
                ) / 2, 2));
            }

            $computedFailure->setOriginalPrice(\Application\Service\Order::priceFailure(
                $failureLangMapper->findByFailureAndLang($failure->getId(), $langId)
            ));

            $color      = $colorMapper->findById($failure->getColorId());
            $model      = $modelMapper->findById($color->getModelId());
            $brand      = $brandMapper->findById($model->getBrandId());
            $device     = $deviceMapper->findById($brand->getDeviceId());


            $computedFailure->setType($device->getDeviceType());
            $computedFailure->setBrand($brand->getName());
            $computedFailure->setModel($model->getName());
            $computedFailure->setColor($color->getName());

            if ($failure->getPictoId()) {
                $computedFailure->setPictoUrl($serviceLocator->get('Config')['static_url'].'/upload/picto-'.$failure->getPictoId().'.png');
            } else {
                $computedFailure->setPictoUrl('');
            }

            $computedList[] = $computedFailure;
        }

        return $computedList;
    }
}
