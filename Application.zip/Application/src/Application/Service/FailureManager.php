<?php

namespace Application\Service;

use Application\Entity\Device;
use Application\Mapper\Brand as BrandMapper;
use Application\Mapper\Device as DeviceMapper;
use Application\Mapper\Failure as FailureMapper;
use Application\Mapper\FailureLang as FailureLangMapper;
use Application\Mapper\Model as ModelMapper;
use Zend\View\Helper\Url;

/**
 * FailureManager.
 *
 * @author       Alexandre Hermann <hermann.alexandre@ahwebdev.fr>
 */
class FailureManager
{

    /**
     * The Brand Mapper.
     *
     * @var BrandMapper
     */
    protected $brandMapper;

    /**
     * The Device Mapper.
     *
     * @var DeviceMapper
     */
    protected $deviceMapper;

    /**
     * The Model Mapper.
     *
     * @var ModelMapper
     */
    protected $modelMapper;

    /**
     * The Failure Mapper.
     *
     * @var FailureMapper
     */
    protected $failureMapper;

    /**
     * The Failure Mapper.
     *
     * @var FailureMapper
     */
    protected $failureLangMapper;

    protected $lang;
    protected $langId;

    /**
     * The Url Helper.
     *
     * @var Url
     */
    protected $urlHelper;

    /**
     * Constructor.
     *
     * @param DeviceMapper $deviceMapper
     * @param BrandMapper  $brandMapper
     */
    public function __construct(Url $urlHelper, DeviceMapper $deviceMapper, BrandMapper $brandMapper, ModelMapper $modelMapper, FailureMapper $failureMapper, FailureLangMapper $failureLangMapper, $lang, $langId)
    {
        $this->deviceMapper      = $deviceMapper;
        $this->brandMapper       = $brandMapper;
        $this->modelMapper       = $modelMapper;
        $this->failureMapper     = $failureMapper;
        $this->failureLangMapper = $failureLangMapper;
        $this->lang              = $lang;
        $this->langId            = $langId;
        $this->urlHelper         = $urlHelper;
    }

    /**
     * Get the device from Url.
     *
     * @param int|string $device
     *
     * @return Device
     */
    public function getDevice($device)
    {
        if (is_string($device)) {
            return $this->deviceMapper->findByUrl($device);
        }

        return $this->deviceMapper->findById($device);
    }

    /**
     * Get the brands from urls.
     *
     * @param int|string $device
     *
     * @return bool|array
     */
    public function getBrandsFromDevice($device)
    {
        $deviceObj = $this->getDevice($device);
        if (!$deviceObj) {
            return false;
        }
        $brands = $this->brandMapper->fetchByDeviceId($deviceObj->getId());
        $brandsArray = array();
        foreach ($brands as $brand) {
            $brandsArray[$brand->getId()] = $brand;
        }

        return $brandsArray;
    }

    /**
     * Get models from brand.
     *
     * @param int $id
     */
    public function getModelsFromBrandId($id)
    {
        $models = $this->modelMapper->findByBrandId($id);
        $modelsArray = array();
        foreach ($models as $model) {
            $modelsArray[$model->getId()] = $model;
        }

        return $modelsArray;
    }

    /**
     * Get models from brand.
     *
     * @param int $id
     */
    public function getFailuresFromModelId($id)
    {
        $failures = $this->failureMapper->findByModelId($id);
        $failuresArray = array();
        foreach ($failures as $failure) {
            $failuresArray[$failure->getId()] = $failure;
        }

        return $failuresArray;
    }

    /**
     * Transform Array Results set to array.
     *
     * @param array $elems
     *
     * @return array
     */
    public function convertToFormFailureSelect($elems)
    {
        $list = array();
        if (!count($elems)) {
            return $list;
        }
        foreach ($elems as $elem) {
            $list[$elem->getId()] = $elem->getName();
        }

        return $list;
    }

    /**
     * Transform Array Results set to array.
     *
     * @param array $elems
     *
     * @return array
     */
    public function convertToFormSelect($elems)
    {
        $list = array();
        if (!count($elems)) {
            return $list;
        }
        foreach ($elems as $elem) {
            $list[$elem->getId()] = $elem->getName();
        }

        return $list;
    }

    /**
     * Transform Array Results set to array.
     *
     * @param array $elems
     *
     * @return array
     */
    public function convertToFailureSelectTranslated($elems)
    {
        $list = array();
        if (!count($elems)) {
            return $list;
        }
        foreach ($elems as $elem) {
            $elemId = $elem->getId();
            $elemLang = $this->failureLangMapper->findByFailureAndLang($elemId, $this->langId);
            $list[$elemId] = $elemLang->getName();
        }

        return $list;
    }

    /**
     * Get datas from options.
     *
     * @param array $options
     *
     * @return array
     */
    public function getDataFromOptions(array $options)
    {
        $defaults = array(
            // 'lang'    => null,
            'device'  => null,
            'brand'   => null,
            'model'   => null,
            'failure' => null,
        );

        $options = array_merge($defaults, $options);

        $data = array(
            'brands'   => array(),
            'models'   => array(),
            'failures' => array(),
        );
        if ($options['device']) {
            $data['brands'] = $this->getBrandsFromDevice($options['device']);
        }
        if ($options['brand']) {
            $data['models'] = $this->getModelsFromBrandId($options['brand']);
        }
        if ($options['model']) {
            $data['failures'] = $this->getFailuresFromModelId($options['model']);
        }

        // $data['lang'] = $this->lang;

        //define the url
        $data['failureUrl'] = $this->getFailureUrl($options, $data);

        return $data;
    }

    /**
     * Generate the url from options select, associated data.
     *
     * @param array $options
     * @param array $data
     *
     * @return string
     */
    public function getFailureUrl(array $options, array $data = array())
    {
        $routeName = 'application';
        if ($options['device']) {
            $options['device'] = is_string($options['device']) ? $options['device'] : $options['device']->getUrl();
            $routeName .= '/reparation';
            if ($options['brand']) {
                $options['brand'] = is_object($options['brand']) ? $options['brand']->getUrl() : $data['brands'][$options['brand']]->getUrl();
                $routeName .= '/brand';
                if ($options['model']) {
                    $options['model'] = is_object($options['model']) ? $options['model']->getUrl() : $data['models'][$options['model']]->getUrl();
                    $routeName .= '/model';
                    if ($options['failure']) {
                        $failureObj = is_object($options['failure']) ? $options['failure'] : $data['failures'][$options['failure']];
                        $options['failure'] = $failureObj->getUrl();
                        $options['color'] = $failureObj->getColorName();
                        $routeName .= '/color/failure';
                    }
                }
            }
        }
        $options['lang'] = $this->lang;

        if ($routeName == '') {
            return;
        }

        return $this->urlHelper->__invoke($routeName, $options);
    }

}
