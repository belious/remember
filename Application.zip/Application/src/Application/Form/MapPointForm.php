<?php

namespace Application\Form;

use Zend\Form\Form;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class MapPointForm extends Form implements InputFilterAwareInterface
{

    protected $inputFilter;

    public function __construct()
    {
        // we want to ignore the name passed
        parent::__construct('mappoint');

        $this->setAttributes(array(
            'method' => 'post',
        ));

        $this->add(array(
            'name' => 'id',
            'type' => 'Zend\Form\Element\Hidden',
            'attributes' => array(
                'value' => '0',
            ),
        ));

        $this->add(array(
            'name' => 'name',
            'type' => 'Zend\Form\Element\Text',
            'options' => array(
                'label' => 'Nom de la boutique',
            ),
        ));

        $this->add(array(
            'name' => 'address',
            'type' => 'Zend\Form\Element\Textarea',
            'options' => array(
                'label' => 'Adresse',
            ),
        ));

        $this->add(array(
            'name' => 'hours',
            'type' => 'Zend\Form\Element\Textarea',
            'options' => array(
                'label' => 'Horaires',
            ),
        ));

        $this->add(array(
            'name' => 'dateOpen',
            'type' => 'Zend\Form\Element\Text',
            'options' => array(
                'label' => 'Date d\'ouveture (aaaa-mm-jj hh:mm:ss)',
            ),
        ));

        $this->add(array(
            'name' => 'lat',
            'type' => 'Zend\Form\Element\Number',
            'options' => array(
                'label' => 'Latitude',
            ),
            'attributes' => array(
                'step' => 'any',
            ),
        ));

        $this->add(array(
            'name' => 'lng',
            'type' => 'Zend\Form\Element\Number',
            'options' => array(
                'label' => 'Longitude',
            ),
            'attributes' => array(
                'step' => 'any',
            ),
        ));
    }

    public function getInputFilter()
    {
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();
            $factory = new InputFactory();

            $inputFilter->add($factory->createInput(array(
                        'name' => 'id',
                        'required' => true,
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'address',
                        'required' => true,
                        'filters' => array(
                            array('name' => 'StringTrim'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'name',
                        'required' => true,
                        'filters' => array(
                            array('name' => 'StringTrim'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'hours',
                        'required' => true,
                        'filters' => array(
                            array('name' => 'StringTrim'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'lat',
                        'required' => true,
                        'validators' => array(
                            array(
                                'name' => 'Zend\I18n\Validator\IsFloat',
                                'options' => array(
                                    'locale' => 'en_US',
                                ),
                            ),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'lng',
                        'required' => true,
                        'validators' => array(
                            array(
                                'name' => 'Zend\I18n\Validator\IsFloat',
                                'options' => array(
                                    'locale' => 'en_US',
                                ),
                            ),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'dateOpen',
                        'required' => true,
            )));

            $this->inputFilter = $inputFilter;
        }

        return $this->inputFilter;
    }

    public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new \Exception('Not used');
    }

}
