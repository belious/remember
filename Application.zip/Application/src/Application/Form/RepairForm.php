<?php

namespace Application\Form;

use Zend\Form\Form;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class RepairForm extends Form implements InputFilterAwareInterface
{
    protected $inputFilter;

    public function __construct()
    {
        // we want to ignore the name passed
        parent::__construct('repair');

        $this->setAttributes(array(
            'method' => 'post',
        ));

        $this->add(array(
            'name' => 'id',
            'type' => 'Zend\Form\Element\Hidden',
            'attributes' => array(
                'value' => '0',
            ),
        ));

        $this->add(array(
            'name' => 'name',
            'type' => 'Zend\Form\Element\Text',
            'options' => array(
                'label' => 'Type de reparation',
            ),
            'attributes' => array(
                'placeholder' => 'Ecouteur',
            ),
        ));

        $this->add(array(
            'name' => 'type',
            'type' => 'Zend\Form\Element\Text',
            'options' => array(
                'label' => 'Type d\'appareil',
            ),
            'attributes' => array(
                'placeholder' => 'Smartphone',
            ),
        ));

        $this->add(array(
            'name' => 'brand',
            'type' => 'Zend\Form\Element\Text',
            'options' => array(
                'label' => 'Marque',
            ),
            'attributes' => array(
                'placeholder' => 'Apple',
            ),
        ));

        $this->add(array(
            'name' => 'model',
            'type' => 'Zend\Form\Element\Text',
            'options' => array(
                'label' => 'Modele',
            ),
            'attributes' => array(
                'placeholder' => 'IPhone 4',
            ),
        ));

        $this->add(array(
            'name' => 'color',
            'type' => 'Zend\Form\Element\Text',
            'options' => array(
                'label' => 'Couleur',
            ),
            'attributes' => array(
                'placeholder' => 'Noir',
            ),
        ));

        $this->add(array(
            'name' => 'price',
            'type' => 'Zend\Form\Element\Number',
            'options' => array(
                'label' => 'Prix TTC',
            ),
            'attributes' => array(
                'step' => 'any',
            ),
        ));

        $this->add(array(
            'name' => 'picto_url',
            'type' => 'Zend\Form\Element\Text',
            'options' => array(
                'label' => 'Url du picto',
            ),
            'attributes' => array(
                'placeholder' => '//resources/upload/picto-1.png',
            ),
        ));
    }

    public function getInputFilter()
    {
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();
            $factory = new InputFactory();

            $inputFilter->add($factory->createInput(array(
                        'name' => 'id',
                        'required' => true,
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'name',
                        'required' => true,
                        'filters' => array(
                            array('name' => 'StringTrim'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'brand',
                        'required' => true,
                        'filters' => array(
                            array('name' => 'StringTrim'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'model',
                        'required' => true,
                        'filters' => array(
                            array('name' => 'StringTrim'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'color',
                        'required' => true,
                        'filters' => array(
                            array('name' => 'StringTrim'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'type',
                        'required' => true,
                        'filters' => array(
                            array('name' => 'StringTrim'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'price',
                        'required' => true,
                        'validators' => array(
                            array(
                                'name' => 'Zend\I18n\Validator\IsFloat',
                                'options' => array(
                                    'locale' => 'en_US',
                                ),
                            ),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'picto_url',
                        'required' => true,
                        'filters' => array(
                            array('name' => 'StringTrim'),
                        ),
            )));

            $this->inputFilter = $inputFilter;
        }

        return $this->inputFilter;
    }

    public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new \Exception('Not used');
    }
}
