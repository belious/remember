<?php

namespace Application\Mapper;

use ZfcBase\Mapper\AbstractDbMapper;

class Lang extends AbstractDbMapper
{
    protected $tableName = 'lang';

    public function fetchAll()
    {
        $select = $this->getSelect();
        $entity = $this->select($select);
        $this->getEventManager()->trigger('fetchAll', $this, array());

        return $entity;
    }

    public function findByLang($lang)
    {
        $select = $this->getSelect();
        $select->where(array(
            'lang' => $lang,
        ));
        $entity = $this->select($select)->current();
        $this->getEventManager()->trigger('findByLang', $this, array('lang' => $lang));

        return $entity;
    }

    public function findById($id)
    {
        $select = $this->getSelect();
        $select->where(array(
            'id' => $id,
        ));
        $entity = $this->select($select)->current();
        $this->getEventManager()->trigger('findById', $this, array('id' => $id));

        return $entity;
    }
}
