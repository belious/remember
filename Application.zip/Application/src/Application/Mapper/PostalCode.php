<?php

namespace Application\Mapper;

use ZfcBase\Mapper\AbstractDbMapper;
use Zend\Stdlib\Hydrator\HydratorInterface;

class PostalCode extends AbstractDbMapper
{
    protected $tableName = 'postal_code';

    public function findById($id)
    {
        $select = $this->getSelect();

        $select->where(array('id' => $id));

        $entity = $this->select($select)->current();
        $this->getEventManager()->trigger('findById', $this, array('id' => $id));

        return $entity;
    }

    public function findByPostalCode($postalCode)
    {
        $select = $this->getSelect();

        $select->where(array('code' => $postalCode));

        $entity = $this->select($select)->current();
        $this->getEventManager()->trigger('findByPostalCode', $this, array('code' => $postalCode));

        return $entity;
    }

    public function fetchAll()
    {
        $select = $this->getSelect();
        $entity = $this->select($select);
        $this->getEventManager()->trigger('fetchAll', $this, array());

        return $entity;
    }

    public function getTableName()
    {
        return $this->tableName;
    }

    public function setTableName($tableName)
    {
        $this->tableName = $tableName;
    }

    public function insert($entity, $tableName = null, HydratorInterface $hydrator = null)
    {
        $result = parent::insert($entity, $tableName, $hydrator);
        $entity->setId($result->getGeneratedValue());

        return $result;
    }

    public function delete($entity, $tableName = null)
    {
        return parent::delete(array('id' => $entity->getId()), $tableName);
    }
}
