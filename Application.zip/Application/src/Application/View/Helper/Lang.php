<?php

namespace Application\View\Helper;

use Zend\View\Helper\AbstractHelper;

/**
 * Remove text between "()"
 */
class Lang extends AbstractHelper
{

    public function __invoke()
    {
        $event->getApplication()->getEventManager()->attach(MvcEvent::EVENT_DISPATCH,
            function($event){
                $localeTranslation = array(
                    'fr' => 'fr_FR',
                    'en' => 'en_US'
                );
                $lang = $event->getRouteMatch()->getParam('lang');
                $translator = $event->getApplication()->getServiceManager()->get('translator');
                $translator->setLocale($localeTranslation[$lang]);
                
                $viewModel = $event->getApplication()->getMvcEvent()->getViewModel();
                $viewModel->lang = $lang;
            }
        );
    }

}
