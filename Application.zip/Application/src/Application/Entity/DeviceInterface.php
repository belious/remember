<?php

namespace Application\Entity;

interface DeviceInterface
{
    public function getId();

    public function getImageUrl();

    public function getUrl();

    public function setId($id);

    public function setImageUrl($imageUrl);

    public function setUrl($url);
}
