<?php

namespace Application\Entity;

class FailureLang
{

    protected $failureId;
    protected $langId;
    protected $name;
    protected $price;
    protected $infos;
    protected $titre;
    protected $description;
    protected $moreInfoReplacement;

    public function getFailureId()
    {
        return $this->failureId;
    }

    public function getLangId()
    {
        return $this->langId;
    }

    public function getName()
    {
        return $this->name;
    }

    public function getPrice()
    {
        return $this->price;
    }

    public function getInfos()
    {
        return $this->infos;
    }

    public function getTitre()
    {
        return $this->titre;
    }

    public function getDescription()
    {
        return $this->description;
    }

    public function getMoreInfoReplacement()
    {
        return $this->moreInfoReplacement;
    }

    public function setFailureId($failureId)
    {
        $this->failureId = $failureId;

        return $this;
    }

    public function setLangId($langId)
    {
        $this->langId = $langId;

        return $this;
    }

    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    public function setPrice($price)
    {
        $this->price = $price;

        return $this;
    }

    public function setInfos($infos)
    {
        $this->infos = $infos;

        return $this;
    }

    public function setTitre($titre)
    {
        $this->titre = $titre;

        return $this;
    }

    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    public function setMoreInfoReplacement($moreInfoReplacement)
    {
        $this->moreInfoReplacement = $moreInfoReplacement;

        return $this;
    }
}
