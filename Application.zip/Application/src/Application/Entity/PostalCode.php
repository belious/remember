<?php

namespace Application\Entity;

class PostalCode implements PostalCodeInterface
{
    protected $id;
    protected $code;

    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    public function getId()
    {
        return $this->id;
    }

    public function setCode($code)
    {
        $this->code = $code;

        return $this;
    }

    public function getCode()
    {
        return $this->code;
    }
}
