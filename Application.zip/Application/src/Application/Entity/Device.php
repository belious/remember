<?php

namespace Application\Entity;

class Device implements DeviceInterface
{
    protected $id;
    protected $deviceType;
    protected $imageUrl;
    protected $url;

    public function getId()
    {
        return $this->id;
    }

    public function getDeviceType()
    {
        return $this->deviceType;
    }

    public function getImageUrl()
    {
        return $this->imageUrl;
    }

    public function getUrl()
    {
        return $this->url;
    }

    public function setId($id)
    {
        $this->id = $id;
    }

    public function setDeviceType($deviceType)
    {
        $this->deviceType = $deviceType;

        return $this;
    }

    public function setImageUrl($imageUrl)
    {
        $this->imageUrl = $imageUrl;
    }

    public function setUrl($url)
    {
        $this->url = $url;
    }

}
