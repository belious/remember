<?php

namespace Application\Entity;

class DeviceLang
{
    protected $langId;
    protected $deviceId;
    protected $name;
    protected $deviceType;
    protected $description;
    protected $topDesc;

    public function getLangId()
    {
        return $this->langId;
    }

    public function getDeviceId()
    {
        return $this->deviceId;
    }

    public function getName()
    {
        return $this->name;
    }

    public function getDeviceType()
    {
        return $this->deviceType;
    }

    public function getDescription()
    {
        return $this->description;
    }

    public function getTopDesc()
    {
        return $this->topDesc;
    }

    public function setLangId($langId)
    {
        $this->langId = $langId;
    }

    public function setDeviceId($deviceId)
    {
        $this->deviceId = $deviceId;
    }

    public function setName($name)
    {
        $this->name = $name;
    }

    public function setDeviceType($deviceType)
    {
        $this->deviceType = $deviceType;

        return $this;
    }

    public function setDescription($description)
    {
        $this->description = $description;
    }

    public function setTopDesc($topDesc)
    {
        $this->topDesc = $topDesc;

        return $this;
    }
}
