<?php

namespace Application\Entity;

class BrandLang
{
    protected $brandId;
    protected $langId;
    protected $titre;
    protected $description;
    protected $bottomDesc;
    protected $topDesc;

    public function getBrandId()
    {
        return $this->brandId;
    }

    public function getLangId()
    {
        return $this->langId;
    }

    public function getTitre()
    {
        return $this->titre;
    }

    public function getDescription()
    {
        return $this->description;
    }

    public function getBottomDesc()
    {
        return $this->bottomDesc;
    }

    public function getTopDesc()
    {
        return $this->topDesc;
    }

    public function setBrandId($brandId)
    {
        $this->brandId = $brandId;

        return $this;
    }

    public function setLangId($langId)
    {
        $this->langId = $langId;

        return $this;
    }

    public function setTitre($titre)
    {
        $this->titre = $titre;

        return $this;
    }

    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    public function setBottomDesc($bottomDesc)
    {
        $this->bottomDesc = $bottomDesc;

        return $this;
    }

    public function setTopDesc($topDesc)
    {
        $this->topDesc = $topDesc;

        return $this;
    }
}
