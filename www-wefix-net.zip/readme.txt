================================================
Bestandsinformatie:
================================================
host-domain-ext.cer  - Specifiek certificaat voor uw host (deze dient u te installeren)
Indien er meerdere bestanden aanwezig zijn dan adviseren we u om alle bestanden te installeren.

www-hieruwdomeinnaam-com_pkcs7-format.p7b
Wanneer u dit bestand ziet, kan deze in principe genegeerd worden als deze niet in de handleiding benoemd wordt. Dit is een certificaat store bestand. Het bestand maakt de installatie op verschillende server type eenvoudiger, bijvoorbeeld in een Microsoft omgeving.

================================================
File Information:
================================================
host-domain-ext.cer - Specific certificate for your host (this should be installed)
If there are two .cer files, you only need to install the www.hereyourname.cer file. If multiple certificates are present then it is a chained SSL Certificate which should be installed as well.

www-hereyourname-com_pkcs7-format.p7b
This is a certificate store file. This can basically be ignored if not appointed in the manual. The file makes the installation easier on different server types, such as a Microsoft environment.

================================================
File Information:
================================================
Le certificat sp�cifique host-domain-ext.cer pour votre host (ce dernier devrait �tre install�)
Si plusieurs fichiers sont pr�sents, nous recommandons que vous installez tous les fichiers.

www-votredomaine-com_pkcs7-format.p7b
Ceci est un fichier de stockage de certificat. Ceci peut basiquement �tre ignor� si non nomm� dans le manuel. Le fichier rend l'installation plus facile sur diff�rents types de serveur, tel qu'un environnement Microsoft. 
