<?php

namespace Application\Controller\Factory;

use Zend\ServiceManager\FactoryInterface,
    Zend\ServiceManager\ServiceLocatorInterface,  
    Zend\ServiceManager\Exception\ServiceNotCreatedException,
    Application\Controller\OrderController;

class OrderControllerFactory implements FactoryInterface
{
    public function createService(ServiceLocatorInterface $serviceLocator)
    {
        $sm          = $serviceLocator->getServiceLocator();
        $routerMatch = $sm->get('router')->match($sm->get('request'));

        $lang       = $routerMatch->getParam("lang");
        $langMapper = $sm->get('lang_mapper');
        $langId     = $langMapper->findByLang($lang)->getId();

        $token      = $routerMatch->getParam("token");
        $orderId    = $routerMatch->getParam("order_id");

        $orderMapper = $sm->get('order_mapper');


        $controller = new OrderController(
            $lang,
            $langId,
            $token,
            $orderId,
            $orderMapper
        );
        return $controller;
    }
}