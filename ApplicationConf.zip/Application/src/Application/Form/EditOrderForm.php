<?php

namespace Application\Form;

use Zend\Form\Form;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class EditOrderForm extends Form implements InputFilterAwareInterface
{
    protected $inputFilter;

    public function __construct()
    {
        // we want to ignore the name passed
        parent::__construct('search_order');

        $this->setAttributes(array(
            'method' => 'post',
        ));

        $this->add(array(
            'name' => 'day',
            'type' => 'Zend\Form\Element\Text',
            'options' => array(
                'label' => 'Jour de passage',
            ),
        ));

        $this->add(array(
            'name' => 'hour',
            'type' => 'Zend\Form\Element\Text',
            'options' => array(
                'label' => 'Heure de passage',
            ),
        ));

        $this->add(array(
            'name' => 'last_name',
            'type' => 'Zend\Form\Element\Text',
            'options' => array(
                'label' => 'Nom',
            ),
        ));

        $this->add(array(
            'name' => 'first_name',
            'type' => 'Zend\Form\Element\Text',
            'options' => array(
                'label' => 'Prénom',
            ),
        ));

        $this->add(array(
            'name' => 'address',
            'type' => 'Zend\Form\Element\Text',
            'options' => array(
                'label' => 'Adresse',
            ),
        ));

        $this->add(array(
            'name' => 'city',
            'type' => 'Zend\Form\Element\Text',
            'options' => array(
                'label' => 'Ville',
            ),
        ));

        $this->add(array(
            'name' => 'postal',
            'type' => 'Zend\Form\Element\Text',
            'options' => array(
                'label' => 'Code postal',
            ),
        ));

        $this->add(array(
            'name' => 'phone',
            'type' => 'Zend\Form\Element\Text',
            'options' => array(
                'label' => 'Téléphone',
            ),
        ));

        $this->add(array(
            'name' => 'mail',
            'type' => 'Zend\Form\Element\Email',
            'options' => array(
                'label' => 'Email',
            ),
        ));

        $this->add(array(
            'name' => 'comment',
            'type' => 'Zend\Form\Element\Textarea',
            'options' => array(
                'label' => 'Commentaire',
            ),
        ));

        $this->add(array(
            'name' => 'state',
            'type' => 'Zend\Form\Element\Select',
            'options' => array(
                'label' => 'Etat du client',
                'value_options' => array(
                    'A appeler' => 'À appeler',
                    'A mailer' => 'À mailer',
                    'A reparer' => 'À réparer',
                    'Doit payer' => 'Doit payer',
                    'A relancer' => 'À relancer',
                    'Presta OK' => 'Presta OK',
                    'nothing' => 'À jeter',
                ),
            ),
        ));
    }

    public function getInputFilter()
    {
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();
            $factory = new InputFactory();

            $inputFilter->add($factory->createInput(array(
                        'name' => 'day',
                        'required' => false,
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'hour',
                        'required' => false,
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'last_name',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'StringTrim'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'first_name',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'StringTrim'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'address',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'StringTrim'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'city',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'StringTrim'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'postal',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'StringTrim'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'phone',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'StringTrim'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'mail',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'StringTrim'),
                        ),
                        'validators' => array(
                            array(
                                'name' => 'Zend\Validator\EmailAddress',
                            ),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'comment',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'StringTrim'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'state',
                        'required' => true,
            )));

            $this->inputFilter = $inputFilter;
        }

        return $this->inputFilter;
    }

    public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new \Exception('Not used');
    }
}
