<?php

namespace Application\Form;

use Zend\Form\Form;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class PointRelaisForm extends Form implements InputFilterAwareInterface
{
    protected $inputFilter;

    public function __construct()
    {
        // we want to ignore the name passed
        parent::__construct('point_relais');

        $this->setAttributes(array(
            'method' => 'post',
        ));

        $this->add(array(
            'name' => 'point_relais',
            'type' => 'Zend\Form\Element\Text',
        ));
    }

    public function getInputFilter()
    {
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();
            $factory = new InputFactory();

            $inputFilter->add($factory->createInput(array(
                        'name' => 'point_relais',
                        'required' => true,
                        'filters' => array(
                            array('name' => 'StringTrim'),
                        ),
            )));

            $this->inputFilter = $inputFilter;
        }

        return $this->inputFilter;
    }

    public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new \Exception('Not used');
    }
}
