<?php

namespace Application\Entity;

class ModelLang
{
    protected $modelId;
    protected $langId;
    protected $titre;
    protected $description;
    protected $topDesc;
    protected $bottomDesc;

    public function getModelId()
    {
        return $this->modelId;
    }

    public function getLangId()
    {
        return $this->langId;
    }

    public function getTitre()
    {
        return $this->titre;
    }

    public function getDescription()
    {
        return $this->description;
    }

    public function getTopDesc()
    {
        return $this->topDesc;
    }

    public function getBottomDesc()
    {
        return $this->bottomDesc;
    }

    public function setModelId($modelId)
    {
        $this->modelId = $modelId;

        return $this;
    }

    public function setLangId($langId)
    {
        $this->langId = $langId;

        return $this;
    }

    public function setTitre($titre)
    {
        $this->titre = $titre;

        return $this;
    }

    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    public function setTopDesc($topDesc)
    {
        $this->topDesc = $topDesc;

        return $this;
    }

    public function setBottomDesc($bottomDesc)
    {
        $this->bottomDesc = $bottomDesc;

        return $this;
    }
}
