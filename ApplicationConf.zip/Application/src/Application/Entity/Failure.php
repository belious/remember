<?php

namespace Application\Entity;

class Failure
{

    protected $id;
    protected $colorId;

    /**
     * The color name
     * hydrated from color left joined data
     * otherwise is null.
     *
     * @var string
     */
    private $colorName;

    /**
     * The color name
     * hydrated from color left joined data
     * otherwise is null.
     *
     * @var string
     */
    private $modelName;
    protected $name;
    protected $imageUrl;
    protected $pictoId;
    protected $url;
    protected $disabled;
    protected $top;

    public function getId()
    {
        return $this->id;
    }

    public function getColorId()
    {
        return $this->colorId;
    }

    //HYDRATOR METHOD REQUIRED
    public function getColorName()
    {
        return $this->colorName;
    }

    //HYDRATOR METHOD REQUIRED
    public function getModelName()
    {
        return $this->modelName;
    }

    public function getName()
    {
        return $this->name;
    }

    public function getImageUrl()
    {
        return $this->imageUrl;
    }

    public function getPictoId()
    {
        return $this->pictoId;
    }

    public function getUrl()
    {
        return $this->url;
    }

    public function getDisabled()
    {
        return $this->disabled;
    }

    public function getTop()
    {
        return $this->top;
    }

    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    public function setColorId($colorId)
    {
        $this->colorId = $colorId;

        return $this;
    }

    public function setColorName($colorName)
    {
        $this->colorName = $colorName;

        return $this;
    }

    public function setModelName($modelName)
    {
        $this->modelName = $modelName;

        return $this;
    }

    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    public function setImageUrl($imageUrl)
    {
        $this->imageUrl = $imageUrl;

        return $this;
    }


    public function setPictoId($pictoId)
    {
        $this->pictoId = $pictoId;

        return $this;
    }

    public function setUrl($url)
    {
        $this->url = $url;

        return $this;
    }

    public function setDisabled($bool)
    {
        $this->disabled = $bool;

        return $this;
    }

    public function setTop($top)
    {
        $this->top = $top;

        return $this;
    }

}
