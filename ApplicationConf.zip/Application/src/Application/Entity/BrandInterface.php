<?php

namespace Application\Entity;

interface BrandInterface
{
    public function setId($id);

    public function getId();

    public function setName($name);

    public function getName();

    public function setUrl($url);

    public function getUrl();

    public function getDeviceId();

    public function setDeviceId($deviceId);

    public function setImageUrl($imageUrl);

    public function getImageUrl();

    public function setTop($top);

    public function getTop();
}
