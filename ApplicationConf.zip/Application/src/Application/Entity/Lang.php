<?php

namespace Application\Entity;

class Lang
{
    protected $id;
    protected $lang;
    protected $locale;

    public function getId()
    {
        return $this->id;
    }

    public function getLang()
    {
        return $this->lang;
    }

    public function getLocale()
    {
        return $this->locale;
    }

    public function setId($id)
    {
        $this->id = $id;
    }

    public function setLang($lang)
    {
        $this->lang = $lang;
    }

    public function setLocale($locale)
    {
        $this->locale = $locale;
    }

}
