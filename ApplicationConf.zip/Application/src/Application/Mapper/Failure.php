<?php

namespace Application\Mapper;

use Zend\Db\Sql\Predicate\Expression;
use Zend\Stdlib\Hydrator\HydratorInterface;
use ZfcBase\Mapper\AbstractDbMapper;

class Failure extends AbstractDbMapper
{

    protected $tableName = 'failure';

    public function fetchAll()
    {
        $select = $this->getSelect();
        $entity = $this->select($select);
        $this->getEventManager()->trigger('fetchAll', $this, array());

        return $entity;
    }

    public function findById($id)
    {
        $select = $this->getSelect();
        $select->where(array(
            'failure.id' => $id,
        ));
        $select->join('color', 'color.id = color_id', array('colorName' => 'url'));
        $select->join('model', 'model.id = color.model_id', array('modelName' => 'name'));

        $entity = $this->select($select)->current();
        $this->getEventManager()->trigger('findById', $this, array('id' => $id));

        return $entity;
    }

    public function findByUrl($url)
    {
        $select = $this->getSelect();
        $select->where(array(
            'url' => $url,
        ));
        $entity = $this->select($select)->current();
        $this->getEventManager()->trigger('findByUrl', $this, array('url' => $url));

        return $entity;
    }

    public function findByColorId($colorId)
    {
        $select = $this->getSelect();
        $select->where(array(
            'color_id' => $colorId,
        ));
        $select->order('top DESC');
        $entity = $this->select($select);
        $this->getEventManager()->trigger('findByColorId', $this, array('color_id' => $colorId));

        return $entity;
    }

    public function findByUrlAndColorId($url, $colorId)
    {
        $select = $this->getSelect();
        $select->where(array(
            'url' => $url,
            'color_id' => $colorId,
        ));
        $entity = $this->select($select)->current();
        $this->getEventManager()->trigger('findByUrlAndColorId', $this, array('url', $url, 'color_id' => $colorId));

        return $entity;
    }

    /**
     * Find by model id.
     *
     * @param int $id
     *
     * @return array
     */
    public function findByModelId($id)
    {
        $select = $this->getSelect();
        $select->join('color', 'color.id = color_id', array('colorName' => 'url'));
        $select->join('model', 'model.id = color.model_id', array());
        $select->order('name ASC');

        $select->where(array(
            //'model.id' => $id
            //This is a hack, we ar enot using colors, so we fetch color to get in memory
            //and fetch faillure directly by color_id instead of Join all colors
            'color_id = (SELECT id from color where model_id=' . $id . ' LIMIT 1)',
        ));

        $entity = $this->select($select);

        $this->getEventManager()->trigger('findByModelId', $this, array('id', $id));

        return $entity;
    }

    public function findByColorIdAndActivated($colorId)
    {
        $select = $this->getSelect();
        $select->where(array(
            'color_id' => $colorId,
            'disabled' => 0,
        ));
        $select->order('top DESC');
        $entity = $this->select($select);
        $this->getEventManager()->trigger('findByColorId', $this, array('color_id' => $colorId));

        return $entity;
    }

    public function findByColorIdAndUrlAndActivated($colorId, $url)
    {
        $select = $this->getSelect();
        $select->where(array(
            'color_id' => $colorId,
            'url' => $url,
            'disabled' => 0,
        ));
        $select->order('top DESC');
        $entity = $this->select($select)->current();
        $this->getEventManager()->trigger('findByColorId', $this, array('color_id' => $colorId));

        return $entity;
    }

    public function findByPictoId($pictoId)
    {
        $select = $this->getSelect();
        $select->where(array(
            'picto_id' => $pictoId,
        ));
        $entity = $this->select($select);
        $this->getEventManager()->trigger('findByPictoId', $this, array('picto_id' => $pictoId));

        return $entity;
    }

    public function fetchNext($top, $deviceId)
    {
        $select = $this->getSelect();
        $select->where(array(
            'color_id' => $deviceId,
        ));
        $select->where(new Expression('failure.top > ' . $top));
        $select->order('top ASC');
        $entity = $this->select($select);

        return $entity;
    }

    public function fetchPrevious($top, $deviceId)
    {
        $select = $this->getSelect();
        $select->where(array(
            'color_id' => $deviceId,
        ));
        $select->where(new Expression('failure.top < ' . $top));
        $select->order('top DESC');
        $entity = $this->select($select);

        return $entity;
    }

    public function findLast($deviceId)
    {
        $select = $this->getSelect();
        $select->where(array(
            'color_id' => $deviceId,
        ));
        $select->order('top ASC');
        $select->limit(1);
        $entity = $this->select($select)->current();

        return $entity;
    }

    public function addTopFrom($deviceId, $brand)
    {
        $this->massiveUpdate(array('top' => new Expression('top + 1')), array(new Expression('color_id = ' . $deviceId), new Expression('top > ' . $brand->getTop())));
    }

    public function downTopFrom($deviceId, $brand)
    {
        $this->massiveUpdate(array('top' => new Expression('top - 1')), array(new Expression('color_id = ' . $deviceId), new Expression('top < ' . $brand->getTop())));
    }

    public function massiveUpdate($set, $where)
    {
        $this->initialize();

        $tableName = $this->tableName;

        $sql = $this->getSql()->setTable($tableName);
        $update = $sql->update();

        $update->set($set)
                ->where($where);

        $statement = $sql->prepareStatementForSqlObject($update);

        $this->getEventManager()->trigger('massiveUpdate', $this, array('set' => $set, 'where' => $where));
        $run = $statement->execute();
        $this->getEventManager()->trigger('massiveUpdate.post', array('set' => $set, 'where' => $where));

        return $run;
    }

    public function getTableName()
    {
        return $this->tableName;
    }

    public function setTableName($tableName)
    {
        $this->tableName = $tableName;
    }

    public function insert($entity, $tableName = null, HydratorInterface $hydrator = null)
    {
        $result = parent::insert($entity, $tableName, $hydrator);
        $entity->setId($result->getGeneratedValue());

        return $result;
    }

    public function update($entity, $where = null, $tableName = null, HydratorInterface $hydrator = null)
    {
        if (!$where) {
            $where = 'id = ' . $entity->getId();
        }

        return parent::update($entity, $where, $tableName, $hydrator);
    }

    public function delete($entity, $tableName = null)
    {
        $where = 'id = ' . $entity->getId();

        return parent::delete($where, $tableName);
    }

    /**
     * Special fix for ColorName in model that should not be persisted in db.
     */
    protected function entityToArray($entity, HydratorInterface $hydrator = null)
    {
        $array = parent::entityToArray($entity, $hydrator);
        unset($array['color_name']);
        unset($array['model_name']);

        return $array;
    }

    public function fetchAllWithDetails()
    {
        $select = $this->getSelect();
        $select->join('color', 'color.id = color_id', array('colorName' => 'url'));
        $select->join('model', 'model.id = color.model_id', array('modelName' => 'name'));
        $entity = $this->select($select);
        $this->getEventManager()->trigger('fetchAllWithDetails', $this, array());

        return $entity;
    }

}
