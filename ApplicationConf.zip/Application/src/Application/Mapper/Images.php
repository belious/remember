<?php

namespace Application\Mapper;

use Zend\Stdlib\Hydrator\HydratorInterface;
use ZfcBase\Mapper\AbstractDbMapper;

class Images extends AbstractDbMapper
{

    protected $tableName = 'background_images';

    public function fetchAll()
    {
        $select = $this->getSelect();
        $entity = $this->select($select);
        $this->getEventManager()->trigger('fetchAll', $this, array());

        return $entity;
    }

    public function findById($id)
    {
        $select = $this->getSelect();
        $select->where(array(
            'id' => $id,
        ));
        $entity = $this->select($select)->current();
        $this->getEventManager()->trigger('findById', $this, array('id' => $id));

        return $entity;
    }

    /**
     * Find image by language
     *
     * @param $lang
     * @return object
     */
    public function findByLang($lang)
    {
        $select = $this->getSelect();
        $select->where(array(
            'lang' => $lang,
        ));
        $entity = $this->select($select)->current();
        $this->getEventManager()->trigger('findByLang', $this, array('lang' => $lang));

        return $entity;
    }

    public function insert($entity, $tableName = null, HydratorInterface $hydrator = null)
    {
        $result = parent::insert($entity, $tableName, $hydrator);
        $entity->setId($result->getGeneratedValue());

        return $result;
    }

    public function update($entity, $where = null, $tableName = null, HydratorInterface $hydrator = null)
    {
        if (!$where) {
            $where = 'id = ' . $entity->getId();
        }

        return parent::update($entity, $where, $tableName, $hydrator);
    }

    public function delete($entity, $tableName = null)
    {
        $where = 'id = ' . $entity->getId();

        return parent::delete($where, $tableName);
    }

    /**
     * Special fix for ColorName in model that should not be persisted in db.
     */
    protected function entityToArray($entity, HydratorInterface $hydrator = null)
    {
        $array = parent::entityToArray($entity, $hydrator);

        return $array;
    }

}
