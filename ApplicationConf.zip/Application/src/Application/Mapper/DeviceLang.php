<?php

namespace Application\Mapper;

use ZfcBase\Mapper\AbstractDbMapper;

class DeviceLang extends AbstractDbMapper
{
    protected $tableName = 'device_lang';

    public function fetchAll()
    {
        $select = $this->getSelect();
        $entity = $this->select($select);
        $this->getEventManager()->trigger('fetchAll', $this, array());

        return $entity;
    }

    public function fetchAllByLang($langId)
    {
        $select = $this->getSelect();
        $select->where(array(
            'lang_id' => $langId,
        ));
        $entity = $this->select($select);
        $this->getEventManager()->trigger('fetchAllByLang', $this, array(
            'lang_id' => $langId
        ));

        return $entity;
    }

    public function findByDeviceAndLang($deviceId, $langId)
    {
        $select = $this->getSelect();
        $select->where(array(
            'device_id' => $deviceId,
            'lang_id' => $langId,
        ));
        $entity = $this->select($select)->current();
        $this->getEventManager()->trigger('findByDeviceAndLang', $this, array(
            'device_id' => $deviceId,
            'lang_id' => $langId
        ));

        return $entity;
    }

    public function getTableName()
    {
        return $this->tableName;
    }

    public function setTableName($tableName)
    {
        $this->tableName = $tableName;
    }

    public function update($entity, $where = null, $tableName = null, HydratorInterface $hydrator = null)
    {
        if (!$where) {
            $where = array(
                'device_id' => $entity->getDeviceId(),
                'lang_id' => $entity->getLangId()
            );
        }

        return parent::update($entity, $where, $tableName, $hydrator);
    }
}
