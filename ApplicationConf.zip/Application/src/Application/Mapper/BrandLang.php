<?php

namespace Application\Mapper;

use ZfcBase\Mapper\AbstractDbMapper;
use Zend\Stdlib\Hydrator\HydratorInterface;

class BrandLang extends AbstractDbMapper
{
    protected $tableName = 'brand_lang';

    public function fetchAll()
    {
        $select = $this->getSelect();
        $entity = $this->select($select);
        $this->getEventManager()->trigger('fetchAll', $this, array());

        return $entity;
    }

    public function findByBrandAndLang($brandId, $langId)
    {
        $select = $this->getSelect();
        $select->where(array(
            'brand_id' => $brandId,
            'lang_id' => $langId,
        ));
        $entity = $this->select($select)->current();
        $this->getEventManager()->trigger('findByBrandAndLang', $this, array(
            'brand_id' => $brandId,
            'lang_id' => $langId
        ));

        return $entity;
    }

    public function getTableName()
    {
        return $this->tableName;
    }

    public function setTableName($tableName)
    {
        $this->tableName = $tableName;
    }

    public function insert($entity, $tableName = null, HydratorInterface $hydrator = null)
    {
        $result = parent::insert($entity, $tableName, $hydrator);

        return $result;
    }

    public function update($entity, $where = null, $tableName = null, HydratorInterface $hydrator = null)
    {
        if (!$where) {
            $where = array(
                'brand_id' => $entity->getBrandId(),
                'lang_id' => $entity->getLangId(),
            );
        }

        return parent::update($entity, $where, $tableName, $hydrator);
    }
}
