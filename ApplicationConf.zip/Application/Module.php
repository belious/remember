<?php

namespace Application;

use Application\Entity\Brand;
use Application\Entity\BrandLang;
use Application\Entity\Color;
use Application\Entity\Device;
use Application\Entity\DeviceLang;
use Application\Entity\Failure;
use Application\Entity\FailureLang;
use Application\Entity\FeaturedFailure;
use Application\Entity\Image;
use Application\Entity\Lang;
use Application\Entity\MapPoint;
use Application\Entity\Model;
use Application\Entity\ModelLang;
use Application\Entity\Order;
use Application\Entity\OrderFailure;
use Application\Entity\Picto;
use Application\Entity\PostalCode;
use Application\Entity\Slider;
use Application\Form\BrandForm;
use Application\Form\BrandLangForm;
use Application\Form\ColorForm;
use Application\Form\ContactForm;
use Application\Form\DeviceForm;
use Application\Form\DeviceLangForm;
use Application\Form\DomicileCallbackForm;
use Application\Form\DomicileMailForm;
use Application\Form\EditOrderForm;
use Application\Form\ExpressInfosForm;
use Application\Form\FailureForm;
use Application\Form\FailureLangForm;
use Application\Form\FailureSearchForm;
use Application\Form\FeaturedFailureForm;
use Application\Form\ImagesForm;
use Application\Form\MapPointForm;
use Application\Form\ModelForm;
use Application\Form\ModelLangForm;
use Application\Form\PictoForm;
use Application\Form\PointRelaisForm;
use Application\Form\PostalCodeForm;
use Application\Form\RepairForm;
use Application\Form\SearchOrderForm;
use Application\Form\ShippingForm;
use Application\Form\SliderForm;
use Application\Mapper\Brand as BrandMapper;
use Application\Mapper\BrandLang as BrandLangMapper;
use Application\Mapper\Color as ColorMapper;
use Application\Mapper\Device as DeviceMapper;
use Application\Mapper\DeviceLang as DeviceLangMapper;
use Application\Mapper\Failure as FailureMapper;
use Application\Mapper\FailureLang as FailureLangMapper;
use Application\Mapper\FeaturedFailure as FeaturedFailureMapper;
use Application\Mapper\Lang as LangMapper;
use Application\Mapper\MapPoint as MapPointMapper;
use Application\Mapper\Model as ModelMapper;
use Application\Mapper\ModelLang as ModelLangMapper;
use Application\Mapper\Order as OrderMapper;
use Application\Mapper\OrderFailure as OrderFailureMapper;
use Application\Mapper\Picto as PictoMapper;
use Application\Mapper\PostalCode as PostalCodeMapper;
use Application\Mapper\Slider as SliderMapper;
use Application\Mapper\Images as ImagesMapper;
use Application\Service\FailureManager;
use Locale;
use Zend\I18n\Translator\Translator;
use Zend\Mvc\MvcEvent;
use Zend\Mvc\ModuleRouteListener;
use Zend\Stdlib\Hydrator\ClassMethods;

class Module
{

    private $lang;

    public function onBootstrap(MvcEvent $event)
    {
        $event->getApplication()->getEventManager()->attach(MvcEvent::EVENT_DISPATCH,
            function($event){
				
                $config = $event->getApplication()->getServiceManager()->get('Config');
                $translationDictionnary = $config['translation']['dictionnary'];
                $lang = $event->getRouteMatch()->getParam('lang');

                $translator = $event->getApplication()->getServiceManager()->get('translator');
                if (!$lang){
                    $browserLang = \Locale::acceptFromHttp($_SERVER['HTTP_ACCEPT_LANGUAGE']);
                    $browserLang = substr($browserLang, 0, 2);
                    if (!in_array($browserLang, $config['translation']['available'])) {
                        $lang = $config['translation']['defaultLanguage'];
                    } else {
                        $lang = $browserLang;
                    }
                    $cookie = new \Zend\Http\Header\SetCookie('lang', $lang);
                    setcookie('lang', $lang);
                    $response = $event->getResponse()->getHeaders();
                    $response->addHeader($cookie);
                    $event->getRouteMatch()->setParam('lang', $lang);
                }

                $this->lang = $lang;
                /** @var Translator */
                $translator
                    ->setLocale($translationDictionnary[$lang])
                    ->setFallbackLocale($translationDictionnary[$config['translation']['defaultLanguage']]);
            }
        );
    }

    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }

    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
                ),
            ),
        );
    }
    

    public function getServiceConfig()
    {
        return array(
            'factories' => array(
                'picto_mapper' => function ($sm) {
                    $mapper = new PictoMapper();
                    $mapper->setDbAdapter($sm->get('Zend\Db\Adapter\Adapter'));

                    $mapper->setEntityPrototype(new Picto());
                    $mapper->setHydrator(new ClassMethods());

                    return $mapper;
                },
                'order_mapper' => function ($sm) {
                    $mapper = new OrderMapper();
                    $mapper->setDbAdapter($sm->get('Zend\Db\Adapter\Adapter'));

                    $mapper->setEntityPrototype(new Order());
                    $mapper->setHydrator(new ClassMethods());

                    return $mapper;
                },
                'order_failure_mapper' => function ($sm) {
                    $mapper = new OrderFailureMapper();
                    $mapper->setDbAdapter($sm->get('Zend\Db\Adapter\Adapter'));

                    $mapper->setEntityPrototype(new OrderFailure());
                    $mapper->setHydrator(new ClassMethods());

                    return $mapper;
                },
                'search_order_form' => function ($sm) {
                    $form = new SearchOrderForm();

                    return $form;
                },
                'express_infos_form' => function ($sm) {
                    $form = new ExpressInfosForm();
                    $form->setHydrator(new ClassMethods());

                    return $form;
                },
                'shipping_form' => function ($sm) {
                    $form = new ShippingForm();
                    $form->setHydrator(new ClassMethods());

                    return $form;
                },
                'point_relais_form' => function ($sm) {
                    $form = new PointRelaisForm();
                    $form->setHydrator(new ClassMethods());

                    return $form;
                },
                'domicile_mail_form' => function ($sm) {
                    $form = new DomicileMailForm();
                    $form->setHydrator(new ClassMethods());

                    return $form;
                },
                'domicile_callback_form' => function ($sm) {
                    $form = new DomicileCallbackForm();
                    $form->setHydrator(new ClassMethods());

                    return $form;
                },
                'edit_order_form' => function ($sm) {
                    $form = new EditOrderForm();
                    $form->setHydrator(new ClassMethods());

                    return $form;
                },
                'repair_form' => function ($sm) {
                    $form = new RepairForm();
                    $form->setHydrator(new ClassMethods());

                    return $form;
                },
                'contact_form' => function ($sm) {
                    $form = new ContactForm();

                    return $form;
                },
                'postal_code_form' => function ($sm) {
                    $form = new PostalCodeForm();

                    return $form;
                },
                'device_form' => function ($sm) {
                    $form = new DeviceForm();

                    return $form;
                },
                'device_lang_form' => function ($sm) {
                    $form = new DeviceLangForm();

                    return $form;
                },
                'brand_form' => function ($sm) {
                    $form = new BrandForm();

                    return $form;
                },
                'brand_lang_form' => function ($sm) {
                    $form = new BrandLangForm();

                    return $form;
                },
                'model_form' => function ($sm) {
                    $form = new ModelForm();

                    return $form;
                },
                'model_lang_form' => function ($sm) {
                    $form = new ModelLangForm();

                    return $form;
                },
                'color_form' => function ($sm) {
                    $form = new ColorForm();

                    return $form;
                },
                'failure_form' => function ($sm) {
                    $pictoMapper = $sm->get('picto_mapper');
                    $pictoList = $pictoMapper->fetchAll();
                    $form = new FailureForm($pictoList);

                    return $form;
                },
                'failure_lang_form' => function ($sm) {
                    $form = new FailureLangForm();

                    return $form;
                },
                'picto_form' => function ($sm) {
                    $form = new PictoForm();

                    return $form;
                },
                'device_mapper' => function ($sm) {
                    $mapper = new DeviceMapper();
                    $mapper->setDbAdapter($sm->get('Zend\Db\Adapter\Adapter'));

                    $mapper->setEntityPrototype(new Device());
                    $mapper->setHydrator(new ClassMethods());

                    return $mapper;
                },
                'device_lang_mapper' => function ($sm) {
                    $mapper = new DeviceLangMapper();
                    $mapper->setDbAdapter($sm->get('Zend\Db\Adapter\Adapter'));
                    
                    $mapper->setEntityPrototype(new DeviceLang());
                    $mapper->setHydrator(new ClassMethods());

                    return $mapper;
                },
                'brand_mapper' => function ($sm) {
                    $mapper = new BrandMapper();
                    $mapper->setDbAdapter($sm->get('Zend\Db\Adapter\Adapter'));

                    $mapper->setEntityPrototype(new Brand());
                    $mapper->setHydrator(new ClassMethods());

                    return $mapper;
                },
                'brand_lang_mapper' => function ($sm) {
                    $mapper = new BrandLangMapper();
                    $mapper->setDbAdapter($sm->get('Zend\Db\Adapter\Adapter'));

                    $mapper->setEntityPrototype(new BrandLang());
                    $mapper->setHydrator(new ClassMethods());

                    return $mapper;
                },
                'lang_mapper' => function ($sm) {
                    $mapper = new LangMapper();
                    $mapper->setDbAdapter($sm->get('Zend\Db\Adapter\Adapter'));

                    $mapper->setEntityPrototype(new Lang());
                    $mapper->setHydrator(new ClassMethods());

                    return $mapper;
                },
                'model_mapper' => function ($sm) {
                    $mapper = new ModelMapper();
                    $mapper->setDbAdapter($sm->get('Zend\Db\Adapter\Adapter'));

                    $mapper->setEntityPrototype(new Model());
                    $mapper->setHydrator(new ClassMethods());

                    return $mapper;
                },
                'model_lang_mapper' => function ($sm) {
                    $mapper = new ModelLangMapper();
                    $mapper->setDbAdapter($sm->get('Zend\Db\Adapter\Adapter'));

                    $mapper->setEntityPrototype(new ModelLang());
                    $mapper->setHydrator(new ClassMethods());

                    return $mapper;
                },
                'color_mapper' => function ($sm) {
                    $mapper = new ColorMapper();
                    $mapper->setDbAdapter($sm->get('Zend\Db\Adapter\Adapter'));

                    $mapper->setEntityPrototype(new Color());
                    $mapper->setHydrator(new ClassMethods());

                    return $mapper;
                },
                'failure_mapper' => function ($sm) {
                    $mapper = new FailureMapper();
                    $mapper->setDbAdapter($sm->get('Zend\Db\Adapter\Adapter'));

                    $mapper->setEntityPrototype(new Failure());
                    $mapper->setHydrator(new ClassMethods());

                    return $mapper;
                },
                'failure_lang_mapper' => function ($sm) {
                    $mapper = new FailureLangMapper();
                    $mapper->setDbAdapter($sm->get('Zend\Db\Adapter\Adapter'));

                    $mapper->setEntityPrototype(new FailureLang());
                    $mapper->setHydrator(new ClassMethods());

                    return $mapper;
                },
                'postal_code_mapper' => function ($sm) {
                    $mapper = new PostalCodeMapper();
                    $mapper->setDbAdapter($sm->get('Zend\Db\Adapter\Adapter'));

                    $mapper->setEntityPrototype(new PostalCode());
                    $mapper->setHydrator(new ClassMethods());

                    return $mapper;
                },
                'failure_manager' => function ($sm) {

                    $urlHelper = $sm->get('viewhelpermanager')->get('url');
                    $routerMatch = $sm->get('router')->match($sm->get('request'));
                    $lang = $routerMatch->getParam("lang");

                    if (!$lang){
                        $config = $sm->get('Config');
                        $browserLang = \Locale::acceptFromHttp($_SERVER['HTTP_ACCEPT_LANGUAGE']);
                        $browserLang = substr($browserLang, 0, 2);
                        if (!in_array($browserLang, $config['translation']['available'])) {
                            $lang = $config['translation']['defaultLanguage'];
                        } else {
                            $lang = $browserLang;
                        }
                    }

                    $langMapper = $sm->get('lang_mapper');
                    $langId = $langMapper->findByLang($lang)->getId();
                    return new FailureManager(
                            $urlHelper, $sm->get('device_mapper'),
                            $sm->get('brand_mapper'),
                            $sm->get('model_mapper'), 
                            $sm->get('failure_mapper'),
                            $sm->get('failure_lang_mapper'), 
                            $lang,
                            $langId
                    );
                },
                'search_failure_smartphone_form' => function ($sm) {
                    $form = new FailureSearchForm('reparation-smartphone', $sm->get('failure_manager'));
                    return $form;
                },
                'search_failure_tablette_form' => function ($sm) {
                    $form = new FailureSearchForm('reparation-tablette', $sm->get('failure_manager'));
                    return $form;
                },
                'search_failure_watch_form' => function ($sm) {
                    $form = new FailureSearchForm('reparation-watch', $sm->get('failure_manager'));
                    return $form;
                },
                'mappoint_mapper' => function ($sm) {
                    $mapper = new MapPointMapper();
                    $mapper->setDbAdapter($sm->get('Zend\Db\Adapter\Adapter'));

                    $mapper->setEntityPrototype(new MapPoint());
                    $mapper->setHydrator(new ClassMethods());

                    return $mapper;
                },
                'mappoint_form' => function ($sm) {
                    $form = new MapPointForm();
                    $form->setHydrator(new ClassMethods());
                    return $form;
                },
                'slider_mapper' => function ($sm) {
                    $mapper = new SliderMapper();
                    $mapper->setDbAdapter($sm->get('Zend\Db\Adapter\Adapter'));

                    $mapper->setEntityPrototype(new Slider());
                    $mapper->setHydrator(new ClassMethods());

                    return $mapper;
                },
                'slider_form' => function ($sm) {
                    $langMapper = $sm->get('Config');
                    $form = new SliderForm($langMapper['translation']['available']);
                    $form->setHydrator(new ClassMethods());
                    return $form;
                },
                'featured_failure_mapper' => function ($sm) {
                    $mapper = new FeaturedFailureMapper();
                    $mapper->setDbAdapter($sm->get('Zend\Db\Adapter\Adapter'));

                    $mapper->setEntityPrototype(new FeaturedFailure());
                    $mapper->setHydrator(new ClassMethods());

                    return $mapper;
                },
                'featured_failure_form' => function ($sm) {
                    $form = new FeaturedFailureForm();
                    $form->setHydrator(new ClassMethods());
                    return $form;
                },
                'images_mapper' => function ($sm) {
                    $mapper = new ImagesMapper();
                    $mapper->setDbAdapter($sm->get('Zend\Db\Adapter\Adapter'));

                    $mapper->setEntityPrototype(new Image());
                    $mapper->setHydrator(new ClassMethods());

                    return $mapper;
                },
                'images_form' => function ($sm) {
                    $langMapper = $sm->get('Config');
                    $form = new ImagesForm($langMapper['translation']['available']);
                    return $form;
                },
            )
        );
    }

}
