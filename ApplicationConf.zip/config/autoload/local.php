<?php

return array(
    'db' => array(
        'username' => __DB_USER__,
        'password' => __DB_PASS__,
    ),
);
