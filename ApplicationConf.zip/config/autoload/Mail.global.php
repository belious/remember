<?php

return array(
    'mailer' => array(
        'default_message' => array(
            'from' => array(
                'email' => 'contact@wefix.net',
                'name' => 'WeFix'
            ),
            'encoding' => 'utf-8',
        ),
        'smtp_options' => array(
            'name' => 'wefix.net',
            'host' => 'smtp.gmail.com',
            'port' => 465,
            'connection_class' => 'login',
            'connection_config' => array(
                'username' => 'contact@wefix.net',
                'password' => 'alloallo',
                'ssl' => 'ssl',
            ),
        ),
    ),
);
