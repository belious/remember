# Installation process

- Install composer (https://getcomposer.org/)
- Run : composer install
- Verify and edit all configuration files into the config/ dir
- Add config/apache2.conf to your apache2 (sites-enabled)
- Install Mysql database
- Import all sql files (into schema/) to your allosmartphone database
- Enjoy !