#----------------------------------------------------------------
#                      ADD WATCH CATEGORY
#----------------------------------------------------------------
INSERT INTO device(id, name, device_type, description, image_url, url, top_desc)
VALUES (null, 'Reparation Watch', 'Watch', '<p>Pour une r&eacute;paration de montres (iWatch...) b&eacute;n&eacute;ficiez des services de r&eacute;parateurs professionnels.&nbsp;</p>', '/static/img/watch.png', 'reparation-watch', '');

#----------------------------------------------------------------
#                      TABLE LANG
#----------------------------------------------------------------

DROP TABLE IF EXISTS lang;
CREATE TABLE lang
(
	id INTEGER PRIMARY KEY AUTO_INCREMENT,
	lang VARCHAR(2) NOT NULL,
	locale VARCHAR(5) NOT NULL
);

INSERT INTO lang (lang,locale)
VALUES ('fr','fr_FR');
INSERT INTO lang (lang,locale)
VALUES ('en','en_US');
INSERT INTO lang (lang,locale)
VALUES ('de','de_DE');
INSERT INTO lang (lang,locale)
VALUES ('nl','nl_NL');

#----------------------------------------------------------------
#                      DEVICE_LANG
#----------------------------------------------------------------

DROP TABLE IF EXISTS device_lang;
CREATE TABLE device_lang
(
	device_id INTEGER NOT NULL,
	lang_id INTEGER NOT NULL,
	name VARCHAR(255) NOT NULL,
 	device_type VARCHAR(255) NOT NULL,
	description VARCHAR(255) NOT NULL,
	top_desc TEXT NOT NULL,
	PRIMARY KEY (lang_id, device_id),
	FOREIGN KEY (device_id) REFERENCES device(id) ON DELETE CASCADE,
	FOREIGN KEY (lang_id) REFERENCES lang(id) ON DELETE CASCADE
);

DELIMITER $$
DROP PROCEDURE IF EXISTS populateDeviceLang$$
CREATE PROCEDURE populateDeviceLang()
BEGIN
    DECLARE i int DEFAULT 1;
    WHILE i < 5 DO
        INSERT INTO device_lang (device_id, lang_id, name, device_type, description, top_desc) SELECT id, i, name, device_type, description, top_desc FROM device;
        SET i = i + 1;
    END WHILE;
END$$
DELIMITER ;
CALL populateDeviceLang();
DROP PROCEDURE IF EXISTS populateDeviceLang;

ALTER TABLE device
DROP name, DROP description, DROP top_desc;

#----------------------------------------------------------------
#                      BRAND_LANG
#----------------------------------------------------------------

ALTER TABLE brand ENGINE = InnoDB;
DROP TABLE IF EXISTS brand_lang;
CREATE TABLE brand_lang
(
  brand_id int(10) UNSIGNED NOT NULL,
  lang_id INTEGER NOT NULL,
  titre VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  bottom_desc TEXT NOT NULL,
  top_desc TEXT NOT NULL,
  PRIMARY KEY (brand_id, lang_id),
  FOREIGN KEY (brand_id) REFERENCES brand(id) ON DELETE CASCADE,
  FOREIGN KEY (lang_id) REFERENCES lang(id) ON DELETE CASCADE
);

DELIMITER $$
DROP PROCEDURE IF EXISTS populateBrandLang$$
CREATE PROCEDURE populateBrandLang()
BEGIN
    DECLARE i INT DEFAULT 1;
    WHILE i < 5 DO
        INSERT INTO brand_lang (brand_id, lang_id, titre, description, bottom_desc, top_desc) SELECT id, i, titre, description, bottom_desc, top_desc FROM brand;
        SET i = i + 1;
    END WHILE;
END$$
DELIMITER ;
CALL populateBrandLang();
DROP PROCEDURE IF EXISTS populateBrandLang;

ALTER TABLE brand
DROP titre, DROP description, DROP bottom_desc, DROP top_desc;


#----------------------------------------------------------------
#                      MODEL_LANG
#----------------------------------------------------------------

ALTER TABLE model ENGINE = InnoDB;
DROP TABLE IF EXISTS model_lang;
CREATE TABLE model_lang
(
  model_id INT(11) NOT NULL,
  lang_id INTEGER NOT NULL,
  titre VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  top_desc TEXT NOT NULL,
  bottom_desc TEXT NOT NULL,
  PRIMARY KEY (model_id, lang_id),
  FOREIGN KEY (model_id) REFERENCES model(id) ON DELETE CASCADE,
  FOREIGN KEY (lang_id) REFERENCES lang(id) ON DELETE CASCADE
);

DELIMITER $$
DROP PROCEDURE IF EXISTS populateModelLang$$
CREATE PROCEDURE populateModelLang()
BEGIN
    DECLARE i INT DEFAULT 1;
    WHILE i < 5 DO
        INSERT INTO model_lang (model_id, lang_id, titre, description, top_desc, bottom_desc) SELECT id, i, titre, description, top_desc, bottom_desc FROM model;
        SET i = i + 1;
    END WHILE;
END$$
DELIMITER ;
CALL populateModelLang();
DROP PROCEDURE IF EXISTS populateModelLang;

ALTER TABLE model
DROP titre, DROP description, DROP bottom_desc, DROP top_desc;



#----------------------------------------------------------------
#                      FAILURE_LANG
#----------------------------------------------------------------

ALTER TABLE failure ENGINE = InnoDB;
DROP TABLE IF EXISTS failure_lang;
CREATE TABLE failure_lang
(
  failure_id INT(11) NOT NULL,
  lang_id INTEGER NOT NULL,
  name VARCHAR(255) NOT NULL,
  price FLOAT NOT NULL,
  infos TEXT NOT NULL,
  titre VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  more_info_replacement TEXT NOT NULL,
  PRIMARY KEY (failure_id, lang_id),
  FOREIGN KEY (failure_id) REFERENCES failure(id) ON DELETE CASCADE,
  FOREIGN KEY (lang_id) REFERENCES lang(id) ON DELETE CASCADE
);

DELIMITER $$
DROP PROCEDURE IF EXISTS populateFailureLang$$
CREATE PROCEDURE populateFailureLang()
BEGIN
    DECLARE i INT DEFAULT 1;
    WHILE i < 5 DO
        INSERT INTO failure_lang (failure_id, lang_id, name, price, infos, titre, description, more_info_replacement) SELECT id, i, name, price, infos, titre, description, more_info_replacement FROM failure;
        SET i = i + 1;
    END WHILE;
END$$
DELIMITER ;
CALL populateFailureLang();
DROP PROCEDURE IF EXISTS populateFailureLang;

ALTER TABLE failure
DROP price, DROP infos, DROP titre, DROP description, DROP more_info_replacement;