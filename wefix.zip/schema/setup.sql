-- phpMyAdmin SQL Dump
-- version 3.3.7deb7
-- http://www.phpmyadmin.net
--
-- Serveur: localhost
-- Généré le : Mar 27 Janvier 2015 à 11:47
-- Version du serveur: 5.5.38
-- Version de PHP: 5.4.35-1~dotdeb.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Base de données: `wefix`
--

-- --------------------------------------------------------

--
-- Structure de la table `featured`
--

CREATE TABLE IF NOT EXISTS `featured_failure` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `failure_id` int(11) NOT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Structure de la table `slider`
--

CREATE TABLE IF NOT EXISTS `slider` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `text` text NOT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Structure de la table `map_point`
--

CREATE TABLE IF NOT EXISTS `map_point` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `address` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `hours` varchar(255) NOT NULL,
  `date_open` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lat` float NOT NULL,
  `lng` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Structure de la table `brand`
--

CREATE TABLE IF NOT EXISTS `brand` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `titre` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `url` varchar(255) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `top` int(11) NOT NULL DEFAULT '0',
  `device_id` int(11) NOT NULL,
  `bottom_desc` text NOT NULL,
  `top_desc` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=74 ;

-- --------------------------------------------------------

--
-- Structure de la table `color`
--

CREATE TABLE IF NOT EXISTS `color` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=171 ;

-- --------------------------------------------------------

--
-- Structure de la table `device`
--

CREATE TABLE IF NOT EXISTS `device` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `device_type` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `image_url` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `top_desc` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Structure de la table `failure`
--

CREATE TABLE IF NOT EXISTS `failure` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `color_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` float NOT NULL,
  `infos` text NOT NULL,
  `reduction` int(11) NOT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `picto_id` int(11) NOT NULL,
  `url` varchar(255) DEFAULT NULL,
  `disabled` tinyint(1) NOT NULL,
  `titre` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `top` int(11) NOT NULL,
  `more_info_replacement` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=495 ;

-- --------------------------------------------------------

--
-- Structure de la table `landing`
--

CREATE TABLE IF NOT EXISTS `landing` (
  `nom` varchar(255) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `html1` text NOT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `sous_titre` varchar(255) NOT NULL,
  `vitre_tactile` tinyint(1) NOT NULL,
  `ecran_lcd` tinyint(1) NOT NULL,
  `bouton_home` tinyint(1) NOT NULL,
  `appareil_photo_avant` tinyint(1) NOT NULL,
  `appareil_photo` tinyint(1) NOT NULL,
  `vitre_arriere` tinyint(1) NOT NULL,
  `batterie` tinyint(1) NOT NULL,
  `connecteur_charge` tinyint(1) NOT NULL,
  `prise_casque` tinyint(1) NOT NULL,
  `bouton_on_off` tinyint(1) NOT NULL,
  `vibreur` tinyint(1) NOT NULL,
  `micro` tinyint(1) NOT NULL,
  `haut_parleur` tinyint(1) NOT NULL,
  `ecouteur_interne` tinyint(1) NOT NULL,
  `antenne` tinyint(1) NOT NULL,
  `wifi` tinyint(1) NOT NULL,
  `autre` tinyint(1) NOT NULL,
  `url` varchar(255) NOT NULL,
  `hublot_appareil_photo` tinyint(1) NOT NULL,
  `boutons_volume` tinyint(1) NOT NULL,
  `facade_arriere` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

-- --------------------------------------------------------

--
-- Structure de la table `model`
--

CREATE TABLE IF NOT EXISTS `model` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brand_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `titre` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `top` int(11) NOT NULL,
  `top_desc` text NOT NULL,
  `bottom_desc` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=137 ;

-- --------------------------------------------------------

--
-- Structure de la table `order`
--

CREATE TABLE IF NOT EXISTS `order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` varchar(8) NOT NULL,
  `day` varchar(255) DEFAULT NULL,
  `hour` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `postal` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `mail` varchar(255) DEFAULT NULL,
  `comment` text,
  `shipping` enum('nothing','Retour point relais','Retour domicile','Aller/Retour point relais','Aller/Retour domicile') NOT NULL DEFAULT 'nothing',
  `point_relais` varchar(255) DEFAULT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `state` enum('nothing','A appeler','A mailer','A reparer','Doit payer','A relancer','Presta OK') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2460 ;

-- --------------------------------------------------------

--
-- Structure de la table `order_failure`
--

CREATE TABLE IF NOT EXISTS `order_failure` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `failure_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` float NOT NULL,
  `original_price` float NOT NULL,
  `type` varchar(255) NOT NULL,
  `brand` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `color` varchar(255) NOT NULL,
  `picto_url` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1228 ;

-- --------------------------------------------------------

--
-- Structure de la table `phone_back`
--

CREATE TABLE IF NOT EXISTS `phone_back` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phone` varchar(255) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `state` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=233 ;

-- --------------------------------------------------------

--
-- Structure de la table `picto`
--

CREATE TABLE IF NOT EXISTS `picto` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

-- --------------------------------------------------------

--
-- Structure de la table `postal_code`
--

CREATE TABLE IF NOT EXISTS `postal_code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code_2` (`code`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=141 ;
