<?php

error_reporting(E_ALL & ~E_STRICT);
ini_set('display_errors', 1);

define('__DB_USER__', getenv('MYSQL_ENV_MYSQL_USER') ? getenv('MYSQL_ENV_MYSQL_USER') : 'wfadmin');
define('__DB_NAME__', getenv('MYSQL_ENV_MYSQL_DATABASE') ? getenv('MYSQL_ENV_MYSQL_DATABASE') : 'app');
define('__DB_PASS__', getenv('MYSQL_ENV_MYSQL_PASSWORD') ? getenv('MYSQL_ENV_MYSQL_PASSWORD') : 'wfadmin2K12');
define('__DB_HOST__', getenv('MYSQL_PORT_3306_TCP_ADDR') ? getenv('MYSQL_PORT_3306_TCP_ADDR') : 'localhost');
define('__DB_PORT__', getenv('MYSQL_PORT_3306_TCP_PORT') ? getenv('MYSQL_PORT_3306_TCP_PORT') : 3306);
define('__DEVMODE__', true);

// Include the Composer vendor autoload file
$loader = include __DIR__ . '/vendor/autoload.php';

// Check if zf2 is installed and ready to be used
if (!class_exists('Zend\Loader\AutoloaderFactory'))
    throw new RuntimeException('Unable to load zf2. Run `composer install` at the root path of the project.');
