<?php

namespace Application\Entity;

interface PostalCodeInterface
{
    public function setId($id);

    public function getId();

    public function setCode($code);

    public function getCode();
}
