<?php

namespace Application\Entity;

class Order
{
    protected $id;
    protected $token;
    protected $day;
    protected $hour;
    protected $lastName;
    protected $firstName;
    protected $address;
    protected $city;
    protected $postal;
    protected $phone;
    protected $mail;
    protected $comment;
    protected $shipping;
    protected $pointRelais;
    protected $dateCreated;
    protected $state;

    public function __construct()
    {
        $this->dateCreated = date('Y-m-d H:i:s');
    }

    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    public function getId()
    {
        return $this->id;
    }

    public function setToken($token)
    {
        $this->token = $token;

        return $this;
    }

    public function getToken()
    {
        return $this->token;
    }

    public function setDay($day)
    {
        $this->day = $day;

        return $this;
    }

    public function getDay()
    {
        return $this->day;
    }

    public function setHour($hour)
    {
        $this->hour = $hour;

        return $this;
    }

    public function getHour()
    {
        return $this->hour;
    }

    public function setLastName($lastName)
    {
        $this->lastName = $lastName;

        return $this;
    }

    public function getLastName()
    {
        return $this->lastName;
    }

    public function setFirstName($firstName)
    {
        $this->firstName = $firstName;

        return $this;
    }

    public function getFirstName()
    {
        return $this->firstName;
    }

    public function setAddress($address)
    {
        $this->address = $address;

        return $this;
    }

    public function getAddress()
    {
        return $this->address;
    }

    public function setCity($city)
    {
        $this->city = $city;

        return $this;
    }

    public function getCity()
    {
        return $this->city;
    }

    public function setPostal($postal)
    {
        $this->postal = $postal;

        return $this;
    }

    public function getPostal()
    {
        return $this->postal;
    }

    public function setPhone($phone)
    {
        $this->phone = $phone;

        return $this;
    }

    public function getPhone()
    {
        return $this->phone;
    }

    public function setMail($mail)
    {
        $this->mail = $mail;

        return $this;
    }

    public function getMail()
    {
        return $this->mail;
    }

    public function setComment($comment)
    {
        $this->comment = $comment;

        return $this;
    }

    public function getComment()
    {
        return $this->comment;
    }

    public function setShipping($shipping)
    {
        $this->shipping = $shipping;

        return $this;
    }

    public function getShipping()
    {
        return $this->shipping;
    }

    public function setPointRelais($pointRelais)
    {
        $this->pointRelais = $pointRelais;

        return $this;
    }

    public function getPointRelais()
    {
        return $this->pointRelais;
    }

    public function setDateCreated($dateCreated)
    {
        $this->dateCreated = $dateCreated;

        return $this;
    }

    public function getDateCreated()
    {
        return $this->dateCreated;
    }

    public function setState($state)
    {
        $this->state = $state;

        return $this;
    }

    public function getState()
    {
        return $this->state;
    }
}
