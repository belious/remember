<?php

namespace Application\Entity;

class FeaturedFailure
{

    /**
     * @var int
     */
    protected $id;

    /**
     * @var integer
     */
    protected $failureId;

    /**
     * @var string
     */
    protected $imageUrl;

    /**
     * Hydrated from custom mapper
     * 
     * 
     * @var Failure
     */
    private $failure;

    /**
     * Hydrated from custom mapper
     * 
     * 
     * @var Failure
     */
    private $url;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getImageUrl()
    {
        return $this->imageUrl;
    }

    /**
     * @return integer
     */
    public function getFailureId()
    {
        return $this->failureId;
    }

    /**
     * @param int $id
     *
     * @return \Application\Entity\FeaturedFailure
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * @param string $imageUrl
     *
     * @return \Application\Entity\FeaturedFailure
     */
    public function setImageUrl($imageUrl)
    {
        $this->imageUrl = $imageUrl;

        return $this;
    }

    /**
     * @param integer $failureId
     *
     * @return \Application\Entity\FeaturedFailure
     */
    public function setFailureId($failureId)
    {
        $this->failureId = $failureId;

        return $this;
    }

    /**
     * @param Failure $failure
     *
     * @return \Application\Entity\FeaturedFailure
     */
    public function setFailure($failure)
    {
        $this->failure = $failure;

        return $this;
    }

    /**
     *
     * @return \Application\Entity\Failure
     */
    public function getFailure()
    {
        return $this->failure;
    }

    /**
     * @param string $url
     *
     * @return \Application\Entity\FeaturedFailure
     */
    public function setUrl($url)
    {
        $this->url = $url;

        return $this;
    }

    /**
     *
     * @return string
     */
    public function getUrl()
    {
        return $this->url;
    }

}
