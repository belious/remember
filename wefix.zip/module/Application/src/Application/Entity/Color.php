<?php

namespace Application\Entity;

class Color
{
    protected $id;
    protected $modelId;
    protected $name;
    protected $imageUrl;
    protected $url;

    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    public function getId()
    {
        return $this->id;
    }

    public function setModelId($modelId)
    {
        $this->modelId = $modelId;

        return $this;
    }

    public function getModelId()
    {
        return $this->modelId;
    }

    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    public function getName()
    {
        return $this->name;
    }

    public function setImageUrl($imageUrl)
    {
        $this->imageUrl = $imageUrl;

        return $this;
    }

    public function getImageUrl()
    {
        return $this->imageUrl;
    }

    public function setUrl($url)
    {
        $this->url = $url;

        return $this;
    }

    public function getUrl()
    {
        return $this->url;
    }
}
