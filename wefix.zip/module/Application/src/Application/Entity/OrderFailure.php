<?php

namespace Application\Entity;

class OrderFailure
{
    protected $id;
    protected $orderId;
    protected $failureId;
    protected $name;
    protected $price;
    protected $originalPrice;
    protected $type;
    protected $brand;
    protected $model;
    protected $color;
    protected $pictoUrl;

    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    public function getId()
    {
        return $this->id;
    }

    public function setOrderId($orderId)
    {
        $this->orderId = $orderId;

        return $this;
    }

    public function getOrderId()
    {
        return $this->orderId;
    }

    public function setFailureId($failureId)
    {
        $this->failureId = $failureId;

        return $this;
    }

    public function getFailureId()
    {
        return $this->failureId;
    }

    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    public function getName()
    {
        return $this->name;
    }

    public function setPrice($price)
    {
        $this->price = $price;

        return $this;
    }

    public function getPrice()
    {
        return $this->price;
    }

    public function setOriginalPrice($originalPrice)
    {
        $this->originalPrice = $originalPrice;

        return $this;
    }

    public function getOriginalPrice()
    {
        return $this->originalPrice;
    }

    public function setType($type)
    {
        $this->type = $type;

        return $this;
    }

    public function getType()
    {
        return $this->type;
    }

    public function setBrand($brand)
    {
        $this->brand = $brand;

        return $this;
    }

    public function getBrand()
    {
        return $this->brand;
    }

    public function setModel($model)
    {
        $this->model = $model;

        return $this;
    }

    public function getModel()
    {
        return $this->model;
    }

    public function setColor($color)
    {
        $this->color = $color;

        return $this;
    }

    public function getColor()
    {
        return $this->color;
    }

    public function setPictoUrl($pictoUrl)
    {
        $this->pictoUrl = $pictoUrl;

        return $this;
    }

    public function getPictoUrl()
    {
        return $this->pictoUrl;
    }
}
