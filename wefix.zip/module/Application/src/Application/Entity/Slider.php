<?php

namespace Application\Entity;

class Slider
{
    /**
     * @var int
     */
    protected $id;

    /**
     * @var string
     */
    protected $imageUrl;

    /**
     * @var string
     */
    protected $text;

    /**
     * @var string
     */
    protected $lang;

    /**
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return string
     */
    public function getImageUrl()
    {
        return $this->imageUrl;
    }

    /**
     * @return string
     */
    public function getText()
    {
        return $this->text;
    }

    /**
     * @param int $id
     *
     * @return \Application\Entity\Slider
     */
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * @param string $imageUrl
     *
     * @return \Application\Entity\Slider
     */
    public function setImageUrl($imageUrl)
    {
        $this->imageUrl = $imageUrl;

        return $this;
    }

    /**
     * @param string $text
     *
     * @return \Application\Entity\Slider
     */
    public function setText($text)
    {
        $this->text = $text;

        return $this;
    }

    /**
     * @return string
     */
    public function getLang()
    {
        return $this->lang;
    }

    /**
     * @param string $lang
     * @return Slider
     */
    public function setLang($lang)
    {
        $this->lang = $lang;

        return $this;
    }
}
