<?php

namespace Application\Form;

use Zend\Form\Form;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class DeviceLangForm extends Form implements InputFilterAwareInterface
{
    protected $inputFilter;

    public function __construct()
    {
        // we want to ignore the name passed
        parent::__construct('device_lang');

        $this->setAttributes(array(
            'method' => 'post',
        ));

        $this->add(array(
            'name' => 'device_id',
            'type' => 'Zend\Form\Element\Hidden',
        ));

        $this->add(array(
            'name' => 'lang_id',
            'type' => 'Zend\Form\Element\Hidden',
        ));

        $this->add(array(
            'name' => 'name',
            'type' => 'Zend\Form\Element\Text',
            'options' => array(
                'label' => 'Nom',
            ),
        ));

        $this->add(array(
            'name' => 'device_type',
            'type' => 'Zend\Form\Element\Text',
            'options' => array(
                'label' => 'Nom court',
            ),
        ));

        $this->add(array(
            'name' => 'description',
            'type' => 'Zend\Form\Element\Textarea',
            'options' => array(
                'label' => 'Description (SEO)',
            ),
        ));

        $this->add(array(
            'name' => 'top_desc',
            'type' => 'Zend\Form\Element\Textarea',
            'options' => array(
                'label' => 'Contenu haut',
            ),
            'attributes' => array(
                'class' => 'htmlify',
                'style' => 'width:500px;height:200px;',
            ),
        ));
    }

    public function getInputFilter()
    {
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();
            $factory = new InputFactory();

            $inputFilter->add($factory->createInput(array(
                        'name' => 'device_id',
                        'required' => true,
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'lang_id',
                        'required' => true,
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'name',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'StringTrim'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'device_type',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'StringTrim'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'description',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'StringTrim'),
                        ),
            )));


            $inputFilter->add($factory->createInput(array(
                        'name' => 'top_desc',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'StringTrim'),
                        ),
            )));

            $this->inputFilter = $inputFilter;
        }

        return $this->inputFilter;
    }

    public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new \Exception('Not used');
    }
}
