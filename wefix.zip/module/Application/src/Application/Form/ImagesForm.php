<?php
namespace Application\Form;

use Zend\Form\Form;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class ImagesForm extends Form implements InputFilterAwareInterface
{
    protected $inputFilter;

    protected $langues;

    public function __construct($langues)
    {
        // we want to ignore the name passed
        parent::__construct('images_lang');
        foreach ($langues as $iKey => $langue) {
            $langues[$langue] = $langue;
            unset($langues[$iKey]);
        }
        $this->langues = $langues;
        $this->setAttributes([
            'method' => 'post',
            'class'  => 'form-vertical'
        ]);
        $this->add([
            'name' => 'id',
            'type' => 'Zend\Form\Element\Hidden',
        ]);
        $this->add([
            'name'    => 'name',
            'type'    => 'Zend\Form\Element\Text',
            'options' => [
                'label' => 'Nom',
                'class' => 'control-label',
            ],
        ]);
        $this->add([
            'name'    => 'image',
            'type'    => 'Zend\Form\Element\File',
            'options' => [
                'label'            => 'Image JPG',
                'label_attributes' => [
                    'class' => 'control-label',
                ],
            ],
        ]);
        $this->add([
            'name'    => 'lang',
            'type'    => 'Zend\Form\Element\Select',
            'options' => [
                'label'         => _('Lang'),
                'empty_option'  => '--',
                'value_options' => $this->langues,
                'class'         => 'control-label',
            ],
        ]);
//        var_dump($this->getInputFilter());
//        $this->setInputFilter($this->getInputFilter());

        return $this;
    }

    public function getInputFilter()
    {

        if (!$this->inputFilter) {

            $inputFilter = new InputFilter();
            $factory = new InputFactory();
            $inputFilter->add($factory->createInput([
                'name'     => 'name',
                'required' => true,
                'filters'  => [
                    ['name' => 'StringTrim'],
                ],
            ]));
            $inputFilter->add($factory->createInput([
                'name'     => 'image',
                'required' => true,
            ]));
            $inputFilter->add($factory->createInput([
                'name'     => 'name',
                'required' => false,
                'filters'  => [
                    ['name' => 'StringTrim'],
                ],
            ]));

            $this->inputFilter = $inputFilter;
        }

        return $this->inputFilter;
    }

    public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new \Exception('Not used');
    }
}
