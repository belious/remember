<?php

namespace Application\Form;

use Zend\Form\Form;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class DomicileMailForm extends Form implements InputFilterAwareInterface
{
    protected $inputFilter;

    public function __construct()
    {
        // we want to ignore the name passed
        parent::__construct('domicile_mail');

        $this->setAttributes(array(
            'method' => 'post',
        ));
        /*
          $this->add(array(
          'name' => 'day',
          'type'  => 'Zend\Form\Element\Date',
          'options' => array(
          'label' => 'Date *',
          ),
          'attributes' => array(
          'class' => 'dayMailForm'
          ),
          ));

          $this->add(array(
          'name'	=> 'hour',
          'type'	=> 'Zend\Form\Element\Select',
          'options' => array(
          'label' => 'Heure *',
          'value_options' => array(
          '8h' => '8h',
          '9h' => '9h',
          '10h' => '10h',
          '11h' => '11h',
          '12h' => '12h',
          '13h' => '13h',
          '14h' => '14h',
          '15h' => '15h',
          '16h' => '16h',
          '17h' => '17h',
          '18h' => '18h',
          '19h' => '19h',
          '20h' => '20h',
          ),
          ),
          ));
         */
        $this->add(array(
            'name' => 'last_name',
            'type' => 'Zend\Form\Element\Text',
            'options' => array(
                'label' => 'Nom *',
            ),
            'attributes' => array(
                'class' => 'last_nameMailForm',
            ),
        ));
        /*
          $this->add(array(
          'name'	=> 'first_name',
          'type'	=> 'Zend\Form\Element\Text',
          'options' => array(
          'label' => 'Prénom *',
          ),
          'attributes' => array(
          'class' => 'first_nameMailForm'
          ),
          ));

          $this->add(array(
          'name'	=> 'address',
          'type'	=> 'Zend\Form\Element\Text',
          'options' => array(
          'label' => 'Adresse *',
          'label_attributes' => array(
          'style' => 'display: block;width: 320px;margin-left: 16px;',
          ),
          ),
          'attributes' => array(
          'class' => 'addressMailForm',
          'style' => 'width:100%;',
          ),
          ));
         */

        $this->add(array(
            'name' => 'postal',
            'type' => 'Zend\Form\Element\Text',
            'options' => array(
                'label' => 'Code postal *',
            ),
            'attributes' => array(
                'class' => 'postalMailForm',
            ),
        ));
        /*
          $this->add(array(
          'name'	=> 'city',
          'type'	=> 'Zend\Form\Element\Text',
          'options' => array(
          'label' => 'Ville *',
          ),
          'attributes' => array(
          'class' => 'cityMailForm'
          ),
          ));
         */
        $this->add(array(
            'name' => 'phone',
            'type' => 'Zend\Form\Element\Text',
            'options' => array(
                'label' => 'Téléphone *',
            ),
            'attributes' => array(
                'class' => 'phoneMailForm',
            ),
        ));

        $this->add(array(
            'name' => 'mail',
            'type' => 'Zend\Form\Element\Email',
            'options' => array(
                'label' => 'Mail *',
            ),
            'attributes' => array(
                'class' => 'mailMailForm',
            ),
        ));

        $this->add(array(
            'name' => 'domicileMailForm',
            'type' => 'Zend\Form\Element\Submit',
            'attributes' => array(
                'value' => 'Valider',
                'class' => 'btn-orange',
                'style' => 'margin-top:15px;',
                'onclick' => 'checker=true;',
            ),
        ));
    }

    public function getInputFilter()
    {
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();
            $factory = new InputFactory();
            /*
              $inputFilter->add($factory->createInput(array(
              'name'     => 'day',
              'required' => true,
              )));

              $inputFilter->add($factory->createInput(array(
              'name'     => 'hour',
              'required' => true,
              )));
             */
            $inputFilter->add($factory->createInput(array(
                        'name' => 'last_name',
                        'required' => true,
                        'filters' => array(
                            array('name' => 'StringTrim'),
                        ),
            )));
            /*
              $inputFilter->add($factory->createInput(array(
              'name'     => 'first_name',
              'required' => true,
              'filters'  => array(
              array('name' => 'StringTrim'),
              ),
              )));
             */
            $inputFilter->add($factory->createInput(array(
                        'name' => 'postal',
                        'required' => true,
                        'filters' => array(
                            array('name' => 'StringTrim'),
                        ),
            )));
            /*
              $inputFilter->add($factory->createInput(array(
              'name'     => 'address',
              'required' => true,
              'filters'  => array(
              array('name' => 'StringTrim'),
              ),
              )));

              $inputFilter->add($factory->createInput(array(
              'name'     => 'city',
              'required' => true,
              'filters'  => array(
              array('name' => 'StringTrim'),
              ),
              )));
             */
            $inputFilter->add($factory->createInput(array(
                        'name' => 'phone',
                        'required' => true,
                        'filters' => array(
                            array('name' => 'StringTrim'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'mail',
                        'required' => true,
                        'filters' => array(
                            array('name' => 'StringTrim'),
                        ),
                        'validators' => array(
                            array(
                                'name' => 'Zend\Validator\EmailAddress',
                            ),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'domicileMailForm',
                        'required' => true,
            )));

            $this->inputFilter = $inputFilter;
        }

        return $this->inputFilter;
    }

    public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new \Exception('Not used');
    }
}
