<?php

namespace Application\Form;

use Application\Service\FailureManager;
use Zend\Db\Adapter\AdapterInterface;
use Zend\Form\Form;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

/**
 * FailureSearchForm.
 *
 * @author       Alexandre Hermann <hermann.alexandre@ahwebdev.fr>
 */
class FailureSearchForm extends Form implements InputFilterAwareInterface
{

    /**
     * @var InputFilterInterface
     */
    protected $inputFilter;

    /**
     * @var string
     */
    protected $deviceUrl;

    /**
     * @var FailureManager
     */
    protected $fm;

    /**
     * Constructor.
     *
     * @param string           $deviceUrl
     * @param AdapterInterface $fm
     */
    public function __construct($deviceUrl, FailureManager $fm)
    {
        parent::__construct('filter_search');

        $this->fm = $fm;
        $this->deviceUrl = $deviceUrl;

        $this->setOption('searchData', array(
            'device' => $this->deviceUrl,
            'brands' => null,
            'models' => null,
            'failures' => null,
        ));

        $this->setAttributes(array('method' => 'post'));

        $this
                ->add(array(
                    'name' => 'brand',
                    'type' => 'Zend\Form\Element\Select',
                    'options' => array(
                        'label' => _('homepage_failure-search-form_label1'),
                        'empty_option' => '--',
                    ),
                    'attributes' => array(
                        'class' => 'form-control input-sm',
                    ),
                ))
                ->add(array(
                    'name' => 'model',
                    'type' => 'Zend\Form\Element\Select',
                    'options' => array(
                        'label' => _('homepage_failure-search-form_label2'),
                        'empty_option' => '--',
                    ),
                    'attributes' => array(
                        'class' => 'form-control input-sm',
                    ),
                ))
                ->add(array(
                    'name' => 'failure',
                    'type' => 'Zend\Form\Element\Select',
                    'options' => array(
                        'label' => _('homepage_failure-search-form_label3'),
                        'empty_option' => '--',
                    ),
                    'attributes' => array(
                        'class' => 'form-control input-sm',
                    ),
                ))
        ;
    }

    /**
     * Get the input filter.
     *
     * @return InputFilterInterface
     */
    public function getInputFilter()
    {
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();
            $this->inputFilter = $inputFilter;

            $factory = new InputFactory();
            $this->inputFilter
                    ->add($factory->createInput(array(
                        'name' => 'brand',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'Int'),
                        ),
                    )))
                    ->add($factory->createInput(array(
                        'name' => 'model',
                        'required' => false, 'filters' => array(
                            array('name' => 'Int'),
                        ),
                    )))
                    ->add($factory->createInput(array(
                        'name' => 'failure',
                        'required' => false, 'filters' => array(
                            array('name' => 'Int'),
                        ),
                    )))
            ;
        }

        return $this->inputFilter;
    }

    /**
     * Set the input filter.
     *
     * @param InputFilterInterface $inputFilter
     */
    public function setInputFilter(InputFilterInterface $inputFilter)
    {
        $this->inputFilter = $inputFilter;

        return $this;
    }

    /**
     * Prepare the dynamic data.
     *
     * @return \Application\Form\FailureSearchForm
     */
    public function prepare()
    {
        if ($this->isPrepared) {
            return $this;
        }
        $this->setAttribute('id', 'filter_search_' . $this->deviceUrl);
        $this->setAttribute('class', 'filter_search filter_search_' . $this->deviceUrl);

        $searchData = $this->getOption('searchData');
        $this->get('brand')->setValueOptions($this->fm->convertToFormSelect($searchData['brands']));
        $this->get('model')->setValueOptions($this->fm->convertToFormSelect($searchData['models']));
        $this->get('failure')->setValueOptions($this->fm->convertToFailureSelectTranslated($searchData['failures']));

        return parent::prepare();
    }

    /**
     * Get the device url.
     *
     * @return string
     */
    public function getDeviceUrl()
    {
        return $this->deviceUrl;
    }

}
