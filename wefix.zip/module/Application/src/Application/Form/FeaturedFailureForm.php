<?php

namespace Application\Form;

use Zend\Form\Form;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class FeaturedFailureForm extends Form implements InputFilterAwareInterface
{

    protected $inputFilter;

    public function __construct()
    {
        // we want to ignore the name passed
        parent::__construct('featuredfailure');

        $this->setAttributes(array(
            'method' => 'post',
        ));

        $this->add(array(
            'name' => 'id',
            'type' => 'Zend\Form\Element\Hidden',
            'attributes' => array(
                'value' => '0',
            ),
        ));

        $this->add(array(
            'name' => 'failureId',
            'type' => 'Zend\Form\Element\Select',
            'options' => array(
                'label' => 'Panne',
                'empty_option' => '--',
            ),
        ));

        $this->add(array(
            'name' => 'picture',
            'type' => 'Zend\Form\Element\File',
            'options' => array(
                'label' => 'Image',
            ),
        ));
    }

    public function getInputFilter()
    {
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();
            $factory = new InputFactory();

            $inputFilter->add($factory->createInput(array(
                'name' => 'id',
                'required' => true,
            )));

            $inputFilter->add($factory->createInput(array(
                'name' => 'failure',
                'required' => false, 'filters' => array(
                    array('name' => 'Int'),
                ),
            )));

            $inputFilter->add($factory->createInput(array(
                'name' => 'picture',
                'required' => false,
            )));

            $this->inputFilter = $inputFilter;
        }

        return $this->inputFilter;
    }

    public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new \Exception('Not used');
    }

}
