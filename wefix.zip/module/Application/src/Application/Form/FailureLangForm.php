<?php

namespace Application\Form;

use Zend\Form\Form;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class FailureLangForm extends Form implements InputFilterAwareInterface
{
    protected $inputFilter;

    public function __construct()
    {
        // we want to ignore the name passed
        parent::__construct('color');

        $this->add(array(
            'name' => 'failure_id',
            'type' => 'Zend\Form\Element\Hidden',
        ));

        $this->add(array(
            'name' => 'lang_id',
            'type' => 'Zend\Form\Element\Hidden',
        ));

        $this->setAttributes(array(
            'method' => 'post',
        ));

        $this->add(array(
            'name' => 'name',
            'type' => 'Zend\Form\Element\Text',
            'options' => array(
                'label' => 'Nom',
            ),
        ));

        $this->add(array(
            'name' => 'price',
            'type' => 'Zend\Form\Element\Number',
            'options' => array(
                'label' => 'Prix TTC',
            ),
            'attributes' => array(
                'step' => 'any',
            ),
        ));

        $this->add(array(
            'name' => 'titre',
            'type' => 'Zend\Form\Element\Text',
            'options' => array(
                'label' => 'Titre (SEO)',
            ),
        ));

        $this->add(array(
            'name' => 'description',
            'type' => 'Zend\Form\Element\Textarea',
            'options' => array(
                'label' => 'Description (SEO)',
            ),
        ));

        $this->add(array(
            'name' => 'infos',
            'type' => 'Zend\Form\Element\Textarea',
            'options' => array(
                'label' => '+ infos',
            ),
        ));

        $this->add(array(
            'name' => 'more_info_replacement',
            'type' => 'Zend\Form\Element\Textarea',
            'options' => array(
                'label' => 'Texte de remplacement + d\'infos',
            ),
        ));
    }

    public function getInputFilter()
    {
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();
            $factory = new InputFactory();

            $inputFilter->add($factory->createInput(array(
                        'name' => 'failure_id',
                        'required' => true,
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'lang_id',
                        'required' => true,
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'name',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'StringTrim'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'price',
                        'required' => false,
                        'validators' => array(
                            array(
                                'name' => 'Zend\I18n\Validator\IsFloat',
                                'options' => array(
                                    'locale' => 'en_US',
                                ),
                            ),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'titre',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'StringTrim'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'description',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'StringTrim'),
                        ),
            )));


            $inputFilter->add($factory->createInput(array(
                        'name' => 'infos',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'StringTrim'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'more_info_replacement',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'StringTrim'),
                        ),
            )));

            $this->inputFilter = $inputFilter;
        }

        return $this->inputFilter;
    }

    public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new \Exception('Not used');
    }
}
