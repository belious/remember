<?php

namespace Application\Mapper;

use ZfcBase\Mapper\AbstractDbMapper;

class MapPoint extends AbstractDbMapper
{
    protected $tableName = 'map_point';

    public function fetchAll()
    {
        $select = $this->getSelect();
        $entity = $this->select($select);
        $this->getEventManager()->trigger('fetchAll', $this, array());

        return $entity;
    }

    public function findById($id)
    {
        $select = $this->getSelect();
        $select->where(array(
            'id' => $id,
        ));
        $entity = $this->select($select)->current();
        $this->getEventManager()->trigger('findById', $this, array('id' => $id));

        return $entity;
    }

    public function insert($entity, $tableName = null, HydratorInterface $hydrator = null)
    {
        $result = parent::insert($entity, $tableName, $hydrator);
        $entity->setId($result->getGeneratedValue());

        return $result;
    }

    public function update($entity, $where = null, $tableName = null, HydratorInterface $hydrator = null)
    {
        if (!$where) {
            $where = 'id = '.$entity->getId();
        }

        return parent::update($entity, $where, $tableName, $hydrator);
    }

    public function delete($entity, $tableName = null)
    {
        $where = 'id = '.$entity->getId();

        return parent::delete($where, $tableName);
    }
}
