<?php

namespace Application\Controller;

use Application\Entity\Order as Order2;
use Application\Service\Order;
use SoapFault;
use TCPDF;
use Zend\Math\Rand;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\Soap\Client;
use Zend\View\Model\ViewModel;


class OrderController extends AbstractActionController
{
    public function addAction()
    {
        $request            = $this->getRequest();
        $failureMapper      = $this->getServiceLocator()->get('failure_mapper');
        $orderFailureMapper = $this->getServiceLocator()->get('order_failure_mapper');

        if ($request->isPost()) {
            if (!empty($request->getPost()['failure'])) {
                $failureEntry = $request->getPost()['failure'];
                $failureList = array();

                foreach ($failureEntry as $failureId) {
                    $failureCheck = $failureMapper->findById($failureId);
                    if ($failureCheck && !$failureCheck->getDisabled()) {
                        $failureList[] = $failureCheck;
                    } else {
                        return $this->redirect()->toUrl($this->url()->fromRoute('application'));
                    }
                }

                $domiForm = $this->getServiceLocator()->get('domicile_mail_form');
                $order = new Order2();
                $order->setState('nothing');
                $order->setPostal('');
                $domiForm->bind($order);
                $domiForm->setData($request->getPost());
                $postalCode = false;
                if ($domiForm->isValid()) {
                    $postalMapper = $this->getServiceLocator()->get('postal_code_mapper');
                    $postalCode = $postalMapper->findByPostalCode($order->getPostal());
                    if ($postalCode) {
                        $order->setState('A mailer');
                    }
                }

                $order->setShipping('nothing');
                $order->setToken(str_replace('O', 'A', str_replace('0', '1', strtoupper(substr(md5(Rand::getBytes(32)), 0, 8)))));

                $this->orderMapper->insert($order);

                if ($postalCode) {
                    mail('serviceclients@wefix.net', 'nouveau client a mailer', 'Identifiant de la commande: '.$order->getId());
                }
                $computedFailure = Order::generate($order->getId(), $failureList, $this->getServiceLocator());
                foreach ($computedFailure as $orderFailure) {
                    $orderFailureMapper->insert($orderFailure);
                }

                return $this->redirect()->toUrl($this->url()->fromRoute('application/process', array('lang' => $this->lang, 'order_id' => $order->getId(), 'token' => $order->getToken())));
            }
        }

        return $this->redirect()->toUrl($this->url()->fromRoute('application'));
    }

    public function be2billFormAction()
    {
    }

    public function processAction()
    {

        $orderFailureMapper = $this->getServiceLocator()->get('order_failure_mapper');
        $postalMapper       = $this->getServiceLocator()->get('postal_code_mapper');
        $order              = $this->orderMapper->findById($this->orderId);

        if ($order && $order->getToken() == $this->token) {
            $postalCode   = $postalMapper->findByPostalCode($order->getPostal());
            $orderFailure = $orderFailureMapper->findByOrderId($order->getId());


            switch ($order->getState()) {
                case 'A reparer':
                    return $this->forward()->dispatch('Order', array(
                        'action'     => 'waiting',
                        'postalCode' => $postalCode,
                    ));
                    break;
                case 'A mailer':
                    return $this->forward()->dispatch('Order', array(
                        'action'     => 'waiting',
                        'postalCode' => $postalCode,
                    ));
                    break;
                case 'A appeler':
                    return $this->forward()->dispatch('Order', array(
                        'action'     => 'waiting',
                        'postalCode' => $postalCode,
                    ));
                    break;
                case 'Presta OK':
                    return $this->forward()->dispatch('Order', array(
                        'action'     => 'prestaOk',
                        'postalCode' => $postalCode,
                    ));
                default:
                    break;
            }

//			if ($postalCode) {
//				return $this->forward()->dispatch('Order', array(
//					'action' => 'domicile',
//					'order' => $order,
//					'orderFailure' => $orderFailure,
//				));
//			}
//			else {

            return $this->forward()->dispatch('Order', array(
                'action'       => 'express',
                'order'        => $order,
                'orderFailure' => $orderFailure,
                'postalCode'   => $postalCode,
            ));
//			}
        }

        return $this->redirect()->toUrl($this->url()->fromRoute('application'));
    }

    public function waitingAction()
    {
        $postalCode = $this->params()->fromRoute('postalCode');
        return array('postalCode' => $postalCode);
    }

    public function prestaOkAction()
    {
    }

//	public function domicileAction() {
//		$order = $this->params()->fromRoute('order');
//		$orderFailure = $this->params()->fromRoute('orderFailure');
//
//		$orderFailureMapper = $this->getServiceLocator()->get('order_failure_mapper');
//		$domicileMailForm = $this->getServiceLocator()->get('domicile_mail_form');
//		$domicileCallbackForm = $this->getServiceLocator()->get('domicile_callback_form');
//		$orderMapper = $this->getServiceLocator()->get('order_mapper');
//
//		$domicileMailForm->bind($order);
//		$domicileCallbackForm->bind($order);
//
//		$request = $this->getRequest();
//		if ($request->isPost()) {
//			$domicileMailForm->setData($request->getPost());
//			if ($domicileMailForm->isValid()) {
//				$order->setState('A mailer');
//				$orderMapper->update($order);
//				mail('contact@wefix.net', 'nouveau client a mailer', 'Identifiant de la commande: ' . $order->getId());
//			}
//		}
//
//		$failureList = $orderFailureMapper->findByOrderId($order->getId());
//
//		return (array('order' => $order, 'orderFailure' => $orderFailure, 'failureList' => $failureList, 'domicileMailForm' => $domicileMailForm, 'domicileCallbackForm' => $domicileCallbackForm));
//	}
//
//	public function callContactAction() {
//		$orderId = $this->params()->fromRoute('order_id');
//		$token = $this->params()->fromRoute('token');
//
//		$orderMapper = $this->getServiceLocator()->get('order_mapper');
//		$domicileCallbackForm = $this->getServiceLocator()->get('domicile_callback_form');
//
//		$order = $orderMapper->findById($orderId);
//		$request = $this->getRequest();
//		if ($order && $order->getToken() == $token && $request->isPost()) {
//			$domicileCallbackForm->bind($order);
//			$domicileCallbackForm->setData($request->getPost());
//			if ($domicileCallbackForm->isValid()) {
//				$order->setState('A appeler');
//				$orderMapper->update($order);
//				mail('contact@wefix.net', 'nouveau client a rappeler', 'Identifiant de la commande: ' . $order->getId());
//			}
//			return $this->redirect()->toUrl($this->url()->fromRoute('application/process', array('order_id' => $order->getId(), 'token' => $order->getToken())));
//		}
//		return $this->redirect()->toUrl($this->url()->fromRoute('application'));
//	}

    public function expressAction()
    {
        $order        = $this->params()->fromRoute('order');
        $orderFailure = $this->params()->fromRoute('orderFailure');

        $expressInfosForm = $this->getServiceLocator()->get('express_infos_form');

        $request = $this->getRequest();

        $order->setShipping('nothing');
        $order->setPointRelais(null);
        $this->orderMapper->update($order);

        $expressInfosForm->bind($order);

        if ($request->isPost()) {
            $expressInfosForm->setData($request->getPost());
            if ($expressInfosForm->isValid()) {
                $order->setState('A relancer');
                $this->orderMapper->update($order);

                return $this->redirect()->toUrl($this->url()->fromRoute('application/process/shipping', array('lang' => $this->lang, 'order_id' => $order->getId(), 'token' => $order->getToken())));
            }
        }

        return (array('order' => $order, 'orderFailure' => $orderFailure, 'expressInfosForm' => $expressInfosForm));
    }

    public function shippingAction()
    {
        $request            = $this->getRequest();
        $orderFailureMapper = $this->getServiceLocator()->get('order_failure_mapper');
        $postalMapper       = $this->getServiceLocator()->get('postal_code_mapper');

        $order = $this->orderMapper->findById($this->orderId);

        if ($order && $order->getToken() == $this->token) {
            $postalCode   = $postalMapper->findByPostalCode($order->getPostal());
            $orderFailure = $orderFailureMapper->findByOrderId($order->getId());

            $totalPrice = 0;
            foreach ($orderFailure as $failure) {
                $totalPrice += $failure->getPrice();
            }

            if ($order->getState() != 'A relancer') {
                return $this->redirect()->toUrl($this->url()->fromRoute('application/process', array(
                    'lang'     => $this->lang,
                    'order_id' => $order->getId(),
                    'token'    => $order->getToken()
                )));
            }

            if ($order->getShipping() != 'nothing') {
                return $this->forward()->dispatch('Order', array(
                    'action' => 'shippingDetails',
                    'order' => $order,
                ));
            }

            $shippingForm = $this->getServiceLocator()->get('shipping_form');
            if ($request->isPost()) {
                $shippingForm->bind($order);
                $shippingForm->setData($request->getPost());
                if ($shippingForm->isValid()) {
                    $this->orderMapper->update($order);
                    return $this->forward()->dispatch('Order', array(
                        'action' => 'shippingDetails',
                        'order' => $order,
                    ));
                }
            }

            return (array('order' => $order, 'totalPrice' => $totalPrice));
        }

        return $this->redirect()->toUrl($this->url()->fromRoute('application'));
    }

    public function cancelShippingAction()
    {
        $order = $this->orderMapper->findById($this->orderId);

        if ($order && $order->getToken() == $token) {
            $order->setPointRelais(null);
            $order->setShipping('nothing');
            $this->orderMapper->update($order);
        }

        return $this->redirect()->toUrl($this->url()->fromRoute('application/process/shipping', array('lang' => $this->lang, 'order_id' => $order->getId(), 'token' => $order->getToken())));
    }

    public function shippingDetailsAction()
    {

        $order = $this->params()->fromRoute('order');

        if (($order->getShipping() == 'Retour point relais' || $order->getShipping() == 'Aller/Retour point relais') && !$order->getPointRelais()) {
            $pointRelaisForm = $this->getServiceLocator()->get('point_relais_form');
            $pointRelaisForm->bind($order);
            $request = $this->getRequest();

            if ($request->isPost()) {
                $pointRelaisForm->setData($request->getPost());
                if ($pointRelaisForm->isValid()) {
                    $this->orderMapper->update($order);
                    return $this->redirect()->toUrl($this->url()->fromRoute('application/process/pay', array('lang' => $this->lang, 'order_id' => $order->getId(), 'token' => $order->getToken())));
                }
            }

            try {
                $chronopost = new Client('https://www.chronopost.fr/recherchebt-ws-cxf/PointRelaisServiceWS?wsdl');
                $chronopostRequestResult = $chronopost->recherchePointChronopost(array(
                    'accountNumber' => '24741002',
                    'password' => '238831',
                    'address' => $order->getAddress(),
                    'zipCode' => $order->getPostal(),
                    'city' => $order->getCity(),
                    'type' => 'P',
                    'productCode' => '1',
                    'service' => 'L',
                    'weight' => '500',
                    'shippingDate' => date('d/m/Y', strtotime('+2 Weekday')),
                    'maxPointChronopost' => '8',
                    'maxDistanceSearch' => '25',
                    'holidayTolerant' => '1'
                ));
                $listPointsRelais = $chronopostRequestResult->return->listePointRelais;
            } catch (SoapFault $e) {
                $listPointsRelais = null;
            }

            return (array('order' => $order, 'listPointsRelais' => $listPointsRelais));
        }

        return $this->redirect()->toUrl($this->url()->fromRoute('application/process/pay', array('lang' => $this->lang, 'order_id' => $order->getId(), 'token' => $order->getToken())));
    }

    public function payProcessAction()
    {
        $orderId = $this->params()->fromRoute('order_id');
        $token   = $this->params()->fromRoute('token');

        $request = $this->getRequest();

        $orderMapper = $this->getServiceLocator()->get('order_mapper');
        $orderFailureMapper = $this->getServiceLocator()->get('order_failure_mapper');
        $postalMapper = $this->getServiceLocator()->get('postal_code_mapper');

        $order = $orderMapper->findById($orderId);

        if ($order && $order->getToken() == $token) {
            $postalCode = $postalMapper->findByPostalCode($order->getPostal());
            $orderFailure = $orderFailureMapper->findByOrderId($order->getId());

            $totalPrice = 0;
            foreach ($orderFailure as $failure) {
                $totalPrice += $failure->getPrice();
            }

            $orderFailure = $orderFailureMapper->findByOrderId($order->getId());

            if ($order->getState() != 'A relancer') {
                return $this->redirect()->toUrl($this->url()->fromRoute('application/process', array('lang' => $this->lang, 'order_id' => $order->getId(), 'token' => $order->getToken())));
            }

            if ($order->getShipping() == 'Retour domicile' || $order->getShipping() == 'Aller/Retour domicile' || ($order->getShipping() == 'Retour point relais' && $order->getPointRelais()) || ($order->getShipping() == 'Aller/Retour point relais' && $order->getPointRelais())) {
                if ($order->getShipping() == 'Retour domicile') {
                    $totalPrice += 5;
                }
                if ($order->getShipping() == 'Aller/Retour point relais') {
                    $totalPrice += 10;
                }
                if ($order->getShipping() == 'Aller/Retour domicile') {
                    $totalPrice += 15;
                }

                $identifier = $this->getServiceLocator()->get('Config')['be2bill']['identifier'];
                $mdp = $this->getServiceLocator()->get('Config')['be2bill']['mdp'];
                $formUrl = $this->getServiceLocator()->get('Config')['be2bill']['formUrl'];
                $hash = hash(
                    'sha256',
                     $mdp.'AMOUNT='.($totalPrice * 100)
                    .$mdp.'CLIENTEMAIL='.$order->getMail()
                    .$mdp.'CLIENTIDENT='.$order->getId()
                    .$mdp.'DESCRIPTION=Réparation WeFix'
                    .$mdp.'IDENTIFIER='.$identifier
                    .$mdp.'OPERATIONTYPE=payment'
                    .$mdp.'ORDERID='.$order->getId()
                    .$mdp.'VERSION=2.0'.$mdp
                );

                return (array(
                    'order'        => $order,
                    'formUrl'      => $formUrl,
                    'identifier'   => $identifier,
                    'hash'         => $hash,
                    'orderFailure' => $orderFailure, 
                    'totalPrice'   => $totalPrice));
            }

            return $this->redirect()->toUrl($this->url()->fromRoute('application/process/shipping', array('lang' => $this->lang, 'order_id' => $order->getId(), 'token' => $order->getToken())));
        }

        return $this->redirect()->toUrl($this->url()->fromRoute('application'));
    }

    public function successAction()
    {
    }

    public function cancelAction()
    {
    }

    public function be2billAction()
    {
        $state       = $this->params()->fromRoute('state');
        $request     = $this->getRequest();
        $orderMapper = $this->getServiceLocator()->get('order_mapper');

        if ($state != 'notification' && $state != 'unpaid') {
            return $this->notFoundAction();
        }

        if ($this->getRequest()->isPost()) {
            // mail('gdc.assistance@gmail.com', '[!!!] TEST [!!!] WeFix', implode('|', $request->getPost()->toArray()));

            // if ($state == 'unpaid') {
            //     $post = $request->getPost();
            //     mail('gdc.assistance@gmail.com', '[!!!] TEST [!!!] Unpaid WeFix', implode('|', $request->getPost()->toArray()));
            // }

            if ($state == 'notification') {
                $post = $request->getPost();
                if ($post->get('EXECCODE') == 0) {
                    $orderId = $post->get('ORDERID');
                    $extraData = $post->get('EXTRADATA');

                    // if ($extraData && $extraData == 'astrazeneca') {
                    //     $astraZenecaMapper = $this->getServiceLocator()->get('astrazeneca_mapper');
                    //     $order = $astraZenecaMapper->findById($orderId);
                    //     if ($order) {
                    //         $order->setPaid(1);
                    //         $astraZenecaMapper->update($order);

                    //         $mailer = $this->getServiceLocator()->get('mail_service');
                    //         $message = $mailer->createHtmlMessage($order->getEmail(), 'Rachat iPhone 5S - WeFix', 'template/astrazeneca', array('order' => $order));
                    //         $mailer->send($message);
                    //         $headers = 'MIME-Version: 1.0'."\r\n";
                    //         $headers .= 'Content-type: text/html; charset=utf-8'."\r\n";
                    //         $headers .= 'To: Contact <contact@wefix.net>'."\r\n";
                    //         $headers .= 'From: WeFix <contact@wefix.net>'."\r\n";
                    //         mail('contact@wefix.net', 'Paiement - AstraZeneca', 'Nom : '.$order->getPrenom().' '.$order->getNom().' ('.$order->getTelephone().' - '.$order->getEmail().')<br><br>Adresse : '.$order->getAdresse().'<br>Ville : '.$order->getVille().' ('.$order->getCodePostal().')<br><br>IMEI : '.$order->getEmei(), $headers);
                    //     } else {
                    //         mail('gdc.assistance@gmail.com', 'Error WeFix', 'astrazeneca order id: '.$orderId);
                    //     }
                    // } else {
                    $order = $orderMapper->findById($orderId);
                    if ($order) {
                        $order->setState('A reparer');
                        $orderMapper->update($order);

                        $mailer  = $this->getServiceLocator()->get('mail_service');
                        $message = $mailer->createHtmlMessage($order->getMail(), 'Votre commande WeFix', 'template/order', array('order' => $order));
                        $mailer->send($message);

                        if ($order->getShipping()) {
                            if ($order->getShipping() == 'Aller/Retour point relais' || $order->getShipping() == 'Aller/Retour domicile') {
                                try {
                                    $chronopost = new Client('https://www.chronopost.fr/shipping-cxf/ShippingServiceWS?wsdl');

                                    $address = explode("\n", wordwrap($order->getAddress(), 38));

                                    $chronopost->shippingWithReservationAndESDWithRefClientPC(array(
                                        'subAccount'           => '000',
                                        'accountNumber'        => '24741002',
                                        'password'             => '238831',
                                        'shipperCivility'      => 'M',
                                        'shipperName'          => $order->getLastName(),
                                        'shipperName2'         => $order->getFirstName(),
                                        'shipperAdress1'       => $address[0],
                                        'shipperAdress2'       => (isset($address[1]) ? $address[1] : ''),
                                        'shipperZipCode'       => $order->getPostal(),
                                        'shipperCity'          => $order->getCity(),
                                        'shipperCountry'       => 'FR',
                                        'shipperCountryName'   => 'France',
                                        'shipperContactName'   => $order->getFirstName().' '.$order->getLastName(),
                                        'shipperEmail'         => $order->getMail(),
                                        'shipperPhone'         => $order->getPhone(),
                                        'shipperMobilePhone'   => $order->getPhone(),
                                        'recipientCivility'    => 'M',
                                        'recipientName'        => 'Société ASP',
                                        'recipientAdress1'     => '21 bd Ney',
                                        'recipientAdress2'     => '',
                                        'recipientZipCode'     => '75018',
                                        'recipientCity'        => 'Paris',
                                        'recipientCountry'     => 'FR',
                                        'recipientCountryName' => 'France',
                                        'recipientContactName' => 'Edouard Menantaud',
                                        'recipientEmail'       => 'contact@wefix.net',
                                        'recipientPhone'       => '0145747814',
                                        'recipientMobilePhone' => '0624625111',
                                        'shipperRef'           => $order->getId(),
                                        'productCode'          => '01',
                                        'shipDate'             => date('d/m/Y G:00:00'),
                                        'shipHour'             => date('G'),
                                        'weight'               => '0.5',
                                        'service'              => '0',
                                        'objectType'           => 'MAR',
                                        'modeRetour'           => '1'
                                    ));
                                } catch (SoapFault $e) {
                                    mail('contact@wefix.net', '[!!!] TEST [!!!] soap fault WeFix', implode('|', array(
                                        'subAccount'           => '000',
                                        'accountNumber'        => '24741002',
                                        'password'             => '238831',
                                        'shipperCivility'      => 'M',
                                        'shipperName'          => $order->getLastName(),
                                        'shipperName2'         => $order->getFirstName(),
                                        'shipperAdress1'       => $order->getAddress(),
                                        'shipperZipCode'       => $order->getPostal(),
                                        'shipperCity'          => $order->getCity(),
                                        'shipperCountry'       => 'FR',
                                        'shipperCountryName'   => 'France',
                                        'shipperContactName'   => $order->getFirstName().' '.$order->getLastName(),
                                        'shipperEmail'         => $order->getMail(),
                                        'shipperPhone'         => $order->getPhone(),
                                        'shipperMobilePhone'   => $order->getPhone(),
                                        'recipientCivility'    => 'M',
                                        'recipientName'        => 'Société ASP',
                                        'recipientAdress1'     => '21 bd Ney',
                                        'recipientZipCode'     => '75018',
                                        'recipientCity'        => 'Paris',
                                        'recipientCountry'     => 'FR',
                                        'recipientCountryName' => 'France',
                                        'recipientContactName' => 'Edouard Menantaud',
                                        'recipientEmail'       => 'contact@wefix.net',
                                        'recipientPhone'       => '0145747814',
                                        'recipientMobilePhone' => '0624625111',
                                        'shipperRef'           => $order->getId(),
                                        'productCode'          => '01',
                                        'shipDate'             => date('d/m/Y G:00:00'),
                                        'shipHour'             => date('G'),
                                        'weight'               => '0.5',
                                        'service'              => '0',
                                        'objectType'           => 'MAR',
                                        'modeRetour'           => '1'
                                    )));
                                }
                            }
                        }

                        mail('contact@wefix.net', '[!!!] TEST [!!!] commande payee', 'Identifiant de la nouvelle commande payee: '.$order->getId());
                    } else {
                        mail('contact@wefix.net', '[!!!] TEST [!!!] Error WeFix', 'order id: '.$orderId);
                    }
                }
                    // }
                // } else {
                //     mail('gdc.assistance@gmail.com', 'Payment Failure WeFix', implode('|', $post->toArray()));
                // }
            }
        }

        $viewModel = new ViewModel();
        $viewModel->setTerminal(true);
        return $viewModel;
    }

//	public function testChronoAction() {
//		$orderMapper = $this->getServiceLocator()->get('order_mapper');
//
//		$order = $orderMapper->findById(2143);
//
////		var_dump("begin");
////
////		var_dump($order->getId());
////		var_dump($order->getToken());
////		var_dump($order->getDay());
////		var_dump($order->getHour());
////		var_dump($order->getLastName());
////		var_dump($order->getFirstName());
////		var_dump($order->getAddress());
////		var_dump($order->getCity());
////		var_dump($order->getPostal());
////		var_dump($order->getPhone());
////		var_dump($order->getMail());
////		var_dump($order->getComment());
////		var_dump($order->getShipping());
////		var_dump($order->getPointRelais());
////		var_dump($order->getDateCreated());
////		var_dump($order->getState());
////
////		var_dump("end");
////
////		exit();
//
////		var_dump(preg_replace("/[^a-zA-Z0-9]+/", "", $order->getAddress()));exit();
//
//		$address = explode("\n", wordwrap($order->getAddress(), 38));
//
//		$chronopost = new \Zend\Soap\Client("https://www.chronopost.fr/shipping-cxf/ShippingServiceWS?wsdl");
//									$chronopost->shippingWithReservationAndESDWithRefClientPC(array('subAccount' => '000', 'accountNumber' => '24741002', 'password' => '238831', 'shipperCivility' => 'M', 'shipperName' => $order->getLastName(), 'shipperName2' => $order->getFirstName(), 'shipperAdress1' => '51 av charles .de gaul', 'shipperAdress2' => 'es residence jj sainclair', 'shipperZipCode' => $order->getPostal(), 'shipperCity' => $order->getCity(), 'shipperCountry' => 'FR', 'shipperCountryName' => 'France', 'shipperContactName' => $order->getFirstName() . ' ' . $order->getLastName(), 'shipperEmail' => $order->getMail(), 'shipperPhone' => $order->getPhone(), 'shipperMobilePhone' => $order->getPhone(), 'recipientCivility' => 'M', 'recipientName' => 'SAS EMGK - WeFix', 'recipientAdress1' => '21 bd Ney', 'recipientZipCode' => '75018', 'recipientCity' => 'Paris', 'recipientCountry' => 'FR', 'recipientCountryName' => 'France', 'recipientContactName' => 'Edouard Menantaud', 'recipientEmail' => 'contact@wefix.net', 'recipientPhone' => '0145747814', 'recipientMobilePhone' => '0624625111', 'shipperRef' => $order->getId(), 'productCode' => '01', 'shipDate' => date('d/m/Y G:00:00'), 'shipHour' => date('G'), 'weight' => '0.5', 'service' => '0', 'objectType' => 'MAR', 'modeRetour' => '1'));
//
////		$chronopost = new \Zend\Soap\Client("https://www.chronopost.fr/shipping-cxf/ShippingServiceWS?wsdl");
////		$chronopost->shippingWithReservationAndESDWithRefClientPC(array('subAccount' => '000', 'accountNumber' => '24741002', 'password' => '238831', 'shipperCivility' => 'M', 'shipperName' => 'Caggiari', 'shipperName2' => 'Vincent', 'shipperAdress1' => '93 rue du Général Leclerc', 'shipperZipCode' => '95600', 'shipperCity' => 'EAUBONNE', 'shipperCountry' => 'FR', 'shipperCountryName' => 'France', 'shipperContactName' => 'Vincent Caggiari', 'shipperEmail' => 'vincent@edencia.com', 'shipperPhone' => '33668486225', 'shipperMobilePhone' => '33668486225', 'recipientCivility' => 'M', 'recipientName' => 'SAS EMGK - WeFix', 'recipientAdress1' => '21 bd Ney', 'recipientZipCode' => '75018', 'recipientCity' => 'Paris', 'recipientCountry' => 'FR', 'recipientCountryName' => 'France', 'recipientContactName' => 'Edouard Menantaud', 'recipientEmail' => 'contact@wefix.net', 'recipientPhone' => '0145747814', 'recipientMobilePhone' => '0624625111', 'shipperRef' => '1234', 'productCode' => '01', 'shipDate' => date('d/m/Y G:00:00'), 'shipHour' => date('G'), 'weight' => '0.5', 'service' => '0', 'objectType' => 'MAR', 'modeRetour' => '1'));
//	}

    public function diagnosticAction()
    {
        $orderId = $this->params()->fromRoute('order_id');
        $token   = $this->params()->fromRoute('token');

        $orderMapper        = $this->getServiceLocator()->get('order_mapper');
        $orderFailureMapper = $this->getServiceLocator()->get('order_failure_mapper');

        $order = $orderMapper->findById($orderId);
        if ($order && $order->getToken() == $token) {
            $orderFailure = $orderFailureMapper->findByOrderId($order->getId());

            $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

            $pdf->SetCreator('WeFix');
            $pdf->SetAuthor('WeFix');
            $pdf->SetTitle('Diagnostique '.$order->getId());
            $pdf->SetSubject('Diagnostique '.$order->getId());
            $pdf->SetKeywords('diagnostique, WeFix');
            $pdf->SetPrintHeader(false);
            $pdf->SetPrintFooter(false);
            $pdf->SetMargins(2, 2, 2);
            $pdf->SetAutoPageBreak(true, 3);
            $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
            $pdf->AddPage();

            $html = '
			<body>
			<img src="'.$this->getServiceLocator()->get('Config')['static_path'].'/img/diagno_top.png"><br><br>
			<div style="text-align:center;font-size: 27px;">
				Fiche de suivi - À joindre avec votre appareil
			</div>
			<br><br>
			<table style="font-size: 11px;text-align: center;">
				<tr>
					<td style="width: 25%;">
					<img src="'.$this->getServiceLocator()->get('Config')['static_path'].'/img/verrou.png" style="width: 40px;height:40px;">
					<div>Envoi sécurisé et assuré</div>
					</td>
					<td style="width: 25%;">
					<img src="'.$this->getServiceLocator()->get('Config')['static_path'].'/img/chronopost2.png" style="width: 87px;height:40px;">
					<div>Lendemain avant 13h</div>
					</td>
					<td style="width: 25%;">
					<img src="'.$this->getServiceLocator()->get('Config')['static_path'].'/img/data.png" style="width: 40px;height:40px;">
					<div>Aucune perte de données</div>
					</td>
					<td style="width: 25%;">
					<img src="'.$this->getServiceLocator()->get('Config')['static_path'].'/img/lagarantie.png" style="width: 40px;height:40px;">
					<div>Garantie 1 an</div>
					</td>
				</tr>
			</table>
			<br><br>
			<table class="details">
			<tr>
			<td style="width: 3%;">
			</td>
			<td style="width: 94%;">
			<hr>
			</td>
			<td style="width: 3%;">
			</td>
			</tr>
			<tr>
			<td></td>
			<td>
			Suivez ces instuctions attentivement:<br><br>
			<table style="font-size: 13px;">
			<tr>
			<td style="width: 80px;">
			<img src="'.$this->getServiceLocator()->get('Config')['static_path'].'/img/print-suivi.png" style="width: 71px;height:60px;">
			</td>
			<td style="width: 600px;">
			<b>1. Imprimez ce formulaire</b>
			<div>
			Imprimez ce document et joignez le à votre appareil.<br>
			Si vous n\'avez pas d\'imprimante, recopiez la fiche de suivi présente en bas de page.
			</div>
			</td>
			</tr>
			<tr>
			<td style="width: 80px;">
			<img src="'.$this->getServiceLocator()->get('Config')['static_path'].'/img/appareil.png" style="width: 71px;height:60px;">
			</td>
			<td style="width: 600px;">
			<img src="'.$this->getServiceLocator()->get('Config')['static_path'].'/img/pixel.jpg"><br>
			<b>2. Emballez votre appareil</b>
			<div>
			Emballez soigneusement votre appareil (sans sa boite, sans carte SIM) accompagné de ce document.
			</div>
			</td>
			</tr>
			<tr><td colspan="2" height="20"></td></tr>
			<tr>
			<td style="width: 80px;">
			<img src="'.$this->getServiceLocator()->get('Config')['static_path'].'/img/envoie.png" style="width: 60px;height:50px;">
			</td>
			<td style="width: 600px;">
			<b>3. Envoi</b>
			<div>
			Rendez-vous à La Poste la plus proche de chez vous afin de nous envoyer votre appareil.<br>
			Remplissez bien l\'adresse de WeFix :<br><br>
			<b>WeFix<br>
			2ème étage droite<br>
			21 bd Ney<br>
			75018 Paris</b>
			</div>
			</td>
			</tr>
			<tr><td colspan="2" height="20"></td></tr>
			<tr>
			<td style="width: 80px;">
			<img src="'.$this->getServiceLocator()->get('Config')['static_path'].'/img/reparation2.png" style="width: 60px;height:50px;">
			</td>
			<td style="width: 600px;">
			<b>4. Réparation</b>
			<div>
			Dès réception de votre colis, nous diagnostiquons puis réparons votre appareil.<br>
			Une fois la réparation terminée, nous testons entièrement votre appareil.
			</div>
			</td>
			</tr>
			<tr><td colspan="2" height="20"></td></tr>
			<tr>
			<td style="width: 80px;">
			<img src="'.$this->getServiceLocator()->get('Config')['static_path'].'/img/renvoie.png" style="width: 60px;height:50px;">
			</td>
			<td style="width: 600px;">
			<b>5. Renvoi de votre appareil</b>
			<div>
			Après validation par notre service technique, votre appareil est renvoyé chez vous selon le moyen de transport que vous avez choisi au préalable. Une facture sera jointe dans le colis renvoyé.
			</div>
			</td>
			</tr>
			</table>
			</td>
			<td>
			</td>
			</tr>
			</table>
			<br><br>
			<table>
			<tr>
			<td width="110"></td>
			<td width="500">
			<div style="text-align:center;font-size:12px;">
			Si vous avez besoin d’aide, regardez la page FAQ de notre site internet: www.wefix.net/fr/faq
			ou appelez directement notre service client : 01 76 50 76 50
			</div>
			</td>
			<td width="90"></td>
			</tr>
			</table>
			<br><br>
			<table>
			<tr>
			<td>
			<hr>
			</td>
			</tr>
			</table>

			<div style="text-align: center;">
			Numéro de commande: <b>'.$order->getId().'</b> (code d\'identification: '.$order->getToken().')
			</div>
			<br>
			<table>
			<tr>
			<td width="50">
			</td>
			<td width="600">
			<div>
			<b>Réparation(s):</b><br>
			';

            foreach ($orderFailure as $failure) {
                $html .= ' - '.$failure->getType().' '.$failure->getBrand().' '.$failure->getModel().' '.$failure->getColor().' '.$failure->getName().'<br>';
            }

            $html .= '</div>
			<div>Commentaire:<br>
			<span style="font-size: 12px;">'.($order->getComment() ?: 'Aucun').'</span>
			</div>
			</td>
			<td width="50">
			</td>
			</tr>
			</table>
			';

            $pdf->writeHTML($html, true, false, true, false, '');

            $pdf->lastPage();

            $pdf->Output('facture_'.$order->getId(), 'I');

            exit();
        }

        return $this->redirect()->toUrl($this->url()->fromRoute('application'));
    }

    public function factureAction()
    {
        $orderId = $this->params()->fromRoute('order_id');
        $token   = $this->params()->fromRoute('token');

        $orderMapper = $this->getServiceLocator()->get('order_mapper');
        $orderFailureMapper = $this->getServiceLocator()->get('order_failure_mapper');

        $order = $orderMapper->findById($orderId);
        if ($order && $order->getToken() == $token) {
            $orderFailure = $orderFailureMapper->findByOrderId($order->getId());

            $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

            $pdf->SetCreator('WeFix');
            $pdf->SetAuthor('WeFix');
            $pdf->SetTitle('Facture '.$order->getId());
            $pdf->SetSubject('Facture '.$order->getId());
            $pdf->SetKeywords('facture, wefix');
            $pdf->SetPrintHeader(false);
            $pdf->SetPrintFooter(false);
            $pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
            $pdf->SetAutoPageBreak(true, PDF_MARGIN_BOTTOM);
            $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
            $pdf->AddPage();

            $html = '
			<style>
			body {
				font-size: 12px;
			}

			a {
				color: #5e6472;
			}

			.entete tr td {
				border-top: 2px solid #707070;
				border-bottom: 2px solid #707070;
			}

			.presta tr th {
				background-color: #bfbfbf;
				border: 1px solid #bfbfbf;
			}

			.presta tr td {
				background-color: #eaeaea;
				border: 1px solid #bfbfbf;
			}

			</style>
			<body>
			<img src="'.$this->getServiceLocator()->get('Config')['static_path'].'/wefix/img/logo.png"><br><br>
			<table class="entete">
				<tr>
					<td style="width: 300px;">
						WeFix<br>
						21 bd Ney<br>
						75018 Paris<br>
						Tel: 01 76 50 76 50<br>
						<a href="http://www.wefix.net">www.wefix.net</a><br>
						<a href="mailto:contact@wefix.net">contact@wefix.net</a><br>
						RCS Paris 518 902 804<br>
						SIRET: 518 902 804 000 21<br>
						N° de TVA intracommunautaire: FR44518902804
					</td>
					<td style="width: 70px;background-color:#bfbfbf;">
					</td>
					<td style="width: 20px;">
					</td>
					<td style="width: 260px;">
						Facture n° '.$order->getId().'<br>
						Date de la facture : '.$order->getDateCreated().'<br><br>
						Facturé à : '.$order->getFirstName().' '.$order->getLastName().'<br>
						Adresse: '.$order->getAddress().', '.$order->getPostal().' - '.$order->getCity().'
					</td>
				</tr>
			</table>
			<br><br><br>
			<table class="presta">
				<tr>
					<th style="width: 300px;">
						 Description
					</th>
					<th style="width: 80px;text-align:center;">
						Quantité
					</th>
					<th style="width: 135px;text-align:center;">
						Coût unitaire HT
					</th>
					<th style="width: 135px;">
						Montant HT
					</th>
				</tr>
			';

            $totalPrice = 0;
            $sousTotal = 0;

            foreach ($orderFailure as $failure) {
                $totalPrice += $failure->getPrice();
                $sousTotal += round($failure->getPrice() * 0.8333333333333333, 2);
                $html .= '<tr><td> '.$failure->getType().' > '.$failure->getBrand().' > '.$failure->getModel().' > '.$failure->getColor().' > '.$failure->getName().'</td>
					<td style="text-align:center;">1</td>
					<td style="text-align:center;">'.round($failure->getPrice() * 0.8333333333333333, 2).' €</td>
					<td style="text-align:right;">'.round($failure->getPrice() * 0.8333333333333333, 2).' €</td></tr>';
            }

            if ($order->getShipping()) {
                if ($order->getShipping() == 'Retour domicile') {
                    $html .= '<tr><td> Transport retour domicile</td><td style="text-align:center;">1</td><td style="text-align:center;">'.round(5 * 0.8333333333333333, 2).' €</td><td style="text-align:right;">'.round(5 * 0.8333333333333333, 2).' €</td></tr>';
                    $totalPrice += 5;
                    $sousTotal += round(5 * 0.8333333333333333, 2);
                }
                if ($order->getShipping() == 'Aller/Retour point relais') {
                    $html .= '<tr><td> Transport Aller/Retour point relais</td><td style="text-align:center;">1</td><td style="text-align:center;">'.round(10 * 0.8333333333333333, 2).' €</td><td style="text-align:right;">'.round(10 * 0.8333333333333333, 2).' €</td></tr>';
                    $totalPrice += 10;
                    $sousTotal += round(10 * 0.8333333333333333, 2);
                }
                if ($order->getShipping() == 'Aller/Retour domicile') {
                    $html .= '<tr><td> Transport Aller/Retour domicile</td><td style="text-align:center;">1</td><td style="text-align:center;">'.round(15 * 0.8333333333333333, 2).' €</td><td style="text-align:right;">'.round(15 * 0.8333333333333333, 2).' €</td></tr>';
                    $totalPrice += 15;
                    $sousTotal += round(15 * 0.8333333333333333, 2);
                }
            }

            $html .= '
			</table><br><br>
			<table>
			<tr><td style="width: 515px;text-align:right;">Sous-total de la facture<br><br><br>Taux de la T.V.A.<br>Montant de la T.V.A.<br><div style="background-color:#eaeaea;"><b>TOTAL</b></div></td><td style="text-align: right;width:135px;">'.$sousTotal.' €<br><br><br>20%<br> '.round($sousTotal * 20 / 100, 2).' €<br><div style="background-color:#eaeaea;"><b>'.$totalPrice.' €</b></div></td></tr>
			</table>
			<br><br>
			<div style="text-align:center;">
			<b>Nous vous remercions pour votre confiance.</b>
			</div>
			</body>';

            $pdf->writeHTML($html, true, false, true, false, '');

            $pdf->lastPage();

            $pdf->Output('facture_'.$order->getId(), 'I');

            exit();
        }

        return $this->redirect()->toUrl($this->url()->fromRoute('application'));
    }


    /**
     * Constructor to inject translator and lang in all actions.
     */
    protected $lang;
    protected $langId;
    protected $token;
    protected $orderId;
    protected $orderMapper;
    public function __construct(
        $lang = null,
        $langId = null,
        $token = null,
        $orderId = null,
        $orderMapper = null
    )
    {
        if (!is_null($lang)) {
            $this->lang = $lang;
        }

        if (!is_null($langId)) {
            $this->langId = $langId;
        }

        if (!is_null($token)) {
            $this->token = $token;
        }

        if (!is_null($orderId)) {
            $this->orderId = $orderId;
        }

        if (!is_null($orderMapper)) {
            $this->orderMapper = $orderMapper;
        }
    }
}
