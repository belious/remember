<?php

namespace Application\View\Helper;

use Zend\View\Helper\AbstractHelper;

/**
 * Remove text between "()"
 */
class CleanRef extends AbstractHelper
{

    public function __invoke($name = '')
    {
        $explodedName = explode('(', $name);

        $count = 0;
        foreach ($explodedName as $key => $splitedString) {
            $count++;
            if ($count % 2)
                continue;
            $explodedParenthesis = explode(')', $splitedString);
            unset($explodedParenthesis[0]);
            $explodedName[$key] = implode('', $explodedParenthesis);
        }

        return str_replace('  ', '', implode('', $explodedName));
    }

}
