<?php

namespace Basic;

use Zend\Mvc\MvcEvent;
use Zend\Validator\AbstractValidator;

class Module
{

    public function onBootstrap(MvcEvent $e)
    {
        $translator = $e->getApplication()->getServiceManager()->get('translator');
        AbstractValidator::setDefaultTranslator($translator, 'Zend_Validate');
    }

    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }

}
