<?php

namespace Mail;

use Zend\ModuleManager\ModuleManager;
use Zend\Mvc\MvcEvent;

class Module
{

    public function onBootstrap(MvcEvent $e)
    {
        
    }

    public function init(ModuleManager $moduleManager)
    {
        
    }

    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }

    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
                ),
            ),
        );
    }

    public function getControllerPluginConfig()
    {
        return array(
        );
    }

    public function getServiceConfig()
    {
        return array(
            'shared' => array(
                'mail_default_message' => false,
            ),
            'factories' => array(
                'mail_smtp_transport' => 'Mail\Factory\SmtpTransportFactory',
                'mail_default_message' => 'Mail\Factory\MessageFactory',
                'mail_service' => function ($sm) {
                    $mailService = new Service\Mail();
                    $mailService->setServiceManager($sm);

                    return $mailService;
                },
            ),
        );
    }

}
