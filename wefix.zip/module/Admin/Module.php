<?php

namespace Admin;

use Zend\Mvc\MvcEvent;
use Zend\View\Model\ViewModel;

class Module
{

    public function onBootstrap(MvcEvent $e)
    {
        $app = $e->getParam('application');
        $app->getEventManager()->attach('dispatch', array($this, 'setLayout'));
    }

    public function setLayout(MvcEvent $e)
    {
        if (!preg_match('/admin/', $e->getRouteMatch()->getMatchedRouteName())) {
            // not a controller from this module
            return;
        }
        
        $viewModel = $e->getViewModel();
        $baseTemplate = $viewModel->getTemplate();
        $viewModel->setTemplate('layout/admin');

        $baseModel = new ViewModel();
        $baseModel->addChild($viewModel);
        $baseModel->setTemplate($baseTemplate);

        $e->setViewModel($baseModel);
    }

    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }

    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
                ),
            ),
        );
    }

    public function getServiceConfig()
    {
        return array(
        );
    }

}
