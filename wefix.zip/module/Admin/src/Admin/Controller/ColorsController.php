<?php

namespace Admin\Controller;

use Zend\Mvc\Controller\AbstractActionController;

class ColorsController extends AbstractActionController
{
    public function listAction()
    {
        $modelId = $this->params()->fromRoute('model_id', 0);

        $colorMapper = $this->getServiceLocator()->get('color_mapper');
        $modelMapper = $this->getServiceLocator()->get('model_mapper');
        $brandMapper = $this->getServiceLocator()->get('brand_mapper');

        $model = $modelMapper->findById($modelId);
        if (!$model) {
            return $this->redirect()->toUrl($this->url()->fromRoute('admin', array('lang' => $this->params()->fromRoute('lang'))));
        }

        $brand = $brandMapper->findById($model->getBrandId());

        $deviceId = $brand->getDeviceId();

        $colorForm = $this->getServiceLocator()->get('color_form');

        $request = $this->getRequest();
        if ($request->isPost()) {
            $data = array_merge_recursive($request->getFiles()->toArray(), $this->getRequest()->getPost()->toArray());
            $colorForm->setData($data);

            if (isset($data['id']) && $data['id'] != 0) {
                $colorForm->getInputFilter()->remove('picture');
            }

            if ($colorForm->isValid()) {
                $colorData = $colorForm->getData();

                $color = new \Application\Entity\Color();

                if ($colorData['id'] != 0) {
                    $color = $colorMapper->findById($colorData['id']);
                }

                $color->setName($colorData['name']);
                $color->setModelId($model->getId());

                $uniqueEntryService = $this->getServiceLocator()->get('UniqueEntryUrl');
                $color->setUrl($uniqueEntryService->generate($this->getServiceLocator()->get('color_mapper')->getTableName(), 'url', $color->getName(), new \Zend\Db\Sql\Predicate\Expression('model_id = '.$model->getId())));

                if ($colorData['id'] == 0) {
                    $color->setId(null);
                    $colorMapper->insert($color);
                } else {
                    $colorMapper->update($color);
                }

                if (isset($colorData['picture']) && $colorData['picture']['error'] == 0) {
                    if (copy($colorData['picture']['tmp_name'], $this->getServiceLocator()->get('Config')['static_path'].'/upload/color-'.$color->getId().'.png')) {
                        $color->setImageUrl($this->getServiceLocator()->get('Config')['static_url'].'/upload/color-'.$color->getId().'.png');

                        $colorMapper->update($color);
                    } elseif ($colorData['id'] == 0) {
                        $colorMapper->delete($color);
                    }
                }

                if ($colorData['id'] != 0) {
                    return $this->redirect()->toUrl($this->url()->fromRoute('admin/colors', array('lang' => $this->params()->fromRoute('lang'), 'model_id' => $model->getId())));
                }
            }
        }

        $colorList = $colorMapper->findByModelId($model->getId());

        return (array('brand' => $brand, 'deviceId' => $deviceId, 'colorForm' => $colorForm, 'model' => $model, 'colorList' => $colorList));
    }

    public function editAction()
    {
        $colorId = $this->params()->fromRoute('color_id');

        $failureMapper = $this->getServiceLocator()->get('failure_mapper');
        $colorMapper = $this->getServiceLocator()->get('color_mapper');
        $modelMapper = $this->getServiceLocator()->get('model_mapper');
        $brandMapper = $this->getServiceLocator()->get('brand_mapper');

        $color = $colorMapper->findById($colorId);
        if (!$color) {
            return $this->redirect()->toUrl($this->url()->fromRoute('admin', array('lang' => $this->params()->fromRoute('lang'))));
        }

        $model = $modelMapper->findById($color->getModelId());
        $brand = $brandMapper->findById($model->getBrandId());

        $deviceId = $brand->getDeviceId();

        $colorForm = $this->getServiceLocator()->get('color_form');

        $colorForm->setAttributes(array(
            'action' => $this->url()->fromRoute('admin/colors', array('lang' => $this->params()->fromRoute('lang'), 'model_id' => $model->getId())),
        ));

        $colorForm->setHydrator(new \Zend\Stdlib\Hydrator\ClassMethods());
        $colorForm->bind($color);

        return (array('brand' => $brand, 'model' => $model, 'color' => $color, 'deviceId' => $deviceId, 'colorForm' => $colorForm));
    }

    public function deleteAction()
    {
        $colorId = $this->params()->fromRoute('color_id', 0);

        $colorMapper = $this->getServiceLocator()->get('color_mapper');
        $color = $colorMapper->findById($colorId);
        if ($color) {
            $modelId = $color->getModelId();

            $failureMapper = $this->getServiceLocator()->get('failure_mapper');
            $failureList = $failureMapper->findByColorId($colorId);

            foreach ($failureList as $failure) {
                $this->forward()->dispatch('Failures', array(
                    'action' => 'delete',
                    'color_id' => $colorId,
                    'failure_id' => $failure->getId(),
                ));
            }

            $colorMapper->delete($color);

            return $this->redirect()->toUrl($this->url()->fromRoute('admin/colors', array('model_id' => $modelId)));
        }

        return $this->redirect()->toUrl($this->url()->fromRoute('admin', array('lang' => $this->params()->fromRoute('lang'))));
    }
}
