<?php

namespace Admin\Controller;

use Zend\Mvc\Controller\AbstractActionController;

class FailuresController extends AbstractActionController
{
    public function listAction()
    {
        $colorId       = $this->params()->fromRoute('color_id', 0);
        $color         = $this->colorMapper->findById($colorId);
        if (!$color) {
            return $this->redirect()->toUrl($this->url()->fromRoute('admin', array('lang' => $this->params()->fromRoute('lang'))));
        }
        $model       = $this->modelMapper->findById($color->getModelId());
        $brand       = $this->brandMapper->findById($model->getBrandId());
        $deviceId    = $brand->getDeviceId();

        $request = $this->getRequest();
        if ($request->isPost()) {
            $data = array_merge_recursive($request->getFiles()->toArray(), $request->getPost()->toArray());

            if ($data['picture']) { 
                $this->failureForm->setData($data);

                if ($this->failureForm->isValid()) {

                    $failureData = $this->failureForm->getData();
                    $failure = new \Application\Entity\Failure();
                    $failure = $this->failureMapper->findById($failureData['id']);
                    $failure->setName($failureData['name'])
                            ->setPictoId($failureData['picto_id'])
                            ->setDisabled($failureData['disabled'])
                    ;
                    
                    if ($failureData['picture']['error'] == 0) {
                        $adapter = new \Zend\File\Transfer\Adapter\Http();
                        $adapter->addFilter('File\Rename',array(
                            'source' => $data['picture']['tmp_name'],
                            'target' => $this->getServiceLocator()->get('Config')['static_path'].'/upload/failure-'.$failure->getId().'.png',
                            'overwrite' => true
                        ));
                        $adapter->receive();
                        $failure->setImageUrl($this->getServiceLocator()->get('Config')['static_url'].'/upload/failure-'.$failure->getId().'.png');
                        $this->failureMapper->update($failure);
                    }
                    $this->failureMapper->update($failure);
                    return $this->redirect()->toUrl($this->url()->fromRoute('admin/failures', array('lang' => $this->lang, 'color_id' => $color->getId())));
                }

            } else if ($data['titre']) {
                $this->failureLangForm->setData($data);
                if ($this->failureLangForm->isValid()) {
                    $failureLangData = $this->failureLangForm->getData();
                    $failureLang = $this->failureLangMapper->findByFailureAndLang($failureLangData['failure_id'], $failureLangData['lang_id']);
                    $failureLang->setName($failureLangData['name'])
                                ->setPrice($failureLangData['price'])
                                ->setInfos($failureLangData['description'])
                                ->setTitre($failureLangData['titre'])
                                ->setDescription($failureLangData['description'])
                                ->setMoreInfoReplacement($failureLangData['more_info_replacement'])
                    ;
                    $this->failureLangMapper->update($failureLang);
                }
                return $this->redirect()->toUrl($this->url()->fromRoute('admin/failures', array('lang' => $this->lang, 'color_id' => $color->getId())));
            }
        }

        $failureList = $this->failureMapper->findByColorId($color->getId());
        return (array('brand' => $brand, 'deviceId' => $deviceId, 'failureForm' => $this->failureForm, 'color' => $color, 'model' => $model, 'failureList' => $failureList));
    }

    public function addAction()
    {
        $colorId       = $this->params()->fromRoute('color_id', 0);
        $color         = $this->colorMapper->findById($colorId);
        if (!$color) {
            return $this->redirect()->toUrl($this->url()->fromRoute('admin', array('lang' => $this->lang)));
        }
        $model         = $this->modelMapper->findById($color->getModelId());
        $brand         = $this->brandMapper->findById($model->getBrandId());
        $deviceId      = $brand->getDeviceId();

        $request = $this->getRequest();
        if ($request->isPost()) {  
            $data = array_merge_recursive($request->getFiles()->toArray(), $this->getRequest()->getPost()->toArray());
            $this->failureForm->setData($data);

            if ($this->failureForm->isValid()) {
                $failureData = $this->failureForm->getData();
                $failure = new \Application\Entity\Failure();

                $failure->setId(null)
                        ->setColorId($color->getId())
                        ->setName($failureData['name'])
                        ->setPictoId($failureData['picto_id'])
                        ->setDisabled($failureData['disabled'])
                ;

                $uniqueEntryService = $this->getServiceLocator()->get('UniqueEntryUrl');
                $baseUrl = $uniqueEntryService->createUrl($failure->getName());
                $tmpUrl = $baseUrl;
                $count = 0;

                do {
                    $searchResult = $this->failureMapper->findByUrlAndColorId($tmpUrl, $failure->getColorId());
                    if ($searchResult && !$failure->getId()) {
                        $count++;
                        $tmpUrl = $baseUrl.$count;
                    } else {
                        $failure->setUrl($tmpUrl);
                    }
                } while (!$failure->getUrl());

                $lastFailure = $this->failureMapper->findLast($color->getId());
                if ($lastFailure) {
                    $failure->setTop($lastFailure->getTop() - 1);
                } else {
                    $failure->setTop(0);
                }

                $this->failureMapper->insert($failure);

                if ($failureData['picture']['error'] == 0) {
                    $adapter = new \Zend\File\Transfer\Adapter\Http();
                    $adapter->addFilter('File\Rename',array(
                        'source' => $data['picture']['tmp_name'],
                        'target' => $this->getServiceLocator()->get('Config')['static_path'].'/upload/failure-'.$failure->getId().'.png',
                        'overwrite' => true
                    ));
                    $adapter->receive();
                    $failure->setImageUrl($this->getServiceLocator()->get('Config')['static_url'].'/upload/failure-'.$failure->getId().'.png');
                    $this->failureMapper->update($failure);
                }

                foreach ($this->getServiceLocator()->get('Config')['translation']['available'] as $configuredLang) {
                    $failureLang = new \Application\Entity\FailureLang();
                    $failureLang->setName('')
                                ->setPrice('')
                                ->setInfos('')
                                ->setTitre('')
                                ->setDescription('')
                                ->setMoreInfoReplacement('')
                                ->setFailureId($failure->getId())
                                ->setLangId($this->getServiceLocator()->get('lang_mapper')->findByLang($configuredLang)->getId())
                    ;
                    $this->failureLangMapper->insert($failureLang);
                }

                return $this->redirect()->toUrl($this->url()->fromRoute('admin/failures', array('lang' => $this->lang, 'color_id' => $color->getId())));

            } else {
                return (array('color' => $color, 'brand' => $brand, 'model' => $model, 'deviceId' => $deviceId, 'form' => $this->failureForm));
            }        
        } else {
            $this->failureForm->setAttributes(array(
                'action' => $this->url()->fromRoute('admin/failures/add', array(
                    'color_id' => $colorId,
                    'lang' => $this->lang
                )),
            ));

            $this->failureForm->setHydrator(new \Zend\Stdlib\Hydrator\ClassMethods());

            return (array('brand' => $brand, 'deviceId' => $deviceId, 'form' => $this->failureForm, 'color' => $color, 'model' => $model));
        }   
    }


    public function editAction()
    {
        $failureId = $this->params()->fromRoute('failure_id', 0);
        $colorId   = $this->params()->fromRoute('color_id', 0);
        $failure   = $this->failureMapper->findById($failureId);
        if (!$failure) {
            return $this->redirect()->toUrl($this->url()->fromRoute('admin', array('lang' => $this->lang)));
        }
        $color     = $this->colorMapper->findById($failure->getColorId());
        $model     = $this->modelMapper->findById($color->getModelId());
        $brand     = $this->brandMapper->findById($model->getBrandId());
        $deviceId  = $brand->getDeviceId();

        $this->failureForm->setAttributes(array(
            'action' => $this->url()->fromRoute('admin/failures', array(
                'color_id' => $color->getId(),
                'lang'     => $this->lang,
            )),
        ));

        $this->failureForm->setHydrator(new \Zend\Stdlib\Hydrator\ClassMethods());
        $this->failureForm->bind($failure);

        return (array('brand' => $brand, 'deviceId' => $deviceId, 'form' => $this->failureForm, 'failure' => $failure, 'color' => $color, 'model' => $model));
    }

    public function editlangAction()
    {
        $failureId         = $this->params()->fromRoute('failure_id', 0);
        $colorId           = $this->params()->fromRoute('color_id', 0);
        $failureLang       = $this->failureLangMapper->findByFailureAndLang($failureId, $this->langId);
        $failure           = $this->failureMapper->findById($failureId);

        if (!$failureLang) {
            return $this->redirect()->toUrl($this->url()->fromRoute('admin', array('lang' => $this->lang)));
        }

        $color           = $this->colorMapper->findById($failure->getColorId());
        $model           = $this->modelMapper->findById($color->getModelId());
        $brand           = $this->brandMapper->findById($model->getBrandId());
        $deviceId        = $brand->getDeviceId();

        $this->failureLangForm->setAttributes(array(
            'action' => $this->url()->fromRoute('admin/failures', array(
                'color_id' => $color->getId(),
                'lang'     => $this->lang,
            )),
        ));

        $this->failureLangForm->setHydrator(new \Zend\Stdlib\Hydrator\ClassMethods());
        $this->failureLangForm->bind($failureLang);

        return (array('brand' => $brand, 'deviceId' => $deviceId, 'form' => $this->failureLangForm, 'failure' => $failure, 'color' => $color, 'model' => $model));
    }

    public function storeAction()
    {
        $failureId = $this->params()->fromRoute('failure_id', 0);
        $colorId = $this->params()->fromRoute('color_id', 0);

        $failure = $this->failureMapper->findById($failureId);
        if ($failure) {
            $failure->setDisabled(!$failure->getDisabled());
            $this->failureMapper->update($failure);
        }

        return $this->redirect()->toUrl($this->url()->fromRoute('admin/failures', array('lang' => $this->lang, 'color_id' => $colorId)));
    }

    public function starAction()
    {
        $id      = $this->params()->fromRoute('id', 0);
        $failure = $this->failureMapper->findById($id);

        if ($failure) {
            $next = $this->failureMapper->fetchNext($failure->getTop(), $failure->getColorId());
            // We are the first
            if (!$next->count()) {
                // nothing
            } elseif ($next->count() == 1) { // We are behind the first
                $failure->setTop($next->current()->getTop() + 1);
            } else { // We are far and there are at least 2 brands on top of us
                $next1 = $next->current();
                $failure->setTop($next1->getTop() + 1);
                $this->failureMapper->addTopFrom($failure->getColorId(), $next1);
            }
            $this->failureMapper->update($failure);
        }

        return $this->redirect()->toUrl($this->url()->fromRoute('admin/failures', array('lang' => $this->lang, 'color_id' => $failure->getColorId())));
    }

    public function downAction()
    {
        $id      = $this->params()->fromRoute('id', 0);
        $failure = $this->failureMapper->findById($id);
        if ($failure) {
            $previous = $this->failureMapper->fetchPrevious($failure->getTop(), $failure->getColorId());
            // We are the first
            if (!$previous->count()) {
                // nothing
            } elseif ($previous->count() == 1) { // We are before the last
                $failure->setTop($previous->current()->getTop() - 1);
            } else { // We are far and there are at least 2 brands on top of us
                $previous1 = $previous->current();
                $failure->setTop($previous1->getTop() - 1);
                $this->failureMapper->downTopFrom($failure->getColorId(), $previous1);
            }
            $this->failureMapper->update($failure);
        }

        return $this->redirect()->toUrl($this->url()->fromRoute('admin/failures', array('lang' => $this->lang, 'color_id' => $failure->getColorId())));
    }

    public function deleteAction()
    {
        $failureId = $this->params()->fromRoute('failure_id', 0);
        $failure   = $this->failureMapper->findById($failureId);
        if ($failure) {
            $colorId = $failure->getColorId();
            $this->failureMapper->delete($failure);
            return $this->redirect()->toUrl($this->url()->fromRoute('admin/failures', array('lang' => $this->lang, 'color_id' => $colorId)));
        }

        return $this->redirect()->toUrl($this->url()->fromRoute('admin', array('lang' => $this->lang)));
    }

    /**
     * Constructor to inject variables uses everywhere
     */
    protected $failureMapper;
    protected $failureLangMapper;  
    protected $failureForm;
    protected $failureLangForm; 
    protected $colorMapper;
    protected $modelMapper;
    protected $brandMapper;  
    protected $lang;
    protected $langId;
    public function __construct($failureMapper = null, $failureLangMapper = null, $failureForm = null, $failureLangForm = null, $colorMapper = null, $modelMapper = null, $brandMapper = null,  $lang = null, $langId = null)
    {
        if (!is_null($failureMapper)) {
            $this->failureMapper = $failureMapper;
        }

        if (!is_null($failureLangMapper)) {
            $this->failureLangMapper = $failureLangMapper;
        }

        if (!is_null($failureForm)) {
            $this->failureForm = $failureForm;
        }

        if (!is_null($failureLangForm)) {
            $this->failureLangForm = $failureLangForm;
        }

        if (!is_null($colorMapper)) {
            $this->colorMapper = $colorMapper;
        }

        if (!is_null($modelMapper)) {
            $this->modelMapper = $modelMapper;
        }

        if (!is_null($brandMapper)) {
            $this->brandMapper = $brandMapper;
        }

        if (!is_null($lang)) {
            $this->lang = $lang;
        }

        if (!is_null($langId)) {
            $this->langId = $langId;
        }
    }
}
