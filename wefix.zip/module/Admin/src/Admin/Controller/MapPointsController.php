<?php

namespace Admin\Controller;

use Application\Entity\MapPoint;
use Zend\Http\Response;
use Zend\Mvc\Controller\AbstractActionController;

class MapPointsController extends AbstractActionController
{

    /**
     * List the map points.
     *
     * @return array
     */
    public function listAction()
    {
        $list = $this->getServiceLocator()->get('mappoint_mapper')->fetchAll();

        return array(
            'list' => $list,
        );
    }

    /**
     * @return array
     */
    public function editAction()
    {
        $form = $this->getServiceLocator()->get('mappoint_form');
        $request = $this->getRequest();

        $id = (int) $this->params()->fromRoute('id', 0);
        $mapper = $this->getServiceLocator()->get('mappoint_mapper');
        $mapPoint = $mapper->findById($id);
        if (!$mapPoint) {
            $mapPoint = new MapPoint();
            $mapPoint->setId(0);
        }
        $form->bind($mapPoint);
        $form->get('dateOpen')->setValue($mapPoint->getDateOpen());
        if ($request->isPost()) {
            $form->setData($request->getPost());
            if ($form->isValid()) {
                $mapPoint = $form->getData();
                if (empty($mapPoint->getId())) {
                    $mapper->insert($mapPoint);
                } else {
                    $mapper->update($mapPoint);
                }

                return $this->redirect()->toUrl($this->url()->fromRoute('admin/mappoint', array('lang' => $this->params()->fromRoute('lang'))));
            }
        }

        return array(
            'form' => $form,
        );
    }

    /**
     * @return Response
     */
    public function deleteAction()
    {
        $id = $this->params()->fromRoute('id', 0);
        $mapper = $this->getServiceLocator()->get('mappoint_mapper');
        $mapPoint = $mapper->findById($id);
        if ($mapPoint) {
            $this->getServiceLocator()->get('mappoint_mapper')->delete($mapPoint);
        }

        return $this->redirect()->toUrl($this->url()->fromRoute('admin/mappoint', array('lang' => $this->params()->fromRoute('lang'))));
    }

}
