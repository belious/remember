<?php

namespace Admin\Controller;

use Zend\Mvc\Controller\AbstractActionController;

class ModelsController extends AbstractActionController
{
    public function listAction()
    {
        $brandId     = $this->params()->fromRoute('brand_id', 0);
        $brandMapper = $this->getServiceLocator()->get('brand_mapper');
        $brand       = $brandMapper->findById($brandId);
        $deviceId    = $brand->getDeviceId();

        $request = $this->getRequest();
        if ($request->isPost()) {
            $data = array_merge_recursive($request->getFiles()->toArray(), $this->getRequest()->getPost()->toArray());

            if ($data['name']) { 
                $this->modelForm->setData($data);

                if ($this->modelForm->isValid()) {
                    $modelData = $this->modelForm->getData();
                    $model = $this->modelMapper->findById($modelData['id']);
                    $model->setName($modelData['name']);

                    if (isset($modelData['picture']) && $modelData['picture']['error'] == 0) {
                        $adapter = new \Zend\File\Transfer\Adapter\Http();
                        $adapter->addFilter('File\Rename',array(
                            'source' => $data['picture']['tmp_name'],
                            'target' => $this->getServiceLocator()->get('Config')['static_path'].'/upload/model-'.$model->getId().'.png',
                            'overwrite' => true
                        ));
                        $adapter->receive();
                        $model->setImageUrl($this->getServiceLocator()->get('Config')['static_url'].'/upload/model-'.$model->getId().'.png');
                    }

                    $this->modelMapper->update($model);

                    return $this->redirect()->toUrl($this->url()->fromRoute('admin/models', array('lang' => $this->lang, 'brand_id' => $brand->getId())));
                }
            } else if ($data['titre']) {
                $this->modelLangForm->setData($data);
                if ($this->modelLangForm->isValid()) {
                    $modelData = $this->modelLangForm->getData();
                    $modelLang = $this->modelLangMapper->findByModelAndLang($modelData['model_id'], $modelData['lang_id']);
                    $modelLang->setTitre($modelData['titre']);
                    $modelLang->setDescription($modelData['description']);
                    $modelLang->setTopDesc($modelData['top_desc']);
                    $modelLang->setBottomDesc($modelData['bottom_desc']);
                    $this->modelLangMapper->update($modelLang);
                }
                return $this->redirect()->toUrl($this->url()->fromRoute('admin/models', array('lang' => $this->lang, 'brand_id' => $brand->getId())));
            }
        }

        $modelList = $this->modelMapper->findByBrandId($brand->getId());

        return (array('brand' => $brand, 'deviceId' => $deviceId, 'modelForm' => $this->modelForm, 'modelList' => $modelList));
    }

    public function addAction()
    {
        $brandId     = $this->params()->fromRoute('brand_id', 0);
        $brandMapper = $this->getServiceLocator()->get('brand_mapper');
        $brand       = $brandMapper->findById($brandId);
        $deviceId    = $brand->getDeviceId();

        $request = $this->getRequest();
        if ($request->isPost()) {  
            $data = array_merge_recursive($request->getFiles()->toArray(), $this->getRequest()->getPost()->toArray());
            $this->modelForm->setData($data);

            if ($this->modelForm->isValid()) {
                $modelData = $this->modelForm->getData();
                $model = new \Application\Entity\Model();
                $lastBrand = $brandMapper->findLast($brandId);

                if ($lastBrand) {
                    $model->setTop($lastBrand->getTop() - 1);
                } else {
                    $model->setTop(0);
                }

                $model->setName($modelData['name']);
                $model->setBrandId($brandId);
                $model->setId(null);
                $this->modelMapper->insert($model);

                $uniqueEntryService = $this->getServiceLocator()->get('UniqueEntryUrl');
                $model->setUrl(
                    $uniqueEntryService->generate(
                        $this->modelMapper->getTableName(),
                        'url',
                        $model->getName(), array('field' => 'id', 'value' => $model->getId())
                    )
                );

                if ($modelData['picture']['error'] == 0) {
                    $adapter = new \Zend\File\Transfer\Adapter\Http();
                    $adapter->addFilter('File\Rename',array(
                        'source' => $data['picture']['tmp_name'],
                        'target' => $this->getServiceLocator()->get('Config')['static_path'].'/upload/model-'.$model->getId().'.png',
                        'overwrite' => true
                    ));
                    $adapter->receive();
                    $model->setImageUrl($this->getServiceLocator()->get('Config')['static_url'].'/upload/model-'.$model->getId().'.png');
                    $this->modelMapper->update($model);
                }

                foreach ($this->getServiceLocator()->get('Config')['translation']['available'] as $configuredLang) {
                    $modelLang = new \Application\Entity\ModelLang();
                    $modelLang->setTitre('');
                    $modelLang->setDescription('');
                    $modelLang->setTopDesc('');
                    $modelLang->setBottomDesc('');
                    $modelLang->setModelId($model->getId());
                    $modelLang->setLangId($this->getServiceLocator()->get('lang_mapper')->findByLang($configuredLang)->getId());
                    $this->modelLangMapper->insert($modelLang);
                }

                return $this->redirect()->toUrl($this->url()->fromRoute('admin/models', array('lang' => $this->lang, 'brand_id' => $brand->getId())));
            } else {
                return (array('brand' => $brand, 'model' => $model, 'deviceId' => $deviceId, 'form' => $this->modelForm));
            }        
        } else {
            $this->modelForm->setAttributes(array(
                'action' => $this->url()->fromRoute('admin/models/add', array(
                    'brand_id' => $brandId,
                    'lang' => $this->lang
                )),
            ));

            $this->modelForm->setHydrator(new \Zend\Stdlib\Hydrator\ClassMethods());

            return (array('brand' => $brand, 'model' => $model, 'deviceId' => $deviceId, 'form' => $this->modelForm));
        }   
    }

    public function editAction()
    {
        $modelId     = $this->params()->fromRoute('model_id');
        $brandMapper = $this->getServiceLocator()->get('brand_mapper');
        $model       = $this->modelMapper->findById($modelId);

        if (!$model) {
            return $this->redirect()->toUrl($this->url()->fromRoute('admin', array('lang' => $this->lang)));
        }

        $brand = $brandMapper->findById($model->getBrandId());
        $deviceId = $brand->getDeviceId();

        $this->modelForm->setAttributes(array(
            'action' => $this->url()->fromRoute('admin/models', array(
                'brand_id' => $brand->getId(),
                'lang' => $this->lang
            )),
        ));

        $this->modelForm->setHydrator(new \Zend\Stdlib\Hydrator\ClassMethods());
        $this->modelForm->bind($model);

        return (array('brand' => $brand, 'model' => $model, 'deviceId' => $deviceId, 'form' => $this->modelForm));
    }

    public function editlangAction()
    {
        $modelId     = $this->params()->fromRoute('model_id');
        $brandMapper = $this->getServiceLocator()->get('brand_mapper');
        $model       = $this->modelMapper->findById($modelId);
        $modelLang   = $this->modelLangMapper->findByModelAndLang($modelId, $this->langId);

        if (!$modelLang) {
            return $this->redirect()->toUrl($this->url()->fromRoute('admin', array('lang' => $this->lang)));
        }
        $brand    = $brandMapper->findById($model->getBrandId());
        $deviceId = $brand->getDeviceId();

        $this->modelLangForm->setAttributes(array(
            'action' => $this->url()->fromRoute('admin/models', array(
                'brand_id' => $brand->getId(),
                'lang' => $this->lang
            )),
        ));
        $this->modelLangForm->setHydrator(new \Zend\Stdlib\Hydrator\ClassMethods());
        $this->modelLangForm->bind($modelLang);

        return (array('brand' => $brand, 'model' => $model, 'deviceId' => $deviceId, 'form' => $this->modelLangForm));
    }

    public function starAction()
    {
        $id          = $this->params()->fromRoute('id', 0);
        $brandMapper = $this->getServiceLocator()->get('model_mapper');
        $brand       = $brandMapper->findById($id);

        if ($brand) {
            $next = $brandMapper->fetchNext($brand->getTop(), $brand->getBrandId());
            // We are the first
            if (!$next->count()) {
                // nothing
            } elseif ($next->count() == 1) { // We are behind the first
                $brand->setTop($next->current()->getTop() + 1);
            } else { // We are far and there are at least 2 brands on top of us
                $next1 = $next->current();
                $brand->setTop($next1->getTop() + 1);
                $brandMapper->addTopFrom($brand->getBrandId(), $next1);
            }
            $brandMapper->update($brand);
        }
        return $this->redirect()->toUrl($this->url()->fromRoute('admin/models', array('lang' => $this->lang, 'brand_id' => $brand->getBrandId())));
    }

    public function downAction()
    {
        $id          = $this->params()->fromRoute('id', 0);
        $brandMapper = $this->getServiceLocator()->get('model_mapper');
        $brand       = $brandMapper->findById($id);

        if ($brand) {
            $previous = $brandMapper->fetchPrevious($brand->getTop(), $brand->getBrandId());
            // We are the first
            if (!$previous->count()) {
                // nothing
            } elseif ($previous->count() == 1) { // We are before the last
                $brand->setTop($previous->current()->getTop() - 1);
            } else { // We are far and there are at least 2 brands on top of us
                $previous1 = $previous->current();
                $brand->setTop($previous1->getTop() - 1);
                $brandMapper->downTopFrom($brand->getBrandId(), $previous1);
            }

            $brandMapper->update($brand);
        }

        return $this->redirect()->toUrl($this->url()->fromRoute('admin/models', array('lang' => $this->lang, 'brand_id' => $brand->getBrandId())));
    }

    public function deleteAction()
    {
        $modelId     = $this->params()->fromRoute('model_id', 0);
        $modelMapper = $this->getServiceLocator()->get('model_mapper');
        $model       = $modelMapper->findById($modelId);

        if ($model) {
            $brandId     = $model->getBrandId();
            $colorMapper = $this->getServiceLocator()->get('color_mapper');
            $colorList   = $colorMapper->findByModelId($modelId);

            foreach ($colorList as $color) {
                $this->forward()->dispatch('Colors', array(
                    'action' => 'delete',
                    'model_id' => $modelId,
                    'color_id' => $color->getId(),
                ));
            }

            $modelMapper->delete($model);
            return $this->redirect()->toUrl($this->url()->fromRoute('admin/models', array('lang' => $this->lang, 'brand_id' => $brandId)));
        }

        return $this->redirect()->toUrl($this->url()->fromRoute('admin', array('lang' => $this->lang)));
    }

    /**
     * Constructor to inject variables uses everywhere
     */
    protected $modelLangMapper;
    protected $modelMapper;
    protected $modelLangForm;
    protected $modelForm;
    protected $lang;
    protected $langId;
    protected $brandId;
    public function __construct($modelLangMapper = null, $modelMapper = null, $modelLangForm = null, $modelForm = null, $lang = null, $langId = null, $brandId = null)
    {
        if (!is_null($modelLangMapper)) {
            $this->modelLangMapper = $modelLangMapper;
        }

        if (!is_null($modelMapper)) {
            $this->modelMapper = $modelMapper;
        }

        if (!is_null($modelLangForm)) {
            $this->modelLangForm = $modelLangForm;
        }

        if (!is_null($modelForm)) {
            $this->modelForm = $modelForm;
        }

        if (!is_null($lang)) {
            $this->lang = $lang;
        }

        if (!is_null($langId)) {
            $this->langId = $langId;
        }

        if (!is_null($brandId)) {
            $this->brandId = $brandId;
        }
    }
}
