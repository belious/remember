<?php

namespace Admin\Controller;

use Zend\Mvc\Controller\AbstractActionController;

class OrdersController extends AbstractActionController
{
    public function listAction()
    {
        $searchOrderForm = $this->getServiceLocator()->get('search_order_form');
        $orderMapper = $this->getServiceLocator()->get('order_mapper');

        $request = $this->getRequest();
        if ($request->isPost()) {
            $searchOrderForm->setData($request->getPost());
            if ($searchOrderForm->isValid()) {
                $formData = $searchOrderForm->getData();
                $order = $orderMapper->findById($formData['id']);
                if ($order) {
                    return $this->redirect()->toUrl($this->url()->fromRoute('admin/orders/edit', array('lang' => $this->params()->fromRoute('lang'), 'order_id' => $order->getId())));
                }
            }
        }

        $orderToCall = $orderMapper->findByState('A appeler');
        $orderToMail = $orderMapper->findByState('A mailer');
        $orderToRepare = $orderMapper->findByState('A reparer');
        $orderShouldPay = $orderMapper->findByState('Doit payer');
        $orderToRetry = $orderMapper->findByState('A relancer');

        return (array('searchForm' => $searchOrderForm, 'orderToCall' => $orderToCall, 'orderToMail' => $orderToMail, 'orderToRetry' => $orderToRetry, 'orderToRepare' => $orderToRepare, 'orderShouldPay' => $orderShouldPay));
    }

    public function editAction()
    {
        $orderId = $this->params()->fromRoute('order_id');
        $request = $this->getRequest();

        $editOrderForm = $this->getServiceLocator()->get('edit_order_form');
        $orderMapper = $this->getServiceLocator()->get('order_mapper');
        $orderFailureMapper = $this->getServiceLocator()->get('order_failure_mapper');
        $postalMapper = $this->getServiceLocator()->get('postal_code_mapper');

        $order = $orderMapper->findById($orderId);
        if ($order) {
            $orderFailure = $orderFailureMapper->findByOrderId($order->getId());

            $postalCode = $postalMapper->findByPostalCode($order->getPostal());

            $repaType = 'Express';
            if ($postalCode) {
                $repaType = 'Domicile';
            }

            $editOrderForm->bind($order);

            if ($request->isPost()) {
                $editOrderForm->setData($request->getPost());
                if ($editOrderForm->isValid()) {
                    $orderMapper->update($order);
                }
            }

            return (array('order' => $order, 'repaType' => $repaType, 'orderFailure' => $orderFailure, 'orderForm' => $editOrderForm));
        }

        return $this->redirect()->toUrl($this->url()->fromRoute('admin/orders', array('lang' => $this->params()->fromRoute('lang'))));
    }

    public function repairAction()
    {
        $orderFailureMapper = $this->getServiceLocator()->get('order_failure_mapper');

        $repairForm = $this->getServiceLocator()->get('repair_form');

        $orderId = $this->params()->fromRoute('order_id');
        $repairId = $this->params()->fromRoute('repair_id');

        $orderFailure = $orderFailureMapper->findById($repairId);
        if ($orderFailure) {
            $repairForm->bind($orderFailure);
        } else {
            $orderFailure = new \Application\Entity\OrderFailure();
            $orderFailure->setOrderId($orderId);
            $repairForm->bind($orderFailure);
        }

        $request = $this->getRequest();
        if ($request->isPost()) {
            $repairForm->setData($request->getPost());

            $data = $request->getPost()->toArray();
            if (isset($data['id']) && $data['id'] == 0) {
                $repairForm->getInputFilter()->get('id')->setRequired(false);
            }

            if ($repairForm->isValid()) {
                if ($orderFailure->getId()) {
                    $orderFailureMapper->update($orderFailure);
                } else {
                    $orderFailure->setFailureId(0);
                    $orderFailureMapper->insert($orderFailure);
                }

                return $this->redirect()->toUrl($this->url()->fromRoute('admin/orders/edit', array('lang' => $this->params()->fromRoute('lang'), 'order_id' => $orderId)));
            }
        }

        return (array('repairForm' => $repairForm, 'orderId' => $orderId));
    }

    public function deleteRepairAction()
    {
        $repairId = $this->params()->fromRoute('repair_id');
        $orderId = $this->params()->fromRoute('order_id');

        $orderFailureMapper = $this->getServiceLocator()->get('order_failure_mapper');
        $orderFailure = $orderFailureMapper->findById($repairId);
        if ($orderFailure) {
            $orderFailureMapper->delete($orderFailure);
        }

        return $this->redirect()->toUrl($this->url()->fromRoute('admin/orders/edit', array('lang' => $this->params()->fromRoute('lang'), 'order_id' => $orderId)));
    }

    public function chronopostAction()
    {
        $orderId = $this->params()->fromRoute('order_id');

        $orderMapper = $this->getServiceLocator()->get('order_mapper');

        $order = $orderMapper->findById($orderId);
        if ($order) {
            try {
                $chronopost = new \Zend\Soap\Client('https://www.chronopost.fr/shipping-cxf/ShippingServiceWS?wsdl');
                $basicInfos = array('subAccount' => '000', 'accountNumber' => '24741002', 'password' => '238831', 'shipperCivility' => 'M', 'shipperName' => 'Société ASP', 'shipperAdress1' => '21 bd Ney', 'shipperZipCode' => '75018', 'shipperCity' => 'Paris', 'shipperCountry' => 'FR', 'shipperCountryName' => 'France', 'shipperContactName' => 'Edouard Menantaud', 'shipperEmail' => 'contact@wefix.net', 'shipperPhone' => '0145747814', 'shipperMobilePhone' => '0624625111', 'recipientCivility' => 'M', 'recipientCountry' => 'FR', 'recipientCountryName' => 'France', 'recipientContactName' => $order->getFirstName().' '.$order->getLastName(), 'recipientEmail' => $order->getMail(), 'recipientPhone' => $order->getPhone(), 'recipientMobilePhone' => $order->getPhone(), 'recipientPreAlert' => '22', 'shipperRef' => $order->getId(), 'productCode' => '01', 'shipDate' => date('d/m/Y G:00:00'), 'shipHour' => date('G'), 'weight' => '0.5', 'service' => '0', 'objectType' => 'MAR', 'modeRetour' => '1');

                if ($order->getPointRelais()) {
                    $chronopostRelais = new \Zend\Soap\Client('https://www.chronopost.fr/recherchebt-ws-cxf/PointRelaisServiceWS?wsdl');
                    $pointRelais = $chronopostRelais->rechercheDetailPointChronopost(array('accountNumber' => '24741002', 'password' => '238831', 'identifiant' => $order->getPointRelais()))->return->listePointRelais;

                    $finalInfos = array_merge($basicInfos, array('recipientName' => $pointRelais->nom, 'recipientName2' => $order->getLastName().' '.$order->getFirstName(), 'recipientAdress1' => $pointRelais->adresse1, 'recipientZipCode' => $pointRelais->codePostal, 'recipientCity' => $pointRelais->localite));
                } else {
                    $address = explode("\n", wordwrap($order->getAddress(), 38));
                    $finalInfos = array_merge($basicInfos, array('recipientName' => $order->getLastName(), 'recipientName2' => $order->getFirstName(), 'recipientAdress1' => $address[0], 'recipientAdress2' => (isset($address[1]) ? $address[1] : ''), 'recipientZipCode' => $order->getPostal(), 'recipientCity' => $order->getCity()));
                }

                $chronopost->shippingWithReservationAndESDWithRefClientPC($finalInfos);
            } catch (\SoapFault $e) {
                mail('gdc.assistance@gmail.com', 'soap fault WeFIX', implode('|', $finalInfos));
            }
        }

        return $this->redirect()->toUrl($this->url()->fromRoute('admin/orders/edit', array('lang' => $this->params()->fromRoute('lang'), 'order_id' => $orderId)));
    }
}
