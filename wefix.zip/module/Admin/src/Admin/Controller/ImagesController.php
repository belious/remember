<?php
/**
 * This file is part of the Ayruu package.
 *
 * @author Bogdan SOOS <bogdan.soos@dynweb.org>
 * @created 10/08/16 16:18
 * @version 1.0
 * @license All rights reserved
 */
namespace Admin\Controller;

use Zend\Mvc\Controller\AbstractActionController;

class ImagesController extends AbstractActionController
{
    /**
     * @return array
     */
    public function listAction()
    {
        $imagesMapper = $this->getServiceLocator()->get('images_mapper');

        $imagesForm = $this->getServiceLocator()->get('images_form');

        $request = $this->getRequest();

        if ($request->isPost()) {
            $data = array_merge_recursive($request->getFiles()->toArray(), $this->getRequest()->getPost()->toArray());
            $imagesForm->setData($data);
            if ($imagesForm->isValid()) {
                $imageData = $data;
                $image = new \Application\Entity\Image();
                if (empty($imageData['id'])){
                    unset($imageData['id']);
                }

                if (!empty($imageData['lang']) && !empty($imageData['id'])) {
                    /** @var \Application\Entity\Image $image */
                    $image = $imagesMapper->findByLang($imageData['lang']);
                    $image->setName($imageData['name']);
                    $image->setLang($imageData['lang']);
                    $image->setId($imageData['id']);
                    $imagesMapper->update($image);
                } else {
                    $image->setName($imageData['name']);
                    $image->setLang($imageData['lang']);
                    $imagesMapper->insert($image);
                }
                if (isset($imageData['image']) && $imageData['image']['error'] == 0) {
                    if (copy($imageData['image']['tmp_name'], $this->getServiceLocator()->get('Config')['static_path'].'/upload/background-' . $image->getId().'.jpg')) {
                        $image->setUrl($this->getServiceLocator()->get('Config')['static_url'].'/upload/background-'.$image->getId().'.jpg');

                        $imagesMapper->update($image);
                    }
                }
                return $this->redirect()->toUrl($this->url()->fromRoute('admin/images', array('lang' => $this->params()->fromRoute('lang'))));
            }
        }

        $imagesList = $imagesMapper->fetchAll();

        return [
            'imagesList' => $imagesList,
            'form' => $imagesForm
        ];
    }

    public function deleteAction()
    {
        $id = $this->params()->fromRoute('id', 0);
        $imagesMapper = $this->getServiceLocator()->get('images_mapper');

        $picto = $imagesMapper->findById($id);
        if ($picto) {
            $imagesMapper->delete($picto);
        }

        return $this->redirect()->toUrl($this->url()->fromRoute('admin/images', array('lang' => $this->params()->fromRoute('lang'))));
    }
}