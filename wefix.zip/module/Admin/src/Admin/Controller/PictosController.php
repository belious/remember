<?php

namespace Admin\Controller;

use Zend\Mvc\Controller\AbstractActionController;

class PictosController extends AbstractActionController
{
    public function listAction()
    {
        $pictoMapper = $this->getServiceLocator()->get('picto_mapper');
        $pictoForm = $this->getServiceLocator()->get('picto_form');

        $request = $this->getRequest();
        if ($request->isPost()) {
            $data = array_merge_recursive($request->getFiles()->toArray(), $this->getRequest()->getPost()->toArray());
            $pictoForm->setData($data);
            if ($pictoForm->isValid()) {
                $pictoData = $pictoForm->getData();

                $picto = new \Application\Entity\Picto();
                $picto->setName($pictoData['name']);

                $pictoMapper->insert($picto);

                if (copy($pictoData['picture']['tmp_name'], $this->getServiceLocator()->get('Config')['static_path'].'/upload/picto-'.$picto->getId().'.png')) {
                    $picto->setImageUrl($this->getServiceLocator()->get('Config')['static_url'].'/upload/picto-'.$picto->getId().'.png');
                    $pictoMapper->update($picto);
                } else {
                    $pictoMapper->delete($picto);
                }
            }
        }

        $pictoList = $pictoMapper->fetchAll();

        return (array('pictoList' => $pictoList, 'pictoForm' => $pictoForm));
    }

    public function deleteAction()
    {
        $id = $this->params()->fromRoute('id', 0);
        $pictoMapper = $this->getServiceLocator()->get('picto_mapper');
        $failureMapper = $this->getServiceLocator()->get('failure_mapper');
        $picto = $pictoMapper->findById($id);
        if ($picto) {
            $pictoMapper->delete($picto);
            $failureList = $failureMapper->findByPictoId($id);
            foreach ($failureList as $failure) {
                $failure->setPictoId(0);
                $failureMapper->update($failure);
            }
        }

        return $this->redirect()->toUrl($this->url()->fromRoute('admin/pictos', array('lang' => $this->params()->fromRoute('lang'))));
    }
}
