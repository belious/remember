<?php

namespace Admin\Controller;

use Zend\Mvc\Controller\AbstractActionController;

class DevicesController extends AbstractActionController
{
    public function listAction()
    {
        $deviceList = $this->deviceLangMapper->fetchAllByLang($this->langId);

        $request = $this->getRequest();
        if ($request->isPost()) {
            $data = array_merge_recursive($request->getFiles()->toArray(), $this->getRequest()->getPost()->toArray());

            if (isset($data['name']) && $data['name'] != '') {
                $this->deviceLangForm->setData($data);

                if ($this->deviceLangForm->isValid()) {
                    $deviceLangData = $this->deviceLangForm->getData();
                    $deviceLang = new \Application\Entity\DeviceLang();

                    if ($deviceLangData['device_id'] != 0 && $deviceLangData['lang_id'] != 0) {
                        $deviceLang = $this->deviceLangMapper->findByDeviceAndLang($deviceLangData['device_id'], $deviceLangData['lang_id']);
                        $deviceLang->setName($deviceLangData['name']);
                        $deviceLang->setDeviceType($deviceLangData['device_type']);
                        $deviceLang->setDescription($deviceLangData['description']);
                        $deviceLang->setTopDesc($deviceLangData['top_desc']);    
                        $this->deviceLangMapper->update($deviceLang);                    
                    }
                }
            } 
        }

        return (array('deviceList' => $deviceList));
    }

    public function editAction()
    {
        $deviceId = $this->params()->fromRoute('device_id');
        $deviceLang = $this->deviceLangMapper->findByDeviceAndLang($deviceId, $this->langId);

        if (!$deviceLang) {
            return $this->redirect()->toUrl($this->url()->fromRoute('admin', array('lang' => $this->lang)));
        }

        $this->deviceLangForm = $this->getServiceLocator()->get('device_lang_form');

        $this->deviceLangForm->setAttributes(array(
            'action' => $this->url()->fromRoute('admin/devices', array(
                'lang' => $this->lang
            )),
        ));

        $this->deviceLangForm->setHydrator(new \Zend\Stdlib\Hydrator\ClassMethods());
        $this->deviceLangForm->bind($deviceLang);

        return (array(
            'deviceLang' => $deviceLang,
            'deviceLangForm' => $this->deviceLangForm
        ));
    }

    /**
     * Constructor to inject variables uses everywhere
     */
    protected $deviceLangMapper;
    protected $deviceMapper;
    protected $deviceLangForm;
    protected $deviceForm;
    protected $lang;
    protected $langId;
    public function __construct($deviceLangMapper = null, $deviceMapper = null, $deviceLangForm = null, $deviceForm = null, $lang = null, $langId = null)
    {
        if (!is_null($deviceLangMapper)) {
            $this->deviceLangMapper = $deviceLangMapper;
        }

        if (!is_null($deviceMapper)) {
            $this->deviceMapper = $deviceMapper;
        }

        if (!is_null($deviceLangForm)) {
            $this->deviceLangForm = $deviceLangForm;
        }

        if (!is_null($deviceForm)) {
            $this->deviceForm = $deviceForm;
        }

        if (!is_null($lang)) {
            $this->lang = $lang;
        }

        if (!is_null($langId)) {
            $this->langId = $langId;
        }
    }
}
