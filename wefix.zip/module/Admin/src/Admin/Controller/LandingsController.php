<?php

namespace Admin\Controller;

use Zend\Mvc\Controller\AbstractActionController;

class LandingsController extends AbstractActionController
{
    public function listAction()
    {
        $landingPageMapper = $this->getServiceLocator()->get('landing_page_mapper');
        $resultsList = $landingPageMapper->fetchAll();

        $landingPageForm = $this->getServiceLocator()->get('landing_page_form');

        $request = $this->getRequest();
        if ($request->isPost()) {
            $data = array_merge_recursive($request->getFiles()->toArray(), $request->getPost()->toArray());
            $landingPageForm->setData($data);

            if (isset($data['id']) && $data['id'] != 0) {
                $landingPageForm->getInputFilter()->get('image')->setRequired(false);
            }

            if ($landingPageForm->isValid()) {
                $landingPageData = $landingPageForm->getData();

                $landingPage = new \LandingPage\Entity\LandingPage();

                if ($landingPageData['id'] != 0) {
                    $landingPage = $landingPageMapper->findById($landingPageData['id']);
                }

                $landingPage->setId($landingPageData['id']);
                $landingPage->setNom($landingPageData['nom']);
                $landingPage->setHtml1($landingPageData['html1']);
                $landingPage->setSousTitre($landingPageData['sous_titre']);
                $landingPage->setVitreTactile($landingPageData['vitre_tactile']);
                $landingPage->setEcranLcd($landingPageData['ecran_lcd']);
                $landingPage->setBoutonHome($landingPageData['bouton_home']);
                $landingPage->setAppareilPhotoAvant($landingPageData['appareil_photo_avant']);
                $landingPage->setAppareilPhoto($landingPageData['appareil_photo']);
                $landingPage->setFacadeArriere($landingPageData['facade_arriere']);
                $landingPage->setVitreArriere($landingPageData['vitre_arriere']);
                $landingPage->setBatterie($landingPageData['batterie']);
                $landingPage->setConnecteurCharge($landingPageData['connecteur_charge']);
                $landingPage->setPriseCasque($landingPageData['prise_casque']);
                $landingPage->setBoutonOnOff($landingPageData['bouton_on_off']);
                $landingPage->setVibreur($landingPageData['vibreur']);
                $landingPage->setMicro($landingPageData['micro']);
                $landingPage->setHautParleur($landingPageData['micro']);
                $landingPage->setEcouteurInterne($landingPageData['ecouteur_interne']);
                $landingPage->setAntenne($landingPageData['antenne']);
                $landingPage->setWifi($landingPageData['wifi']);
                $landingPage->setBoutonsVolume($landingPageData['boutons_volume']);
                $landingPage->setHublotAppareilPhoto($landingPageData['hublot_appareil_photo']);
                $landingPage->setAutre($landingPageData['autre']);
                $landingPage->setUrl($landingPageData['url']);

                if ($landingPageData['id'] == 0) {
                    $landingPage->setId(null);
                    $landingPageMapper->insert($landingPage);
                } else {
                    $landingPageMapper->update($landingPage);
                }

                if (isset($landingPageData['image']) && $landingPageData['image']['error'] == 0) {
                    if (copy($landingPageData['image']['tmp_name'], $this->getServiceLocator()->get('Config')['static_path'].'/upload/landing-'.$landingPage->getId().'.png')) {
                        $landingPage->setImageUrl($this->getServiceLocator()->get('Config')['static_url'].'/upload/landing-'.$landingPage->getId().'.png');
                        $landingPageMapper->update($landingPage);
                    } elseif ($landingPageData['id'] == 0) {
                        $landingPageMapper->delete($landingPage);
                    }
                }

                if ($landingPageData['id'] != 0) {
                    return $this->redirect()->toUrl($this->url()->fromRoute('admin/landing', array('lang' => $this->params()->fromRoute('lang'))));
                }
            }
        }

        return array('resultsList' => $resultsList, 'form' => $landingPageForm);
    }

    public function editAction()
    {
        $landingPageMapper = $this->getServiceLocator()->get('landing_page_mapper');
        $landingPageId = $this->params()->fromRoute('landing_id');

        $landingPage = $landingPageMapper->findById($landingPageId);
        if (!$landingPage) {
            return $this->notFoundAction();
        }

        $landingPageForm = $this->getServiceLocator()->get('landing_page_form');

        $landingPageForm->setAttributes(array(
            'action' => $this->url()->fromRoute('admin/landing', array('lang' => $this->params()->fromRoute('lang'))),
        ));

        $landingPageForm->setHydrator(new \Zend\Stdlib\Hydrator\ClassMethods());
        $landingPageForm->bind($landingPage);

        return (array('landingPage' => $landingPage, 'landingPageForm' => $landingPageForm));
    }

    public function deleteAction()
    {
        $landingPageMapper = $this->getServiceLocator()->get('landing_page_mapper');
        $landingPageId = $this->params()->fromRoute('landing_id');

        $landingPage = $landingPageMapper->findById($landingPageId);
        if ($landingPage) {
            $landingPageMapper->remove($landingPage);
        }

        return $this->redirect()->toRoute('admin/landing');
    }
}
