<?php

namespace Admin\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Application\Entity\FeaturedFailure;

class FeaturedFailureController extends AbstractActionController
{

    public function listAction()
    {
        $list = $this->getServiceLocator()->get('featured_failure_mapper')->fetchAll();

        return array(
            'list' => $list,
        );
    }

    public function editAction()
    {
        $form = $this->getServiceLocator()->get('featured_failure_form');
        $request = $this->getRequest();

        $failureMapper = $this->getServiceLocator()->get('failure_mapper');
        $failures = $failureMapper->fetchAllWithDetails();
        $options = array();
        foreach ($failures as $failure) {
            $options[$failure->getId()] = $failure->getModelName() . ' ' . $failure->getName();
        }
        $form->get('failureId')->setValueOptions($options);

        $id = (int) $this->params()->fromRoute('id', 0);
        $mapper = $this->getServiceLocator()->get('featured_failure_mapper');
        $featured = $mapper->findById($id);
        if (!$featured) {
            $featured = new FeaturedFailure();
            $featured->setId(0);
        } else {
            $form->getInputFilter()->remove('picture');
        }
        $form->get('failureId')->setValue($featured->getFailureId());
        $form->bind($featured);

        if ($request->isPost()) {
            $data = array_merge_recursive($request->getFiles()->toArray(), $request->getPost()->toArray());
            $form->setData($data);

            if ($form->isValid()) {
                $featured = $form->getData();
                $featured->setFailureId($data['failureId']);
                if (empty($featured->getId())) {
                    $mapper->insert($featured);
                } else {
                    $mapper->update($featured);
                }

                //update file
                if (isset($data['picture']) && $data['picture']['error'] == 0) {
                    $ext = pathinfo($data['picture']['name'], PATHINFO_EXTENSION);
                    $dirpath = $this->getServiceLocator()->get('Config')['static_path'] . '/upload/featured';
                    $dirUrl = $this->getServiceLocator()->get('Config')['static_url'] . '/upload/featured';
                    if (!is_dir($dirpath)) {
                        mkdir($dirpath, 0777, true);
                    }
                    $copy = copy($data['picture']['tmp_name'], $dirpath . '/featured-' . $featured->getId() . '.' . $ext);
                    if ($copy) {
                        $featured->setImageUrl($dirUrl . '/featured-' . $featured->getId() . '.' . $ext);
                        $mapper->update($featured);
                    } elseif ($data['id'] == 0) {
                        $mapper->delete($featured);
                    }
                }

                return $this->redirect()->toUrl($this->url()->fromRoute('admin/featured', array('lang' => $this->params()->fromRoute('lang'))));
            }
        }

        return array(
            'form' => $form,
        );
    }

    public function deleteAction()
    {
        $id = $this->params()->fromRoute('id', 0);
        $sliderMapper = $this->getServiceLocator()->get('featured_failure_mapper');
        $slider = $sliderMapper->findById($id);
        if ($slider) {
            $sliderMapper->delete($slider);
        }

        return $this->redirect()->toUrl($this->url()->fromRoute('admin/featured', array('lang' => $this->params()->fromRoute('lang'))));
    }

}
