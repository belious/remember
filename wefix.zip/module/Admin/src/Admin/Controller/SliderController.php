<?php

namespace Admin\Controller;

use Application\Entity\Slider;
use Zend\Mvc\Controller\AbstractActionController;

class SliderController extends AbstractActionController
{

    public function listAction()
    {
        $list = $this->getServiceLocator()->get('slider_mapper')->fetchAll();

        return array(
            'list' => $list,
        );
    }

    public function editAction()
    {
        $form = $this->getServiceLocator()->get('slider_form');
        $request = $this->getRequest();

        $id = (int) $this->params()->fromRoute('id', 0);
        $mapper = $this->getServiceLocator()->get('slider_mapper');
        $slider = $mapper->findById($id);

        if (!$slider) {
            $slider = new Slider();
            $slider->setId(0);
        } else {
            $form->getInputFilter()->remove('picture');
        }

        $form->bind($slider);
        if ($request->isPost()) {
            $data = array_merge_recursive($request->getFiles()->toArray(), $request->getPost()->toArray());
            $form->setData($data);

            if ($form->isValid()) {
                $slider = $form->getData();

                if (empty($slider->getId())) {
                    $mapper->insert($slider);
                } else {
                    $mapper->update($slider);
                }

                //update file
                if (isset($data['picture']) && $data['picture']['error'] == 0) {
                    $ext = pathinfo($data['picture']['name'], PATHINFO_EXTENSION);
                    $dirpath = $this->getServiceLocator()->get('Config')['static_path'] . '/upload/slider';
                    $dirUrl = $this->getServiceLocator()->get('Config')['static_url'] . '/upload/slider';
                    if (!is_dir($dirpath)) {
                        mkdir($dirpath, 0777, true);
                    }
                    $copy = copy($data['picture']['tmp_name'], $dirpath . '/slider-' . $slider->getId() . '.' . $ext);
                    if ($copy) {
                        $slider->setImageUrl($dirUrl . '/slider-' . $slider->getId() . '.' . $ext);
                        $mapper->update($slider);
                    } elseif ($data['id'] == 0) {
                        $mapper->delete($slider);
                    }
                }

                return $this->redirect()->toUrl($this->url()->fromRoute('admin/slider', array('lang' => $this->params()->fromRoute('lang'))));
            }
        }

        return array(
            'form' => $form,
            'slider' => $slider,
            'static_path' => $this->getServiceLocator()->get('Config')['static_path']
        );
    }

    public function deleteAction()
    {
        $id = $this->params()->fromRoute('id', 0);
        $sliderMapper = $this->getServiceLocator()->get('slider_mapper');
        $slider = $sliderMapper->findById($id);
        if ($slider) {
            $sliderMapper->delete($slider);
        }

        return $this->redirect()->toUrl($this->url()->fromRoute('admin/slider', array('lang' => $this->params()->fromRoute('lang'))));
    }

}
