<?php

namespace Admin\Controller\Factory;

use Zend\ServiceManager\FactoryInterface,
    Zend\ServiceManager\ServiceLocatorInterface,  
    Zend\ServiceManager\Exception\ServiceNotCreatedException,
    Admin\Controller\FailuresController;

class FailuresControllerFactory implements FactoryInterface
{
    public function createService(ServiceLocatorInterface $serviceLocator)
    {
        $sm = $serviceLocator->getServiceLocator();

        $routerMatch = $sm->get('router')->match($sm->get('request'));
        $lang = $routerMatch->getParam("lang");
        $langMapper = $sm->get('lang_mapper');
        $langId = $langMapper->findByLang($lang)->getId();

        $failureMapper     = $sm->get('failure_mapper');
        $failureLangMapper = $sm->get('failure_lang_mapper');
        $failureForm       = $sm->get('failure_form');
        $failureLangForm   = $sm->get('failure_lang_form');
        $colorMapper       = $sm->get('color_mapper');
        $modelMapper       = $sm->get('model_mapper');
        $brandMapper       = $sm->get('brand_mapper');

        $controller = new FailuresController($failureMapper, $failureLangMapper, $failureForm, $failureLangForm, $colorMapper, $modelMapper, $brandMapper, $lang, $langId);
        return $controller;
    }
}