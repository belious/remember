<?php

namespace Admin\Controller\Factory;

use Zend\ServiceManager\FactoryInterface,
    Zend\ServiceManager\ServiceLocatorInterface,  
    Zend\ServiceManager\Exception\ServiceNotCreatedException,
    Admin\Controller\BrandsController;

class BrandsControllerFactory implements FactoryInterface
{
    public function createService(ServiceLocatorInterface $serviceLocator)
    {
        $sm = $serviceLocator->getServiceLocator();

        $brandLangMapper = $sm->get('brand_lang_mapper');
        $brandMapper = $sm->get('brand_mapper');

        $brandLangForm = $sm->get('brand_lang_form');
        $brandForm = $sm->get('brand_form');

        $routerMatch = $sm->get('router')->match($sm->get('request'));
        $lang = $routerMatch->getParam("lang");
        $langMapper = $sm->get('lang_mapper');
        $langId = $langMapper->findByLang($lang)->getId();

        $deviceId = $routerMatch->getParam("device_id");

        $controller = new BrandsController($brandLangMapper, $brandMapper, $brandLangForm, $brandForm, $lang, $langId, $deviceId);
        return $controller;
    }
}