<?php

namespace Admin\Controller\Factory;

use Zend\ServiceManager\FactoryInterface,
    Zend\ServiceManager\ServiceLocatorInterface,  
    Zend\ServiceManager\Exception\ServiceNotCreatedException,
    Admin\Controller\ModelsController;

class ModelsControllerFactory implements FactoryInterface
{
    public function createService(ServiceLocatorInterface $serviceLocator)
    {
        $sm = $serviceLocator->getServiceLocator();

        $modelLangMapper = $sm->get('model_lang_mapper');
        $modelMapper = $sm->get('model_mapper');

        $modelLangForm = $sm->get('model_lang_form');
        $modelForm = $sm->get('model_form');

        $routerMatch = $sm->get('router')->match($sm->get('request'));
        $lang = $routerMatch->getParam("lang");
        $langMapper = $sm->get('lang_mapper');
        $langId = $langMapper->findByLang($lang)->getId();

        $brandId = $routerMatch->getParam("brand_id");

        $controller = new ModelsController($modelLangMapper, $modelMapper, $modelLangForm, $modelForm, $lang, $langId, $deviceId, $brandId);
        return $controller;
    }
}