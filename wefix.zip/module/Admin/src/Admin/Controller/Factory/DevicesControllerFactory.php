<?php

namespace Admin\Controller\Factory;

use Zend\ServiceManager\FactoryInterface,
    Zend\ServiceManager\ServiceLocatorInterface,  
    Zend\ServiceManager\Exception\ServiceNotCreatedException,
    Admin\Controller\DevicesController;

class DevicesControllerFactory implements FactoryInterface
{
    public function createService(ServiceLocatorInterface $serviceLocator)
    {
        $sm = $serviceLocator->getServiceLocator();

        $deviceLangMapper = $sm->get('device_lang_mapper');
        $deviceMapper = $sm->get('device_mapper');

        $routerMatch = $sm->get('router')->match($sm->get('request'));
        $lang = $routerMatch->getParam("lang");
        $langMapper = $sm->get('lang_mapper');
        $langId = $langMapper->findByLang($lang)->getId();

        $deviceLangForm = $sm->get('device_lang_form');
        $deviceForm = $sm->get('device_form');

        $controller = new DevicesController($deviceLangMapper, $deviceMapper, $deviceLangForm, $deviceForm, $lang, $langId);
        return $controller;
    }
}