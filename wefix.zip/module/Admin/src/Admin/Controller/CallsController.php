<?php

namespace Admin\Controller;

use Zend\Mvc\Controller\AbstractActionController;

class CallsController extends AbstractActionController
{
    public function listAction()
    {
        $phoneBackMapper = $this->getServiceLocator()->get('phone_back_mapper');
        $phoneBackList = $phoneBackMapper->findAllActive();

        return (array('phoneBackList' => $phoneBackList));
    }

    public function deleteAction()
    {
        $id = $this->params()->fromRoute('id', 0);
        $phoneBackMapper = $this->getServiceLocator()->get('phone_back_mapper');
        $phoneBack = $phoneBackMapper->findById($id);
        if ($phoneBack) {
            $phoneBackMapper->remove($phoneBack);
        }

        return $this->redirect()->toUrl($this->url()->fromRoute('admin/calls', array('lang' => $this->params()->fromRoute('lang'))));
    }
}
