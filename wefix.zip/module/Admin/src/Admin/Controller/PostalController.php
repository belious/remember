<?php

namespace Admin\Controller;

use Zend\Mvc\Controller\AbstractActionController;

class PostalController extends AbstractActionController
{
    public function listAction()
    {
        $postalCodeMapper = $this->getServiceLocator()->get('postal_code_mapper');
        $postalCodeForm = $this->getServiceLocator()->get('postal_code_form');

        $request = $this->getRequest();

        if ($request->isPost()) {
            $postalCodeForm->setData($request->getPost());
            if ($postalCodeForm->isValid()) {
                $postalCode = new \Application\Entity\PostalCode();
                $postalCode->setCode($postalCodeForm->getData()['code']);

                $postalCodeMapper->insert($postalCode);
            }
        }

        $postalCodeList = $postalCodeMapper->fetchAll();

        return (array('postalCodeList' => $postalCodeList, 'postalCodeForm' => $postalCodeForm));
    }

    public function deleteAction()
    {
        $id = $this->params()->fromRoute('id', 0);
        $postalCodeMapper = $this->getServiceLocator()->get('postal_code_mapper');
        $postalCode = $postalCodeMapper->findById($id);
        if ($postalCode) {
            $postalCodeMapper->delete($postalCode);
        }

        return $this->redirect()->toUrl($this->url()->fromRoute('admin/postal', array('lang' => $this->params()->fromRoute('lang'))));
    }
}
