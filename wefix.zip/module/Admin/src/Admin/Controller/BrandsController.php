<?php

namespace Admin\Controller;

use Zend\Mvc\Controller\AbstractActionController;

class BrandsController extends AbstractActionController
{
    public function listAction()
    {
        $request = $this->getRequest();
        if ($request->isPost()) {
            $data = array_merge_recursive($request->getFiles()->toArray(), $this->getRequest()->getPost()->toArray());
            if ($data['name']) { 
                $this->brandForm->setData($data);

                if ($this->brandForm->isValid()) {
                    $brandData = $this->brandForm->getData();
                    $brand = new \Application\Entity\Brand();
                    $brand = $this->brandMapper->findById($brandData['id']);
                    $brand->setName($brandData['name']);

                    // $uniqueEntryService = $this->getServiceLocator()->get('UniqueEntryUrl');
                    // $baseUrl = $uniqueEntryService->createUrl($brand->getName());
                    // $tmpUrl = $baseUrl;
                    // $count = 0;

                    // do {
                    //     $searchResult = $this->brandMapper->findByUrlAndDeviceId($tmpUrl, $brand->getDeviceId());
                    //     if ($searchResult && !$brand->getId()) {
                    //         $count++;
                    //         $tmpUrl = $baseUrl.$count;
                    //     } else {
                    //         $brand->setUrl($tmpUrl);
                    //     }
                    // } while (!$brand->getUrl());

                    //                $brand->setUrl($uniqueEntryService->generate($this->getServiceLocator()->get('brand_mapper')->getTableName(), 'url', $brand->getName(), array('field' => 'id', 'value' => $brand->getId())));


                    if (isset($brandData['picture']) && $brandData['picture']['error'] == 0) {
                        $adapter = new \Zend\File\Transfer\Adapter\Http();
                        $adapter->addFilter('File\Rename',array(
                            'source' => $data['picture']['tmp_name'],
                            'target' => $this->getServiceLocator()->get('Config')['static_path'].'/upload/brand-'.$brand->getId().'.png',
                            'overwrite' => true
                        ));
                        $adapter->receive();
                        $brand->setImageUrl($this->getServiceLocator()->get('Config')['static_url'].'/upload/brand-'.$brand->getId().'.png');
                    }

                    $this->brandMapper->update($brand);

                    return $this->redirect()->toUrl($this->url()->fromRoute('admin/brands', array('lang' => $this->lang, 'device_id' => $this->deviceId)));
                } else {

                }
            } else if ($data['titre']) {
                $this->brandLangForm->setData($data);
                if ($this->brandLangForm->isValid()) {
                    $brandData = $this->brandLangForm->getData();
                    $brandLang = $this->brandLangMapper->findByBrandAndLang($brandData['brand_id'], $this->langId);
                    $brandLang->setTitre($brandData['titre']);
                    $brandLang->setDescription($brandData['description']);
                    $brandLang->setTopDesc($brandData['top_desc']);
                    $brandLang->setBottomDesc($brandData['bottom_desc']);
                    $this->brandLangMapper->update($brandLang);
                }
                return $this->redirect()->toUrl($this->url()->fromRoute('admin/brands', array('lang' => $this->lang, 'device_id' => $this->deviceId)));
            }
        }

        $brandList = $this->brandMapper->fetchByDeviceId($this->deviceId);

        return (array('brandForm' => $this->brandForm, 'brandList' => $brandList, 'deviceId' => $this->deviceId));
    }

    public function addAction()
    {
        $request = $this->getRequest();

        if ($request->isPost()) {
            $data = array_merge_recursive($request->getFiles()->toArray(), $request->getPost()->toArray());
            $this->brandForm->setData($data);

            if ($this->brandForm->isValid()) {

                $brandData = $this->brandForm->getData();
                $brand = new \Application\Entity\Brand();
                $lastBrand = $this->brandMapper->findLast($this->deviceId);

                if ($lastBrand) {
                    $brand->setTop($lastBrand->getTop() - 1);
                } else {
                    $brand->setTop(0);
                }

                $brand->setName($brandData['name']);
                $brand->setDeviceId($this->deviceId);
                $brand->setId(null);

                $uniqueEntryService = $this->getServiceLocator()->get('UniqueEntryUrl');
                $baseUrl = $uniqueEntryService->createUrl($brand->getName());
                $tmpUrl = $baseUrl;
                $count = 0;

                do {
                    $searchResult = $this->brandMapper->findByUrlAndDeviceId($tmpUrl, $brand->getDeviceId());
                    if ($searchResult && !$brand->getId()) {
                        $count++;
                        $tmpUrl = $baseUrl.$count;
                    } else {
                        $brand->setUrl($tmpUrl);
                    }
                } while (!$brand->getUrl());

                $this->brandMapper->insert($brand);

                if (isset($brandData['picture']) && $brandData['picture']['error'] == 0) {
                    $adapter = new \Zend\File\Transfer\Adapter\Http();
                    $adapter->addFilter('File\Rename',array(
                        'source' => $data['picture']['tmp_name'],
                        'target' => $this->getServiceLocator()->get('Config')['static_path'].'/upload/brand-'.$brand->getId().'.png',
                        'overwrite' => true
                    ));
                    $adapter->receive();
                    $brand->setImageUrl($this->getServiceLocator()->get('Config')['static_url'].'/upload/brand-'.$brand->getId().'.png');
                    $this->brandMapper->update($brand);
                }

                foreach ($this->getServiceLocator()->get('Config')['translation']['available'] as $configuredLang) {
                    $brandLang = new \Application\Entity\BrandLang();
                    $brandLang->setTitre('');
                    $brandLang->setDescription('');
                    $brandLang->setTopDesc('');
                    $brandLang->setBottomDesc('');
                    $brandLang->setBrandId($brand->getId());
                    $brandLang->setLangId($this->getServiceLocator()->get('lang_mapper')->findByLang($configuredLang)->getId());
                    $this->brandLangMapper->insert($brandLang);
                }

                return $this->redirect()->toUrl($this->url()->fromRoute('admin/brands', array('lang' => $this->lang, 'device_id' => $this->deviceId)));
            } else {
                return (array('deviceId' => $this->deviceId, 'form' => $this->brandForm, 'lang' => $this->lang));
            }

        } else {
            $this->brandForm->setAttributes(array(
                'action' => $this->url()->fromRoute('admin/brands/add', array(
                    'device_id' => $this->deviceId,
                    'lang' => $this->lang,
                )),
            ));

            $this->brandForm->setHydrator(new \Zend\Stdlib\Hydrator\ClassMethods());

            return (array('deviceId' => $this->deviceId, 'form' => $this->brandForm));
        }
    }

    public function editAction()
    {
        $brandId = $this->params()->fromRoute('brand_id', 0);
        $brand = $this->brandMapper->findById($brandId);

        if (!$brand) {
            return $this->redirect()->toUrl($this->url()->fromRoute('admin'));
        }

        $this->brandForm->setAttributes(array(
            'action' => $this->url()->fromRoute('admin/brands', array(
                'device_id' => $this->deviceId,
                'lang' => $this->lang,
            )),
        ));

        $this->brandForm->setHydrator(new \Zend\Stdlib\Hydrator\ClassMethods());
        $this->brandForm->bind($brand);

        return (array('brand' => $brand, 'deviceId' => $this->deviceId, 'form' => $this->brandForm, 'lang' => $this->lang));
    }

    public function editlangAction()
    {
        $brandId = $this->params()->fromRoute('brand_id', 0);
        $brand = $this->brandMapper->findById($brandId);
        $brandLang = $this->brandLangMapper->findByBrandAndLang($brandId, $this->langId);

        if (!$brandLang) {
            return $this->redirect()->toUrl($this->url()->fromRoute('admin'));
        }

        $this->brandLangForm->setAttributes(array(
            'action' => $this->url()->fromRoute('admin/brands', array(
                'device_id' => $this->deviceId,
                'lang' => $this->lang,
            )),
        ));

        $this->brandLangForm->setHydrator(new \Zend\Stdlib\Hydrator\ClassMethods());
        $this->brandLangForm->bind($brandLang);

        return (array('brand' => $brand, 'deviceId' => $this->deviceId, 'form' => $this->brandLangForm));
    }

    public function starAction()
    {
        $id    = $this->params()->fromRoute('id', 0);
        $brand = $this->brandMapper->findById($id);

        if ($brand) {
            $next = $this->brandMapper->fetchNext($brand->getTop(), $brand->getDeviceId());
            // We are the first
            if (!$next->count()) {
                // nothing
            } elseif ($next->count() == 1) { // We are behind the first
                $brand->setTop($next->current()->getTop() + 1);
            } else { // We are far and there are at least 2 brands on top of us
                $next1 = $next->current();
                $brand->setTop($next1->getTop() + 1);
                $this->brandMapper->addTopFrom($brand->getDeviceId(), $next1);
            }
            $this->brandMapper->update($brand);
        }

        return $this->redirect()->toUrl($this->url()->fromRoute('admin/brands', array('lang' => $this->lang, 'device_id' => $brand->getDeviceId())));
    }

    public function downAction()
    {
        $id    = $this->params()->fromRoute('id', 0);
        $brand = $this->brandMapper->findById($id);

        if ($brand) {
            $previous = $this->brandMapper->fetchPrevious($brand->getTop(), $brand->getDeviceId());
            // We are the first
            if (!$previous->count()) {
                // nothing
            } elseif ($previous->count() == 1) { // We are before the last
                $brand->setTop($previous->current()->getTop() - 1);
            } else { // We are far and there are at least 2 brands on top of us
                $previous1 = $previous->current();
                $brand->setTop($previous1->getTop() - 1);
                $this->brandMapper->downTopFrom($brand->getDeviceId(), $previous1);
            }
            $this->brandMapper->update($brand);
        }

        return $this->redirect()->toUrl($this->url()->fromRoute('admin/brands', array('lang' => $this->lang, 'device_id' => $brand->getDeviceId())));
    }

    public function deleteAction()
    {
        $brandId = $this->params()->fromRoute('brand_id', 0);
        $type    = $this->params()->fromRoute('type', 0);
        $brand   = $this->brandMapper->findById($brandId);

        if ($brand) {
            $modelMapper = $this->getServiceLocator()->get('model_mapper');
            $modelList = $modelMapper->findByBrandId($brandId);

            foreach ($modelList as $model) {
                $this->forward()->dispatch('Models', array(
                    'action' => 'delete',
                    'model_id' => $model->getId(),
                    'brand_id' => $brand->getId(),
                ));
            }
            $this->brandMapper->delete($brand);
            return $this->redirect()->toUrl($this->url()->fromRoute('admin/brands', array('lang' => $this->lang, 'device_id' => $brand->getDeviceId())));
        }

        return $this->redirect()->toUrl($this->url()->fromRoute('admin'));
    }

    /**
     * Constructor to inject variables uses everywhere
     */
    protected $brandLangMapper;
    protected $brandMapper;
    protected $brandLangForm;
    protected $brandForm;
    protected $lang;
    protected $langId;
    protected $deviceId;
    public function __construct($brandLangMapper = null, $brandMapper = null, $brandLangForm = null, $brandForm = null, $lang = null, $langId = null, $deviceId = null)
    {
        if (!is_null($brandLangMapper)) {
            $this->brandLangMapper = $brandLangMapper;
        }

        if (!is_null($brandMapper)) {
            $this->brandMapper = $brandMapper;
        }

        if (!is_null($brandLangForm)) {
            $this->brandLangForm = $brandLangForm;
        }

        if (!is_null($brandForm)) {
            $this->brandForm = $brandForm;
        }

        if (!is_null($lang)) {
            $this->lang = $lang;
        }

        if (!is_null($langId)) {
            $this->langId = $langId;
        }

        if (!is_null($deviceId)) {
            $this->deviceId = $deviceId;
        }
    }
}
