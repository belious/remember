<?php

/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */
return array(
    'controllers' => array(
        'invokables' => array(
            'Admin'           => 'Admin\Controller\AdminController',
            'MapPoints'       => 'Admin\Controller\MapPointsController',
            'Slider'          => 'Admin\Controller\SliderController',
            'FeaturedFailure' => 'Admin\Controller\FeaturedFailureController',
            'Calls'           => 'Admin\Controller\CallsController',
            'Postal'          => 'Admin\Controller\PostalController',
            'Colors'          => 'Admin\Controller\ColorsController',
            'Pictos'          => 'Admin\Controller\PictosController',
            'Orders'          => 'Admin\Controller\OrdersController',
            'Landings'        => 'Admin\Controller\LandingsController',
            'Images'          => 'Admin\Controller\ImagesController',
        ),
        'factories' => array(
            'Devices'  => 'Admin\Controller\Factory\DevicesControllerFactory',
            'Brands'   => 'Admin\Controller\Factory\BrandsControllerFactory',
            'Models'   => 'Admin\Controller\Factory\ModelsControllerFactory',
            'Failures' => 'Admin\Controller\Factory\FailuresControllerFactory',
        )
    ),
    'router' => array(
        'routes' => array(
            'admin' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/[:lang/]admin/index',
                    'defaults' => array(
                        'controller' => 'Admin',
                        'action' => 'index',
                        'lang' => 'fr',
                    ),
                    'constraints' => array(
                        'lang' => 'en|fr|de|nl'
                    ),
                ),
                'may_terminate' => true,
                'child_routes' => array(
                    'mappoint' => array(
                        'type' => 'Literal',
                        'options' => array(
                            'route' => '/mappoints',
                            'defaults' => array(
                                'controller' => 'MapPoints',
                                'action' => 'list',
                            ),
                        ),
                        'may_terminate' => true,
                        'child_routes' => array(
                            'add' => array(
                                'type' => 'Literal',
                                'options' => array(
                                    'route' => '/new',
                                    'defaults' => array(
                                        'action' => 'edit',
                                    ),
                                ),
                                'may_terminate' => true,
                            ),
                            'edit' => array(
                                'type' => 'Segment',
                                'options' => array(
                                    'route' => '/edit/:id',
                                    'constraints' => array(
                                        'id' => '[0-9]+',
                                    ),
                                    'defaults' => array(
                                        'action' => 'edit',
                                    ),
                                ),
                                'may_terminate' => true,
                            ),
                            'delete' => array(
                                'type' => 'Segment',
                                'options' => array(
                                    'route' => '/delete/:id',
                                    'constraints' => array(
                                        'id' => '[0-9]+',
                                    ),
                                    'defaults' => array(
                                        'action' => 'delete',
                                    ),
                                ),
                                'may_terminate' => true,
                            ),
                        )
                    ),
                    'slider' => array(
                        'type' => 'Literal',
                        'options' => array(
                            'route' => '/slider',
                            'defaults' => array(
                                'controller' => 'Slider',
                                'action' => 'list',
                            ),
                        ),
                        'may_terminate' => true,
                        'child_routes' => array(
                            'add' => array(
                                'type' => 'Literal',
                                'options' => array(
                                    'route' => '/new',
                                    'defaults' => array(
                                        'action' => 'edit',
                                    ),
                                ),
                                'may_terminate' => true,
                            ),
                            'edit' => array(
                                'type' => 'Segment',
                                'options' => array(
                                    'route' => '/edit/:id',
                                    'constraints' => array(
                                        'id' => '[0-9]+',
                                    ),
                                    'defaults' => array(
                                        'action' => 'edit',
                                    ),
                                ),
                                'may_terminate' => true,
                            ),
                            'delete' => array(
                                'type' => 'Segment',
                                'options' => array(
                                    'route' => '/delete/:id',
                                    'constraints' => array(
                                        'id' => '[0-9]+',
                                    ),
                                    'defaults' => array(
                                        'action' => 'delete',
                                    ),
                                ),
                                'may_terminate' => true,
                            ),
                        )
                    ),
                    'featured' => array(
                        'type' => 'Literal',
                        'options' => array(
                            'route' => '/featured',
                            'defaults' => array(
                                'controller' => 'FeaturedFailure',
                                'action' => 'list',
                            ),
                        ),
                        'may_terminate' => true,
                        'child_routes' => array(
                            'add' => array(
                                'type' => 'Literal',
                                'options' => array(
                                    'route' => '/new',
                                    'defaults' => array(
                                        'action' => 'edit',
                                    ),
                                ),
                                'may_terminate' => true,
                            ),
                            'edit' => array(
                                'type' => 'Segment',
                                'options' => array(
                                    'route' => '/edit/:id',
                                    'constraints' => array(
                                        'id' => '[0-9]+',
                                    ),
                                    'defaults' => array(
                                        'action' => 'edit',
                                    ),
                                ),
                                'may_terminate' => true,
                            ),
                            'delete' => array(
                                'type' => 'Segment',
                                'options' => array(
                                    'route' => '/delete/:id',
                                    'constraints' => array(
                                        'id' => '[0-9]+',
                                    ),
                                    'defaults' => array(
                                        'action' => 'delete',
                                    ),
                                ),
                                'may_terminate' => true,
                            ),
                        )
                    ),
                    'landing' => array(
                        'type' => 'Literal',
                        'options' => array(
                            'route' => '/landings',
                            'defaults' => array(
                                'controller' => 'Landings',
                                'action' => 'list',
                            ),
                        ),
                        'may_terminate' => true,
                        'child_routes' => array(
                            'edit' => array(
                                'type' => 'Segment',
                                'options' => array(
                                    'route' => '/edit/:landing_id',
                                    'constraints' => array(
                                        'landing_id' => '[0-9]+',
                                    ),
                                    'defaults' => array(
                                        'action' => 'edit',
                                    ),
                                ),
                                'may_terminate' => true,
                            ),
                            'delete' => array(
                                'type' => 'Segment',
                                'options' => array(
                                    'route' => '/delete/:landing_id',
                                    'constraints' => array(
                                        'landing_id' => '[0-9]+',
                                    ),
                                    'defaults' => array(
                                        'action' => 'delete',
                                    ),
                                ),
                                'may_terminate' => true,
                            ),
                        ),
                    ),
                    'orders' => array(
                        'type' => 'Literal',
                        'options' => array(
                            'route' => '/orders',
                            'defaults' => array(
                                'controller' => 'Orders',
                                'action' => 'list',
                            ),
                        ),
                        'may_terminate' => true,
                        'child_routes' => array(
                            'edit' => array(
                                'type' => 'Segment',
                                'options' => array(
                                    'route' => '/edit/:order_id',
                                    'constraints' => array(
                                        'order_id' => '[0-9]+',
                                    ),
                                    'defaults' => array(
                                        'controller' => 'Orders',
                                        'action' => 'edit',
                                    ),
                                ),
                                'may_terminate' => true,
                                'child_routes' => array(
                                    'repair' => array(
                                        'type' => 'Segment',
                                        'options' => array(
                                            'route' => '/repair[/:repair_id]',
                                            'constraints' => array(
                                                'repair_id' => '[0-9]+',
                                            ),
                                            'defaults' => array(
                                                'controller' => 'Orders',
                                                'action' => 'repair',
                                                'repair_id' => '0',
                                            ),
                                        ),
                                    ),
                                    'deleteRepair' => array(
                                        'type' => 'Segment',
                                        'options' => array(
                                            'route' => '/delete/:repair_id',
                                            'constraints' => array(
                                                'repair_id' => '[0-9]+',
                                            ),
                                            'defaults' => array(
                                                'controller' => 'Orders',
                                                'action' => 'deleteRepair',
                                            ),
                                        ),
                                    ),
                                    'chronopost' => array(
                                        'type' => 'Literal',
                                        'options' => array(
                                            'route' => '/chronopost',
                                            'defaults' => array(
                                                'controller' => 'Orders',
                                                'action' => 'chronopost',
                                            ),
                                        ),
                                    ),
                                ),
                            ),
                        ),
                    ),
                    'devices' => array(
                        'type' => 'Segment',
                        'options' => array(
                            'route' => '/devices',
                            'defaults' => array(
                                'controller' => 'Devices',
                                'action' => 'list',
                            ),
                        ),
                        'may_terminate' => true,
                        'child_routes' => array(
                            'edit' => array(
                                'type' => 'Segment',
                                'options' => array(
                                    'route' => '/edit/:device_id',
                                    'constraints' => array(
                                        'device_id' => '[0-9]+',
                                    ),
                                    'defaults' => array(
                                        'controller' => 'Devices',
                                        'action' => 'edit',
                                    ),
                                ),
                            ),
                        ),
                    ),
                    'brands' => array(
                        'type' => 'Segment',
                        'options' => array(
                            'route' => '/:device_id/brands',
                            'constraints' => array(
                                'device_id' => '[0-9]+',
                            ),
                            'defaults' => array(
                                'controller' => 'Brands',
                                'action' => 'list',
                            ),
                        ),
                        'may_terminate' => true,
                        'child_routes' => array(
                            'add' => array(
                                'type' => 'Literal',
                                'options' => array(
                                    'route' => '/add',
                                    'defaults' => array(
                                        'controller' => 'Brands',
                                        'action' => 'add',
                                    ),
                                ),
                            ),
                            'edit' => array(
                                'type' => 'Segment',
                                'options' => array(
                                    'route' => '/edit/:brand_id',
                                    'constraints' => array(
                                        'brand_id' => '[0-9]+',
                                    ),
                                    'defaults' => array(
                                        'controller' => 'Brands',
                                        'action' => 'edit',
                                    ),
                                ),
                            ),
                            'editlang' => array(
                                'type' => 'Segment',
                                'options' => array(
                                    'route' => '/editlang/:brand_id',
                                    'constraints' => array(
                                        'brand_id' => '[0-9]+',
                                    ),
                                    'defaults' => array(
                                        'controller' => 'Brands',
                                        'action' => 'editlang',
                                    ),
                                ),
                            ),
                            'star' => array(
                                'type' => 'Segment',
                                'options' => array(
                                    'route' => '/star/:id',
                                    'constraints' => array(
                                        'id' => '[0-9]+',
                                    ),
                                    'defaults' => array(
                                        'controller' => 'Brands',
                                        'action' => 'star',
                                    ),
                                ),
                            ),
                            'down' => array(
                                'type' => 'Segment',
                                'options' => array(
                                    'route' => '/down/:id',
                                    'constraints' => array(
                                        'id' => '[0-9]+',
                                    ),
                                    'defaults' => array(
                                        'controller' => 'Brands',
                                        'action' => 'down',
                                    ),
                                ),
                            ),
                            'delete' => array(
                                'type' => 'Segment',
                                'options' => array(
                                    'route' => '/delete/:brand_id',
                                    'constraints' => array(
                                        'brand_id' => '[0-9]+',
                                    ),
                                    'defaults' => array(
                                        'controller' => 'Brands',
                                        'action' => 'delete',
                                    ),
                                ),
                            ),
                        ),
                    ),
                    'models' => array(
                        'type' => 'Segment',
                        'options' => array(
                            'route' => '/model/:brand_id',
                            'constraints' => array(
                                'id' => '[0-9]+',
                            ),
                            'defaults' => array(
                                'controller' => 'Models',
                                'action' => 'list',
                            ),
                        ),
                        'may_terminate' => true,
                        'child_routes' => array(
                            'add' => array(
                                'type' => 'Literal',
                                'options' => array(
                                    'route' => '/add',
                                    'defaults' => array(
                                        'controller' => 'Models',
                                        'action' => 'add',
                                    ),
                                ),
                            ),
                            'star' => array(
                                'type' => 'Segment',
                                'options' => array(
                                    'route' => '/star/:id',
                                    'constraints' => array(
                                        'id' => '[0-9]+',
                                    ),
                                    'defaults' => array(
                                        'controller' => 'Models',
                                        'action' => 'star',
                                    ),
                                ),
                            ),
                            'down' => array(
                                'type' => 'Segment',
                                'options' => array(
                                    'route' => '/down/:id',
                                    'constraints' => array(
                                        'id' => '[0-9]+',
                                    ),
                                    'defaults' => array(
                                        'controller' => 'Models',
                                        'action' => 'down',
                                    ),
                                ),
                            ),
                            'edit' => array(
                                'type' => 'Segment',
                                'options' => array(
                                    'route' => '/edit/:model_id',
                                    'constraints' => array(
                                        'model_id' => '[0-9]+',
                                    ),
                                    'defaults' => array(
                                        'controller' => 'Models',
                                        'action' => 'edit',
                                    ),
                                ),
                            ),
                            'editlang' => array(
                                'type' => 'Segment',
                                'options' => array(
                                    'route' => '/editlang/:model_id',
                                    'constraints' => array(
                                        'model_id' => '[0-9]+',
                                    ),
                                    'defaults' => array(
                                        'controller' => 'Models',
                                        'action' => 'editlang',
                                    ),
                                ),
                            ),
                            'delete' => array(
                                'type' => 'Segment',
                                'options' => array(
                                    'route' => '/delete/:model_id',
                                    'constraints' => array(
                                        'model_id' => '[0-9]+',
                                    ),
                                    'defaults' => array(
                                        'controller' => 'Models',
                                        'action' => 'delete',
                                    ),
                                ),
                            ),
                        ),
                    ),
                    'colors' => array(
                        'type' => 'Segment',
                        'options' => array(
                            'route' => '/color/:model_id',
                            'constraints' => array(
                                'model_id' => '[0-9]+',
                            ),
                            'defaults' => array(
                                'controller' => 'Colors',
                                'action' => 'list',
                            ),
                        ),
                        'may_terminate' => true,
                        'child_routes' => array(
                            'edit' => array(
                                'type' => 'Segment',
                                'options' => array(
                                    'route' => '/edit/:color_id',
                                    'constraints' => array(
                                        'color_id' => '[0-9]+',
                                    ),
                                    'defaults' => array(
                                        'controller' => 'Colors',
                                        'action' => 'edit',
                                    ),
                                ),
                            ),
                            'delete' => array(
                                'type' => 'Segment',
                                'options' => array(
                                    'route' => '/delete/:color_id',
                                    'constraints' => array(
                                        'color_id' => '[0-9]+',
                                    ),
                                    'defaults' => array(
                                        'controller' => 'Colors',
                                        'action' => 'delete',
                                    ),
                                ),
                            ),
                        ),
                    ),
                    'failures' => array(
                        'type' => 'Segment',
                        'options' => array(
                            'route' => '/failure/:color_id',
                            'constraints' => array(
                                'color_id' => '[0-9]+',
                            ),
                            'defaults' => array(
                                'controller' => 'Failures',
                                'action' => 'list',
                            ),
                        ),
                        'may_terminate' => true,
                        'child_routes' => array(
                            'add' => array(
                                'type' => 'Literal',
                                'options' => array(
                                    'route' => '/add',
                                    'defaults' => array(
                                        'controller' => 'Failures',
                                        'action' => 'add',
                                    ),
                                ),
                            ),
                            'edit' => array(
                                'type' => 'Segment',
                                'options' => array(
                                    'route' => '/edit/:failure_id',
                                    'constraints' => array(
                                        'failure_id' => '[0-9]+',
                                    ),
                                    'defaults' => array(
                                        'controller' => 'Failures',
                                        'action' => 'edit',
                                    ),
                                ),
                            ),
                            'editlang' => array(
                                'type' => 'Segment',
                                'options' => array(
                                    'route' => '/editlang/:failure_id',
                                    'constraints' => array(
                                        'failure_id' => '[0-9]+',
                                    ),
                                    'defaults' => array(
                                        'controller' => 'Failures',
                                        'action' => 'editlang',
                                    ),
                                ),
                            ),
                            'store' => array(
                                'type' => 'Segment',
                                'options' => array(
                                    'route' => '/store/:failure_id',
                                    'constraints' => array(
                                        'failure_id' => '[0-9]+',
                                    ),
                                    'defaults' => array(
                                        'controller' => 'Failures',
                                        'action' => 'store',
                                    ),
                                ),
                            ),
                            'star' => array(
                                'type' => 'Segment',
                                'options' => array(
                                    'route' => '/star/:id',
                                    'constraints' => array(
                                        'id' => '[0-9]+',
                                    ),
                                    'defaults' => array(
                                        'controller' => 'Failures',
                                        'action' => 'star',
                                    ),
                                ),
                            ),
                            'down' => array(
                                'type' => 'Segment',
                                'options' => array(
                                    'route' => '/down/:id',
                                    'constraints' => array(
                                        'id' => '[0-9]+',
                                    ),
                                    'defaults' => array(
                                        'controller' => 'Failures',
                                        'action' => 'down',
                                    ),
                                ),
                            ),
                            'delete' => array(
                                'type' => 'Segment',
                                'options' => array(
                                    'route' => '/delete/:failure_id',
                                    'constraints' => array(
                                        'failure_id' => '[0-9]+',
                                    ),
                                    'defaults' => array(
                                        'controller' => 'Failures',
                                        'action' => 'delete',
                                    ),
                                ),
                            ),
                        ),
                    ),
                    'calls' => array(
                        'type' => 'Literal',
                        'options' => array(
                            'route' => '/calls',
                            'defaults' => array(
                                'controller' => 'Calls',
                                'action' => 'list',
                            ),
                        ),
                        'may_terminate' => true,
                        'child_routes' => array(
                            'delete' => array(
                                'type' => 'Segment',
                                'options' => array(
                                    'route' => '/delete/:id',
                                    'constraints' => array(
                                        'id' => '[0-9]+',
                                    ),
                                    'defaults' => array(
                                        'controller' => 'Calls',
                                        'action' => 'delete',
                                    ),
                                ),
                            ),
                        ),
                    ),

                    'postal' => array(
                        'type' => 'Literal',
                        'options' => array(
                            'route' => '/postal',
                            'defaults' => array(
                                'controller' => 'Postal',
                                'action' => 'list',
                            ),
                        ),
                        'may_terminate' => true,
                        'child_routes' => array(
                            'delete' => array(
                                'type' => 'Segment',
                                'options' => array(
                                    'route' => '/delete/:id',
                                    'constraints' => array(
                                        'id' => '[0-9]+',
                                    ),
                                    'defaults' => array(
                                        'controller' => 'Postal',
                                        'action' => 'delete',
                                    ),
                                ),
                            ),
                        ),
                    ),
                    'pictos' => array(
                        'type' => 'Literal',
                        'options' => array(
                            'route' => '/pictos',
                            'defaults' => array(
                                'controller' => 'Pictos',
                                'action' => 'list',
                            ),
                        ),
                        'may_terminate' => true,
                        'child_routes' => array(
                            'delete' => array(
                                'type' => 'Segment',
                                'options' => array(
                                    'route' => '/delete/:id',
                                    'constraints' => array(
                                        'id' => '[0-9]+',
                                    ),
                                    'defaults' => array(
                                        'controller' => 'Pictos',
                                        'action' => 'delete',
                                    ),
                                ),
                            ),
                        ),
                    ),
                    'images' => array(
                        'type' => 'Literal',
                        'options' => array(
                            'route' => '/images',
                            'defaults' => array(
                                'controller' => 'Images',
                                'action' => 'list',
                            ),
                        ),
                        'may_terminate' => true,
                        'child_routes' => array(
                            'delete' => array(
                                'type' => 'Segment',
                                'options' => array(
                                    'route' => '/delete/:id',
                                    'constraints' => array(
                                        'id' => '[0-9]+',
                                    ),
                                    'defaults' => array(
                                        'controller' => 'Images',
                                        'action' => 'delete',
                                    ),
                                ),
                            ),
                        ),
                    ),
                ),
            ),
        ),
    ),
    'translator' => array(
        'locale' => 'fr_FR',
        'translation_file_patterns' => array(
            array(
                'type'     => 'gettext',
                'base_dir' => __DIR__ . '/../language',
                'pattern'  => '%s.mo',
            ),
        ),
    ),
    'view_manager' => array(
        'template_map' => array(
            'layout/admin' => __DIR__ . '/../view/layout/index.phtml'
        ),
        'template_path_stack' => array(
            __DIR__ . '/../view',
        ),
    ),
    'service_manager' => array(
        'abstract_factories' => array(
            'Zend\Navigation\Service\NavigationAbstractServiceFactory',
        ),
    ),
);
