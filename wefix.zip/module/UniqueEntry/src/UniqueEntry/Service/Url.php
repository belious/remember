<?php

namespace UniqueEntry\Service;

use Zend\ServiceManager\ServiceManagerAwareInterface;
use Zend\ServiceManager\ServiceManager;
use Zend\Validator\Db\NoRecordExists;

class Url implements ServiceManagerAwareInterface
{
    /**
     * @var ServiceManager
     */
    protected $serviceManager;

    public function generate($tableName, $tableField, $element, $excludeEntryId = null)
    {
        $count = 0;
        setlocale(LC_ALL, 'fr_FR.UTF-8');

        $uristub = iconv('UTF-8', 'ASCII//TRANSLIT', $element);
        $uristub = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $uristub);
        $uristub = preg_replace("/[\/_|+ -]+/", '-', $uristub);
        $uristub = strtolower(trim($uristub, '-'));
        $noRecord = new NoRecordExists(array('table' => $tableName, 'field' => $tableField, 'adapter' => $this->getServiceManager()->get('Zend\Db\Adapter\Adapter'), 'exclude' => $excludeEntryId));

        do {
            $uristubToCheck = ($count != 0 ? $uristub . $count : $uristub);
            $count++;
        } while (!$noRecord->isValid($uristubToCheck));

        return $uristubToCheck;
    }
    
    public function createUrl($name) {
        setlocale(LC_ALL, 'fr_FR.UTF-8');

        $uristub = iconv('UTF-8', 'ASCII//TRANSLIT', $name);
        $uristub = preg_replace("/[^a-zA-Z0-9\/_|+ -]/", '', $uristub);
        $uristub = preg_replace("/[\/_|+ -]+/", '-', $uristub);
        $uristub = preg_replace("ç", '', $uristub);
        $uristub = strtolower(trim($uristub, '-'));
        return $uristub;
    }

    /**
     * Retrieve service manager instance
     *
     * @return ServiceManager
     */
    public function getServiceManager()
    {
        return $this->serviceManager;
    }

    /**
     * Set service manager instance
     *
     * @param  ServiceManager $serviceManager
     * @return User
     */
    public function setServiceManager(ServiceManager $serviceManager)
    {
        $this->serviceManager = $serviceManager;

        return $this;
    }
}
