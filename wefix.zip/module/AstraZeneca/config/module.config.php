<?php

return array(
    'controllers' => array(
        'invokables' => array(
            'AstraZeneca' => 'AstraZeneca\Controller\AstraZenecaController',
            'AstraZenecaSiege' => 'AstraZeneca\Controller\AstraZenecaSiegeController',
        ),
    ),
    'service_manager' => array(
        'invokables' => array(
            'AstraZenecaForm' => 'AstraZeneca\Form\AstraZenecaForm',
        ),
    ),
    'router' => array(
        'routes' => array(
            'astrazeneca' => array(
                'type' => 'Literal',
                'options' => array(
                    'route' => '/astrazeneca',
                    'defaults' => array(
                        'controller' => 'AstraZeneca',
                        'action' => 'index',
                    ),
                ),
                'may_terminate' => false,
                'child_routes' => array(
                    'pay' => array(
                        'type' => 'Segment',
                        'options' => array(
                            'route' => '/:id',
                            'constraints' => array(
                                'id' => '[0-9]+',
                            ),
                            'defaults' => array(
                                'action' => 'pay',
                            ),
                        ),
                        'may_terminate' => true,
                        'child_routes' => array(
                            'facture' => array(
                                'type' => 'Literal',
                                'options' => array(
                                    'route' => '/facture',
                                    'defaults' => array(
                                        'action' => 'facture',
                                    ),
                                ),
                            ),
                        ),
                    ),
                ),
            ),
            'astrazeneca-siege' => array(
                'type' => 'Literal',
                'options' => array(
                    'route' => '/astrazeneca-siege',
                    'defaults' => array(
                        'controller' => 'AstraZenecaSiege',
                        'action' => 'index',
                    ),
                ),
                'may_terminate' => false,
            ),
            'astrazeneca_pay' => array(
                'type' => 'Literal',
                'options' => array(
                    'route' => '/be2bill-mobile/form',
                    'defaults' => array(
                        'controller' => 'AstraZeneca',
                        'action' => 'template',
                    ),
                ),
            ),
        ),
    ),
    'view_manager' => array(
        'template_path_stack' => array(
            __DIR__ . '/../view',
        ),
    ),
);
