<?php

namespace AstraZeneca\Form;

use Zend\Form\Form;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;
use Zend\Stdlib\Hydrator\ClassMethods;

class AstraZenecaForm extends Form implements InputFilterAwareInterface
{
    protected $inputFilter;

    public function __construct()
    {
        $this->setHydrator(new ClassMethods());
        // we want to ignore the name passed
        parent::__construct('astrazeneca');

        $this->setAttributes(array(
            'method' => 'post',
        ));

        $this->add(array(
            'name' => 'prenom',
            'type'  => 'Zend\Form\Element\Text',
            'options' => array(
                'label' => "Prénom*",
            ),
        ));

        $this->add(array(
            'name' => 'nom',
            'type'  => 'Zend\Form\Element\Text',
            'options' => array(
                'label' => 'Nom*',
            ),
        ));

        $this->add(array(
            'name' => 'adresse',
            'type'  => 'Zend\Form\Element\Text',
            'options' => array(
                'label' => 'Adresse*',
            ),
        ));

        $this->add(array(
            'name' => 'code_postal',
            'type'  => 'Zend\Form\Element\Text',
            'options' => array(
                'label' => 'Code postal*',
            ),
        ));

        $this->add(array(
            'name' => 'ville',
            'type'  => 'Zend\Form\Element\Text',
            'options' => array(
                'label' => 'Ville*',
            ),
        ));

        $this->add(array(
            'name' => 'telephone',
            'type'  => 'Zend\Form\Element\Text',
            'options' => array(
                'label' => 'Téléphone*',
            ),
        ));
        
        $this->add(array(
            'name' => 'email',
            'type'  => 'Zend\Form\Element\Email',
            'options' => array(
                'label' => 'Mail*',
            ),
        ));
        
        $this->add(array(
            'name' => 'emei',
            'type'  => 'Zend\Form\Element\Text',
            'options' => array(
                'label' => 'Numéro EMEI*',
            ),
        ));
    }

    public function getInputFilter()
    {
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();
            $factory     = new InputFactory();

            $inputFilter->add($factory->createInput(array(
                'name'       => 'prenom',
                'required'   => true,
                'filters'  => array(
                    array('name' => 'StringTrim'),
                ),
            )));
            
            $inputFilter->add($factory->createInput(array(
                'name'       => 'nom',
                'required'   => true,
                'filters'  => array(
                    array('name' => 'StringTrim'),
                ),
            )));
            
            $inputFilter->add($factory->createInput(array(
                'name'       => 'adresse',
                'required'   => true,
                'filters'  => array(
                    array('name' => 'StringTrim'),
                ),
            )));
            
            $inputFilter->add($factory->createInput(array(
                'name'       => 'code_postal',
                'required'   => true,
                'filters'  => array(
                    array('name' => 'StringTrim'),
                ),
            )));
            
            $inputFilter->add($factory->createInput(array(
                'name'       => 'ville',
                'required'   => true,
                'filters'  => array(
                    array('name' => 'StringTrim'),
                ),
            )));
            
            $inputFilter->add($factory->createInput(array(
                'name'       => 'telephone',
                'required'   => true,
                'filters'  => array(
                    array('name' => 'StringTrim'),
                ),
            )));
            
            $inputFilter->add($factory->createInput(array(
                'name'       => 'email',
                'required'   => true,
                'filters'  => array(
                    array('name' => 'StringTrim'),
                ),
            )));
            
            $inputFilter->add($factory->createInput(array(
                'name'       => 'emei',
                'required'   => true,
                'filters'  => array(
                    array('name' => 'StringTrim'),
                ),
                'validators' => array(
                    array('name' => 'StringLength', 'options' => array('min' => 15, 'max' => 15)),
                ),
            )));

            $this->inputFilter = $inputFilter;
        }

        return $this->inputFilter;
    }

    public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new \Exception("Not used");
    }
}
