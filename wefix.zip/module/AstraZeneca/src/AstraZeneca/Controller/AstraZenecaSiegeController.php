<?php

namespace AstraZeneca\Controller;

use Zend\Mvc\Controller\AbstractActionController;

class AstraZenecaSiegeController extends AbstractActionController
{
    public function indexAction()
    {
        return $this->notFoundAction();
        $request = $this->getRequest();
        $this->layout('layout/astra-zeneca');
        $form = $this->getServiceLocator()->get('AstraZenecaForm');
        $astraZenecaMapper = $this->getServiceLocator()->get('astrazeneca_mapper');

        if ($request->isPost()) {
            $form->bind(new \AstraZeneca\Entity\AstraZeneca());
            $form->setData($request->getPost()->toArray());
            if ($form->isValid()) {
                $astraZeneca = $form->getData();
                $astraZenecaMapper->insert($astraZeneca);

                return $this->redirect()->toRoute('astrazeneca/pay', array('id' => $astraZeneca->getId()));
            }
        }

        return array('form' => $form);
    }
}
