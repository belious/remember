<?php

namespace AstraZeneca\Controller;

use Zend\Mvc\Controller\AbstractActionController;

class AstraZenecaController extends AbstractActionController
{
    public function indexAction()
    {
        $request = $this->getRequest();
        $this->layout('layout/astra-zeneca');
        $form = $this->getServiceLocator()->get('AstraZenecaForm');
        $astraZenecaMapper = $this->getServiceLocator()->get('astrazeneca_mapper');

        if ($request->isPost()) {
            $form->bind(new \AstraZeneca\Entity\AstraZeneca());
            $form->setData($request->getPost()->toArray());
            if ($form->isValid()) {
                $astraZeneca = $form->getData();
                $astraZenecaMapper->insert($astraZeneca);

                return $this->redirect()->toRoute('astrazeneca/pay', array('id' => $astraZeneca->getId()));
            }
        }

        return array('form' => $form);
    }

    public function payAction()
    {
        $id = $this->params()->fromRoute('id');
        $this->layout('layout/astra-zeneca');
        $astraZenecaMapper = $this->getServiceLocator()->get('astrazeneca_mapper');

        $astraZeneca = $astraZenecaMapper->findById($id);
        if (!$astraZeneca) {
            return $this->notFoundAction();
        }
        if ($astraZeneca->getPaid()) {
            return $this->notFoundAction();
        }

        $identifier = $this->getServiceLocator()->get('Config')['be2bill']['identifier'];
        $mdp = $this->getServiceLocator()->get('Config')['be2bill']['mdp'];
        $formUrl = $this->getServiceLocator()->get('Config')['be2bill']['formUrl'];
        $hash = hash('sha256', $mdp.'AMOUNT='.(250 * 100).$mdp.'CLIENTEMAIL='.$astraZeneca->getEmail().$mdp.'CLIENTIDENT='.$astraZeneca->getId().$mdp.'DESCRIPTION=iPhone 5S noir 16 Go'.$mdp.'EXTRADATA=astrazeneca'.$mdp.'IDENTIFIER='.$identifier.$mdp.'OPERATIONTYPE=payment'.$mdp.'ORDERID='.$astraZeneca->getId().$mdp.'USETEMPLATE=mobile'.$mdp.'VERSION=2.0'.$mdp);

        return array('astrazeneca' => $astraZeneca, 'hash' => $hash, 'formUrl' => $formUrl, 'identifier' => $identifier);
    }

    public function templateAction()
    {
        $this->layout('layout/astra-zeneca');
    }

    public function factureAction()
    {
        $orderId = $this->params()->fromRoute('id');

        $orderMapper = $this->getServiceLocator()->get('astrazeneca_mapper');

        $order = $orderMapper->findById($orderId);
        if ($order && $order->getPaid()) {
            $pdf = new \TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

            $pdf->SetCreator('WeFix');
            $pdf->SetAuthor('WeFix');
            $pdf->SetTitle('Facture '.$order->getId());
            $pdf->SetSubject('Facture '.$order->getId());
            $pdf->SetKeywords('facture, allosmartphone');
            $pdf->SetPrintHeader(false);
            $pdf->SetPrintFooter(false);
            $pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
            $pdf->SetAutoPageBreak(true, PDF_MARGIN_BOTTOM);
            $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
            $pdf->AddPage();

            $html = '
			<style>
			body {
				font-size: 12px;
			}

			a {
				color: #5e6472;
			}

			.entete tr td {
				border-top: 2px solid #707070;
				border-bottom: 2px solid #707070;
			}

			.presta tr th {
				background-color: #bfbfbf;
				border: 1px solid #bfbfbf;
			}

			.presta tr td {
				background-color: #eaeaea;
				border: 1px solid #bfbfbf;
			}

			</style>
			<body>
			<img src="'.$this->getServiceLocator()->get('Config')['static_path'].'/img/logo.png"><br><br>
			<table class="entete">
				<tr>
					<td style="width: 300px;">
						WeFix<br>
						SAS EMGK<br>
						21 bd Ney<br>
						75018 Paris<br>
						Tel: 01 76 50 76 50<br>
						<a href="http://www.wefix.net">www.wefix.net</a><br>
						<a href="mailto:contact@wefix.net">contact@wefix.net</a><br>
						RCS Paris 518 902 804<br>
						SIRET: 518 902 804 00013<br>
						N° de TVA intracommunautaire: FR44518902804
					</td>
					<td style="width: 70px;background-color:#bfbfbf;">
					</td>
					<td style="width: 20px;">
					</td>
					<td style="width: 260px;">
						Facture n° ASTRA'.$order->getId().'<br>
						Date de la facture : '.$order->getDateCreated().'<br><br>
						Facturé à : '.$order->getPrenom().' '.$order->getNom().'<br>
						Adresse: '.$order->getAdresse().', '.$order->getCodePostal().' - '.$order->getVille().'
					</td>
				</tr>
			</table>
			<br><br><br>
			<table class="presta">
				<tr>
					<th style="width: 300px;">
						 Description
					</th>
					<th style="width: 80px;text-align:center;">
						Quantité
					</th>
					<th style="width: 135px;text-align:center;">
						Coût unitaire HT
					</th>
					<th style="width: 135px;">
						Montant HT
					</th>
				</tr>
			';

            $totalPrice = 0;
            $sousTotal = 0;

            $totalPrice += 250;
            $sousTotal += round(250 * 0.8333333333333333, 2);
            $html .= '<tr><td> iPhone 5S</td>
					<td style="text-align:center;">1</td>
					<td style="text-align:center;">'.round(250 * 0.8333333333333333, 2).' €</td>
					<td style="text-align:right;">'.round(250 * 0.8333333333333333, 2).' €</td></tr>';

            $html .= '
			</table><br><br>
			<table>
			<tr><td style="width: 515px;text-align:right;">Sous-total de la facture<br><br><br>Taux de la T.V.A.<br>Montant de la T.V.A.<br><div style="background-color:#eaeaea;"><b>TOTAL</b></div></td><td style="text-align: right;width:135px;">'.$sousTotal.' €<br><br><br>20%<br> '.round($sousTotal * 20 / 100, 2).' €<br><div style="background-color:#eaeaea;"><b>'.$totalPrice.' €</b></div></td></tr>
			</table>
			<br><br>
			<div style="text-align:center;">
			<b>Nous vous remercions pour votre confiance.</b>
			</div>
			</body>';

            $pdf->writeHTML($html, true, false, true, false, '');

            $pdf->lastPage();

            $pdf->Output('facture_'.$order->getId(), 'I');

            exit();
        }

        return $this->redirect()->toUrl($this->url()->fromRoute('application'));
    }
}
