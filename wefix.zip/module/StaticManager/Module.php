<?php

namespace StaticManager;

use StaticManager\Helper\StaticResourceUrl;

class Module
{

    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }

    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
                ),
            ),
        );
    }

    public function getViewHelperConfig()
    {
        return array(
            'factories' => array(
                'StaticResourceUrl' => function ($sm) {
                    $staticResourceUrl = new StaticResourceUrl();
                    $staticResourceUrl->setServiceManager($sm);

                    return $staticResourceUrl;
                }
            ),
        );
    }

}
