<?php

namespace LandingPage\Controller;

use Zend\Mvc\Controller\AbstractActionController;

class LandingPageController extends AbstractActionController
{
    public function iphone2Action()
    {
        $this->layout('layout/landing');
        $request = $this->getRequest();
        $landingIphoneForm = $this->getServiceLocator()->get('landing_iphone_form');


        $displayPopup = false;

        if ($request->isPost()) {
            $landingIphoneForm->setData($request->getPost());

            if ($landingIphoneForm->isValid()) {
                $mailer = $this->getServiceLocator()->get('mail_service');
                $message = $mailer->createHtmlMessage('contact@wefix.net', 'Landing WeFix', 'template/landing', array('data' => $landingIphoneForm->getData()));
                $message = $mailer->createHtmlMessage('serviceclients@wefix.net', 'Landing WeFix', 'template/landing', array('data' => $landingIphoneForm->getData()));
                $mailer->send($message);
                $displayPopup = true;
            }
        }

        return array('iphoneForm' => $landingIphoneForm, 'displayPopup' => $displayPopup);
    }

    public function dynamicAction() {
        $landingPageId = $this->params()->fromRoute('landing_id');
        $landingPageUrl = $this->params()->fromRoute('landing_url');
        
        $landingPageMapper = $this->getServiceLocator()->get('landing_page_mapper');
        $landingPage = $landingPageMapper->findById($landingPageId);
        
        if (!$landingPage || $landingPageUrl != $landingPage->getUrl())
            return $this->notFoundAction();
        
        $this->layout('layout/dynamic-landing');
        
        $request = $this->getRequest();
        $landingForm = $this->getServiceLocator()->get('dynamic_landing_page_form');
        
        
        $valueOptions = true;
        
        if (!$landingPage->getVitreTactile()) {
            $valueOptions = $landingForm->get('repair')->getValueOptions();
            unset($valueOptions['Vitre tactile']);
            $landingForm->get('repair')->setValueOptions($valueOptions);
        }
        
        if (!$landingPage->getEcranLcd()) {
            $valueOptions = $landingForm->get('repair')->getValueOptions();
            unset($valueOptions['Écran LCD']);
            $landingForm->get('repair')->setValueOptions($valueOptions);
        }
        
        if (!$landingPage->getBoutonHome()) {
            $valueOptions = $landingForm->get('repair')->getValueOptions();
            unset($valueOptions['Bouton home']);
            $landingForm->get('repair')->setValueOptions($valueOptions);
        }

        if (!$landingPage->getAppareilPhotoAvant()) {
            $valueOptions = $landingForm->get('repair')->getValueOptions();
            unset($valueOptions['Appareil photo avant']);
            $landingForm->get('repair')->setValueOptions($valueOptions);
        }
        
        
        
        if (!$landingPage->getAppareilPhoto()) {
            $valueOptions = $landingForm->get('repair')->getValueOptions();
            unset($valueOptions['Appareil photo']);
            $landingForm->get('repair')->setValueOptions($valueOptions);
        }
        
        if (!$landingPage->getFacadeArriere()) {
            $valueOptions = $landingForm->get('repair')->getValueOptions();
            unset($valueOptions['Façade arrière']);
            $landingForm->get('repair')->setValueOptions($valueOptions);
        }
        
        if (!$landingPage->getVitreArriere()) {
            $valueOptions = $landingForm->get('repair')->getValueOptions();
            unset($valueOptions['Vitre arrière']);
            $landingForm->get('repair')->setValueOptions($valueOptions);
        }
        
        if (!$landingPage->getBatterie()) {
            $valueOptions = $landingForm->get('repair')->getValueOptions();
            unset($valueOptions['Batterie']);
            $landingForm->get('repair')->setValueOptions($valueOptions);
        }
        
        if (!$landingPage->getConnecteurCharge()) {
            $valueOptions = $landingForm->get('repair')->getValueOptions();
            unset($valueOptions['Connecteur de charge']);
            $landingForm->get('repair')->setValueOptions($valueOptions);
        }
        
        if (!$landingPage->getPriseCasque()) {
            $valueOptions = $landingForm->get('repair')->getValueOptions();
            unset($valueOptions['Prise casque']);
            $landingForm->get('repair')->setValueOptions($valueOptions);
        }
        
        if (!$landingPage->getBoutonOnOff()) {
            $valueOptions = $landingForm->get('repair')->getValueOptions();
            unset($valueOptions['Bouton On-Off']);
            $landingForm->get('repair')->setValueOptions($valueOptions);
        }
        
        if (!$landingPage->getVibreur()) {
            $valueOptions = $landingForm->get('repair')->getValueOptions();
            unset($valueOptions['Vibreur']);
            $landingForm->get('repair')->setValueOptions($valueOptions);
        }
        
        if (!$landingPage->getMicro()) {
            $valueOptions = $landingForm->get('repair')->getValueOptions();
            unset($valueOptions['Micro']);
            $landingForm->get('repair')->setValueOptions($valueOptions);
        }
        
        if (!$landingPage->getHautParleur()) {
            $valueOptions = $landingForm->get('repair')->getValueOptions();
            unset($valueOptions['Haut parleur']);
            $landingForm->get('repair')->setValueOptions($valueOptions);
        }
        
        if (!$landingPage->getEcouteurInterne()) {
            $valueOptions = $landingForm->get('repair')->getValueOptions();
            unset($valueOptions['Écouteur interne']);
            $landingForm->get('repair')->setValueOptions($valueOptions);
        }
        
        if (!$landingPage->getAntenne()) {
            $valueOptions = $landingForm->get('repair')->getValueOptions();
            unset($valueOptions['Antenne']);
            $landingForm->get('repair')->setValueOptions($valueOptions);
        }
        
        if (!$landingPage->getWifi()) {
            $valueOptions = $landingForm->get('repair')->getValueOptions();
            unset($valueOptions['Wifi']);
            $landingForm->get('repair')->setValueOptions($valueOptions);
        }
        
        if (!$landingPage->getHublotAppareilPhoto()) {
            $valueOptions = $landingForm->get('repair')->getValueOptions();
            unset($valueOptions['Hublot appareil photo']);
            $landingForm->get('repair')->setValueOptions($valueOptions);
        }
        
        if (!$landingPage->getBoutonsVolume()) {
            $valueOptions = $landingForm->get('repair')->getValueOptions();
            unset($valueOptions['Boutons volume']);
            $landingForm->get('repair')->setValueOptions($valueOptions);
        }
        
        
        if (!$landingPage->getAutre()) {
            $valueOptions = $landingForm->get('repair')->getValueOptions();
            unset($valueOptions['Autre']);
            $landingForm->get('repair')->setValueOptions($valueOptions);
        }

        if (!$valueOptions) {
            $landingForm->remove('repair');
        }



        $displayPopup = false;

        if ($request->isPost()) {
            $landingForm->setData($request->getPost());

            if ($landingForm->isValid()) {
                $mailer = $this->getServiceLocator()->get('mail_service');
                $message = $mailer->createHtmlMessage('contact@wefix.net', 'Landing WeFix', 'template/landing', array('data' => $landingForm->getData()));
                $message = $mailer->createHtmlMessage('serviceclients@wefix.net', 'Landing WeFix', 'template/landing', array('data' => $landingForm->getData()));
                $mailer->send($message);
                $displayPopup = true;
            }
        }

        return array('landingPage' => $landingPage, 'landingForm' => $landingForm, 'displayPopup' => $displayPopup);
    }
}
