<?php
namespace LandingPage\Form;

use Zend\Form\Form;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class IphoneForm extends Form implements InputFilterAwareInterface
{
    protected $inputFilter;

    public function __construct()
    {
        // we want to ignore the name passed
        parent::__construct('iphone');

        $this->setAttributes(array(
            'method' => 'post',
        ));

        $this->add(array(
            'name' => 'repair',
            'type'  => 'Zend\Form\Element\MultiCheckbox',
            'options' => array(
                'label' => 'Type de panne :',
                'value_options' => array(
                    'Vitre ou ecran' => 'Vitre ou Ecran',
                    'Boutons' => 'Boutons',
                    'Batterie' => 'Batterie',
                    'Son' => 'Son',
                    'Autres' => 'Autres',
                ),
            ),
        ));

        $this->add(array(
            'name' => 'nom',
            'type'  => 'Zend\Form\Element\Text',
            'options' => array(
                'label' => 'Nom :',
            ),
        ));

        $this->add(array(
            'name' => 'tel',
            'type'  => 'Zend\Form\Element\Text',
            'options' => array(
                'label' => 'Tel :',
            ),
        ));

        $this->add(array(
            'name'    => 'landingForm',
            'type'    => 'Zend\Form\Element\Submit',
            'attributes' => array(
                'value' => '',
            ),
        ));
    }

    public function getInputFilter()
    {
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();
            $factory     = new InputFactory();

            $inputFilter->add($factory->createInput(array(
                'name'     => 'repair',
                'required' => false,
            )));

        $inputFilter->add($factory->createInput(array(
                'name'     => 'nom',
                'filter' => array(
                    array('name' => 'HtmlEntities'),
                ),
                'required' => true,
            )));

            $inputFilter->add($factory->createInput(array(
                'name'     => 'tel',
                'filter' => array(
                    array('name' => 'HtmlEntities'),
                ),
                'required' => true,
            )));

            $this->inputFilter = $inputFilter;
        }

        return $this->inputFilter;
    }

    public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new \Exception("Not used");
    }
}
