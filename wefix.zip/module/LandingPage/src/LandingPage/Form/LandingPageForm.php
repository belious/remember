<?php

namespace LandingPage\Form;

use Zend\Form\Form;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class LandingPageForm extends Form implements InputFilterAwareInterface
{

    protected $inputFilter;

    public function __construct()
    {
        // we want to ignore the name passed
        parent::__construct('landing-page');

        $this->setAttributes(array(
            'method' => 'post',
        ));

        $this->add(array(
            'name' => 'id',
            'type' => 'Zend\Form\Element\Hidden',
            'attributes' => array(
                'value' => '0',
            ),
        ));

        $this->add(array(
            'name' => 'nom',
            'type' => 'Zend\Form\Element\Text',
            'options' => array(
                'label' => 'Nom',
            ),
        ));

        $this->add(array(
            'name' => 'url',
            'type' => 'Zend\Form\Element\Text',
            'options' => array(
                'label' => 'Url',
            ),
        ));

        $this->add(array(
            'name' => 'html1',
            'type' => 'Zend\Form\Element\Textarea',
            'options' => array(
                'label' => 'Contenu Top',
            ),
            'attributes' => array(
                'class' => 'htmlify',
                'style' => 'width:500px;height:200px;',
            ),
        ));

        $this->add(array(
            'name' => 'image',
            'type' => 'Zend\Form\Element\File',
            'options' => array(
                'label' => 'Image (600x345px) PNG',
            ),
        ));

        $this->add(array(
            'name' => 'sous_titre',
            'type' => 'Zend\Form\Element\Text',
            'options' => array(
                'label' => 'Contenu sous image',
            ),
        ));

        $this->add(array(
            'name' => 'vitre_tactile',
            'type' => 'Zend\Form\Element\Checkbox',
            'options' => array(
                'label' => 'Option réparation vitre tactile',
                'use_hidden_element' => true,
                'checked_value' => 'true',
                'unchecked_value' => 'false',
            ),
        ));

        $this->add(array(
            'name' => 'ecran_lcd',
            'type' => 'Zend\Form\Element\Checkbox',
            'options' => array(
                'label' => 'Option réparation écran lcd',
                'use_hidden_element' => true,
                'checked_value' => 'true',
                'unchecked_value' => 'false',
            ),
        ));

        $this->add(array(
            'name' => 'bouton_home',
            'type' => 'Zend\Form\Element\Checkbox',
            'options' => array(
                'label' => 'Option réparation bouton home',
                'use_hidden_element' => true,
                'checked_value' => 'true',
                'unchecked_value' => 'false',
            ),
        ));

        $this->add(array(
            'name' => 'appareil_photo_avant',
            'type' => 'Zend\Form\Element\Checkbox',
            'options' => array(
                'label' => 'Option réparation appareil photo avant',
                'use_hidden_element' => true,
                'checked_value' => 'true',
                'unchecked_value' => 'false',
            ),
        ));






        $this->add(array(
            'name' => 'vitre_arriere',
            'type' => 'Zend\Form\Element\Checkbox',
            'options' => array(
                'label' => 'Vitre arrière',
                'use_hidden_element' => true,
                'checked_value' => 'true',
                'unchecked_value' => 'false',
            ),
        ));

        $this->add(array(
            'name' => 'facade_arriere',
            'type' => 'Zend\Form\Element\Checkbox',
            'options' => array(
                'label' => 'Façade arrière',
                'use_hidden_element' => true,
                'checked_value' => 'true',
                'unchecked_value' => 'false',
            ),
        ));

        $this->add(array(
            'name' => 'appareil_photo',
            'type' => 'Zend\Form\Element\Checkbox',
            'options' => array(
                'label' => 'Appareil photo',
                'use_hidden_element' => true,
                'checked_value' => 'true',
                'unchecked_value' => 'false',
            ),
        ));

        $this->add(array(
            'name' => 'batterie',
            'type' => 'Zend\Form\Element\Checkbox',
            'options' => array(
                'label' => 'Batterie',
                'use_hidden_element' => true,
                'checked_value' => 'true',
                'unchecked_value' => 'false',
            ),
        ));

        $this->add(array(
            'name' => 'connecteur_charge',
            'type' => 'Zend\Form\Element\Checkbox',
            'options' => array(
                'label' => 'Connecteur de charge',
                'use_hidden_element' => true,
                'checked_value' => 'true',
                'unchecked_value' => 'false',
            ),
        ));

        $this->add(array(
            'name' => 'prise_casque',
            'type' => 'Zend\Form\Element\Checkbox',
            'options' => array(
                'label' => 'Prise casque',
                'use_hidden_element' => true,
                'checked_value' => 'true',
                'unchecked_value' => 'false',
            ),
        ));

        $this->add(array(
            'name' => 'bouton_on_off',
            'type' => 'Zend\Form\Element\Checkbox',
            'options' => array(
                'label' => 'Bouton On/Off',
                'use_hidden_element' => true,
                'checked_value' => 'true',
                'unchecked_value' => 'false',
            ),
        ));

        $this->add(array(
            'name' => 'vibreur',
            'type' => 'Zend\Form\Element\Checkbox',
            'options' => array(
                'label' => 'Vibreur',
                'use_hidden_element' => true,
                'checked_value' => 'true',
                'unchecked_value' => 'false',
            ),
        ));

        $this->add(array(
            'name' => 'micro',
            'type' => 'Zend\Form\Element\Checkbox',
            'options' => array(
                'label' => 'Micro',
                'use_hidden_element' => true,
                'checked_value' => 'true',
                'unchecked_value' => 'false',
            ),
        ));

        $this->add(array(
            'name' => 'haut_parleur',
            'type' => 'Zend\Form\Element\Checkbox',
            'options' => array(
                'label' => 'Haut parleur',
                'use_hidden_element' => true,
                'checked_value' => 'true',
                'unchecked_value' => 'false',
            ),
        ));

        $this->add(array(
            'name' => 'ecouteur_interne',
            'type' => 'Zend\Form\Element\Checkbox',
            'options' => array(
                'label' => 'Écouteur interne',
                'use_hidden_element' => true,
                'checked_value' => 'true',
                'unchecked_value' => 'false',
            ),
        ));

        $this->add(array(
            'name' => 'antenne',
            'type' => 'Zend\Form\Element\Checkbox',
            'options' => array(
                'label' => 'Antenne réseau',
                'use_hidden_element' => true,
                'checked_value' => 'true',
                'unchecked_value' => 'false',
            ),
        ));

        $this->add(array(
            'name' => 'wifi',
            'type' => 'Zend\Form\Element\Checkbox',
            'options' => array(
                'label' => 'Wifi',
                'use_hidden_element' => true,
                'checked_value' => 'true',
                'unchecked_value' => 'false',
            ),
        ));

        $this->add(array(
            'name' => 'boutons_volume',
            'type' => 'Zend\Form\Element\Checkbox',
            'options' => array(
                'label' => 'Boutons volume',
                'use_hidden_element' => true,
                'checked_value' => 'true',
                'unchecked_value' => 'false',
            ),
        ));


        $this->add(array(
            'name' => 'hublot_appareil_photo',
            'type' => 'Zend\Form\Element\Checkbox',
            'options' => array(
                'label' => 'Hublot appareil photo',
                'use_hidden_element' => true,
                'checked_value' => 'true',
                'unchecked_value' => 'false',
            ),
        ));


        $this->add(array(
            'name' => 'autre',
            'type' => 'Zend\Form\Element\Checkbox',
            'options' => array(
                'label' => 'Option réparation autre',
                'use_hidden_element' => true,
                'checked_value' => 'true',
                'unchecked_value' => 'false',
            ),
        ));
    }

    public function getInputFilter()
    {
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();
            $factory = new InputFactory();

            $inputFilter->add($factory->createInput(array(
                        'name' => 'id',
                        'required' => true,
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'nom',
                        'required' => true,
                        'filters' => array(
                            array('name' => 'StringTrim'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'url',
                        'required' => true,
                        'filters' => array(
                            array('name' => 'StringTrim'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'html1',
                        'required' => true,
                        'filters' => array(
                            array('name' => 'StringTrim'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'image',
                        'required' => true,
                        'validators' => array(
                            array(
                                'name' => 'Zend\Validator\File\IsImage',
                                'options' => array(
                                    'image/png',
                                ),
                            ),
                            array(
                                'name' => 'Zend\Validator\File\UploadFile',
                            ),
                            array(
                                'name' => 'Zend\Validator\File\Size',
                                'options' => array(
                                    'max' => 500000,
                                ),
                            ),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'sous_titre',
                        'required' => true,
                        'filters' => array(
                            array('name' => 'StringTrim'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'vitre_tactile',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'Zend\Filter\Boolean', 'options' => array('type' => 'false')),
                        ),
                        'validators' => array(
                            array('name' => 'Application\Validator\Boolean'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'ecran_lcd',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'Zend\Filter\Boolean', 'options' => array('type' => 'false')),
                        ),
                        'validators' => array(
                            array('name' => 'Application\Validator\Boolean'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'bouton_home',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'Zend\Filter\Boolean', 'options' => array('type' => 'false')),
                        ),
                        'validators' => array(
                            array('name' => 'Application\Validator\Boolean'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'appareil_photo_avant',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'Zend\Filter\Boolean', 'options' => array('type' => 'false')),
                        ),
                        'validators' => array(
                            array('name' => 'Application\Validator\Boolean'),
                        ),
            )));





            $inputFilter->add($factory->createInput(array(
                        'name' => 'appareil_photo',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'Zend\Filter\Boolean', 'options' => array('type' => 'false')),
                        ),
                        'validators' => array(
                            array('name' => 'Application\Validator\Boolean'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'facade_arriere',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'Zend\Filter\Boolean', 'options' => array('type' => 'false')),
                        ),
                        'validators' => array(
                            array('name' => 'Application\Validator\Boolean'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'vitre_arriere',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'Zend\Filter\Boolean', 'options' => array('type' => 'false')),
                        ),
                        'validators' => array(
                            array('name' => 'Application\Validator\Boolean'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'batterie',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'Zend\Filter\Boolean', 'options' => array('type' => 'false')),
                        ),
                        'validators' => array(
                            array('name' => 'Application\Validator\Boolean'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'connecteur_charge',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'Zend\Filter\Boolean', 'options' => array('type' => 'false')),
                        ),
                        'validators' => array(
                            array('name' => 'Application\Validator\Boolean'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'prise_casque',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'Zend\Filter\Boolean', 'options' => array('type' => 'false')),
                        ),
                        'validators' => array(
                            array('name' => 'Application\Validator\Boolean'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'bouton_on_off',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'Zend\Filter\Boolean', 'options' => array('type' => 'false')),
                        ),
                        'validators' => array(
                            array('name' => 'Application\Validator\Boolean'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'vibreur',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'Zend\Filter\Boolean', 'options' => array('type' => 'false')),
                        ),
                        'validators' => array(
                            array('name' => 'Application\Validator\Boolean'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'micro',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'Zend\Filter\Boolean', 'options' => array('type' => 'false')),
                        ),
                        'validators' => array(
                            array('name' => 'Application\Validator\Boolean'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'haut_parleur',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'Zend\Filter\Boolean', 'options' => array('type' => 'false')),
                        ),
                        'validators' => array(
                            array('name' => 'Application\Validator\Boolean'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'ecouteur_interne',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'Zend\Filter\Boolean', 'options' => array('type' => 'false')),
                        ),
                        'validators' => array(
                            array('name' => 'Application\Validator\Boolean'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'antenne',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'Zend\Filter\Boolean', 'options' => array('type' => 'false')),
                        ),
                        'validators' => array(
                            array('name' => 'Application\Validator\Boolean'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'wifi',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'Zend\Filter\Boolean', 'options' => array('type' => 'false')),
                        ),
                        'validators' => array(
                            array('name' => 'Application\Validator\Boolean'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'boutons_volume',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'Zend\Filter\Boolean', 'options' => array('type' => 'false')),
                        ),
                        'validators' => array(
                            array('name' => 'Application\Validator\Boolean'),
                        ),
            )));

            $inputFilter->add($factory->createInput(array(
                        'name' => 'hublot_appareil_photo',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'Zend\Filter\Boolean', 'options' => array('type' => 'false')),
                        ),
                        'validators' => array(
                            array('name' => 'Application\Validator\Boolean'),
                        ),
            )));


            $inputFilter->add($factory->createInput(array(
                        'name' => 'autre',
                        'required' => false,
                        'filters' => array(
                            array('name' => 'Zend\Filter\Boolean', 'options' => array('type' => 'false')),
                        ),
                        'validators' => array(
                            array('name' => 'Application\Validator\Boolean'),
                        ),
            )));


            $this->inputFilter = $inputFilter;
        }

        return $this->inputFilter;
    }

    public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new \Exception("Not used");
    }

}
