<?php

namespace LandingPage\Entity;


class LandingPage
{
    protected $id;
    protected $nom;
    protected $url;
    protected $html1;
    protected $imageUrl;
    protected $sousTitre;
    protected $vitreTactile;
    protected $ecranLcd;
    protected $boutonHome;
    protected $appareilPhotoAvant;
    protected $vitreArriere;
    protected $facadeArriere;
    protected $appareilPhoto;
    protected $batterie;
    protected $connecteurCharge;
    protected $priseCasque;
    protected $boutonOnOff;
    protected $vibreur;
    protected $micro;
    protected $hautParleur;
    protected $ecouteurInterne;
    protected $antenne;
    protected $wifi;
    protected $boutonsVolume;
    protected $hublotAppareilPhoto;
    protected $autre;
    
    public function getFacadeArriere()
    {
        return $this->facadeArriere;
    }

    public function setFacadeArriere($facadeArriere)
    {
        $this->facadeArriere = $facadeArriere;
        return $this;
    }

    public function getBoutonsVolume()
    {
        return $this->boutonsVolume;
    }

    public function getHublotAppareilPhoto()
    {
        return $this->hublotAppareilPhoto;
    }

    public function setBoutonsVolume($boutonsVolume)
    {
        $this->boutonsVolume = $boutonsVolume;
        return $this;
    }

    public function setHublotAppareilPhoto($hublotAppareilPhoto)
    {
        $this->hublotAppareilPhoto = $hublotAppareilPhoto;
        return $this;
    }
        
    public function getUrl()
    {
        return $this->url;
    }

    public function setUrl($url)
    {
        $this->url = $url;
        return $this;
    }
    
    public function getVitreArriere()
    {
        return $this->vitreArriere;
    }

    public function getAppareilPhoto()
    {
        return $this->appareilPhoto;
    }

    public function getBatterie()
    {
        return $this->batterie;
    }

    public function getConnecteurCharge()
    {
        return $this->connecteurCharge;
    }

    public function getPriseCasque()
    {
        return $this->priseCasque;
    }

    public function getBoutonOnOff()
    {
        return $this->boutonOnOff;
    }

    public function getVibreur()
    {
        return $this->vibreur;
    }

    public function getMicro()
    {
        return $this->micro;
    }

    public function getHautParleur()
    {
        return $this->hautParleur;
    }

    public function getEcouteurInterne()
    {
        return $this->ecouteurInterne;
    }

    public function getAntenne()
    {
        return $this->antenne;
    }

    public function getWifi()
    {
        return $this->wifi;
    }

    public function setVitreArriere($vitreArriere)
    {
        $this->vitreArriere = $vitreArriere;
        return $this;
    }

    public function setAppareilPhoto($appareilPhoto)
    {
        $this->appareilPhoto = $appareilPhoto;
        return $this;
    }

    public function setBatterie($batterie)
    {
        $this->batterie = $batterie;
        return $this;
    }

    public function setConnecteurCharge($connecteurCharge)
    {
        $this->connecteurCharge = $connecteurCharge;
        return $this;
    }

    public function setPriseCasque($priseCasque)
    {
        $this->priseCasque = $priseCasque;
        return $this;
    }

    public function setBoutonOnOff($boutonOnOff)
    {
        $this->boutonOnOff = $boutonOnOff;
        return $this;
    }

    public function setVibreur($vibreur)
    {
        $this->vibreur = $vibreur;
        return $this;
    }

    public function setMicro($micro)
    {
        $this->micro = $micro;
        return $this;
    }

    public function setHautParleur($hautParleur)
    {
        $this->hautParleur = $hautParleur;
        return $this;
    }

    public function setEcouteurInterne($ecouteurInterne)
    {
        $this->ecouteurInterne = $ecouteurInterne;
        return $this;
    }

    public function setAntenne($antenne)
    {
        $this->antenne = $antenne;
        return $this;
    }

    public function setWifi($wifi)
    {
        $this->wifi = $wifi;
        return $this;
    }

        
    public function getId()
    {
        return $this->id;
    }
    
    public function getNom()
    {
        return $this->nom;
    }

    public function getHtml1()
    {
        return $this->html1;
    }

    public function getImageUrl()
    {
        return $this->imageUrl;
    }

    public function getSousTitre()
    {
        return $this->sousTitre;
    }

    public function getVitreTactile()
    {
        return $this->vitreTactile;
    }

    public function getEcranLcd()
    {
        return $this->ecranLcd;
    }

    public function getBoutonHome()
    {
        return $this->boutonHome;
    }

    public function getAppareilPhotoAvant()
    {
        return $this->appareilPhotoAvant;
    }

    public function getAutre()
    {
        return $this->autre;
    }

    public function setId($id)
    {
        $this->id = $id;
        return $this;
    }
    
    public function setNom($nom)
    {
        $this->nom = $nom;
        return $this;
    }

    public function setHtml1($html1)
    {
        $this->html1 = $html1;
        return $this;
    }

    public function setImageUrl($imageUrl)
    {
        $this->imageUrl = $imageUrl;
        return $this;
    }

    public function setSousTitre($sousTitre)
    {
        $this->sousTitre = $sousTitre;
        return $this;
    }

    public function setVitreTactile($vitreTactile)
    {
        $this->vitreTactile = $vitreTactile;
        return $this;
    }

    public function setEcranLcd($ecranLcd)
    {
        $this->ecranLcd = $ecranLcd;
        return $this;
    }

    public function setBoutonHome($boutonHome)
    {
        $this->boutonHome = $boutonHome;
        return $this;
    }

    public function setAppareilPhotoAvant($appareilPhotoAvant)
    {
        $this->appareilPhotoAvant = $appareilPhotoAvant;
        return $this;
    }

    public function setAutre($autre)
    {
        $this->autre = $autre;
        return $this;
    }
}
