<?php

return array(
    'controllers' => array(
        'invokables' => array(
            'LandingPage' => 'LandingPage\Controller\LandingPageController',
        ),
    ),
    'router' => array(
        'routes' => array(
            'landingPageIphone2' => array(
                'type' => 'Literal',
                'options' => array(
                    'route' => '/reparation-iphone-2',
                    'defaults' => array(
                        'controller' => 'LandingPage',
                        'action' => 'iphone2',
                    ),
                ),
            ),
            'landingPage' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/reparation/:landing_id/:landing_url',
                    'defaults' => array(
                        'controller' => 'LandingPage',
                        'action' => 'dynamic',
                    ),
                    'constraints' => array(
                        'landing_id' => '[0-9]+',
                    ),
                ),
            ),
        ),
    ),
    'view_manager' => array(
        'template_path_stack' => array(
            __DIR__ . '/../view',
        ),
    ),
);
