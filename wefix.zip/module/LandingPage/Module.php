<?php

namespace LandingPage;

use Zend\Stdlib\Hydrator\ClassMethods;

class Module
{

    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }

    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
                ),
            ),
        );
    }

    public function getServiceConfig()
    {
        return array(
            'invokables' => array(
                'landing_iphone_form' => 'LandingPage\Form\IphoneForm',
                'dynamic_landing_page_form' => 'LandingPage\Form\DynamicLandingPageForm',
                'landing_page_form' => 'LandingPage\Form\LandingPageForm',
            ),
            'factories' => array(
                'landing_page_mapper' => function ($sm) {
                    $mapper = new Mapper\LandingPage();
                    $mapper->setDbAdapter($sm->get('Zend\Db\Adapter\Adapter'));
                    $mapper->setEntityPrototype(new Entity\LandingPage());
                    $mapper->setHydrator(new ClassMethods());

                    return $mapper;
                },
            ),
        );
    }

}
