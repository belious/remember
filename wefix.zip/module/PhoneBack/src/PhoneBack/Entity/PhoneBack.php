<?php

namespace PhoneBack\Entity;

class PhoneBack implements PhoneBackInterface
{
    protected $id;
    protected $phone;
    protected $dateCreated;
    protected $state;

    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    public function getId()
    {
        return $this->id;
    }

    public function setPhone($phone)
    {
        $this->phone = $phone;

        return $this;
    }

    public function getPhone()
    {
        return $this->phone;
    }

    public function setDateCreated($date)
    {
        $this->dateCreated = $date;

        return $this;
    }

    public function getDateCreated()
    {
        return $this->dateCreated;
    }

    public function setState($state)
    {
        $this->state = $state;

        return $this;
    }

    public function getState()
    {
        return $this->state;
    }
}
