<?php

namespace PhoneBack\Entity;

interface PhoneBackInterface
{
    public function setId($id);
    public function getId();
    public function setPhone($phone);
    public function getPhone();
    public function setDateCreated($date);
    public function getDateCreated();
    public function setState($state);
    public function getState();
}
