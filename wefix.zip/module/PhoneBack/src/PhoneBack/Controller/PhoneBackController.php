<?php

namespace PhoneBack\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use PhoneBack\Entity\PhoneBack;

class PhoneBackController extends AbstractActionController
{
    public function createAction() {
        $request = $this->getRequest();
        if ($request->getPost()->get("phone")) {
            $phoneBack = new PhoneBack();
            $phoneBack->setPhone($request->getPost()->get("phone"));
            $phoneBack->setState(1);
            $phoneBackMapper = $this->getServiceLocator()->get('phone_back_mapper');
            $phoneBackMapper->insert($phoneBack);

            mail('serviceclients@wefix.net', 'A rapeler', $phoneBack->getPhone());
        }
        $viewModel = new ViewModel();
        $viewModel->setTerminal(true);

        return $viewModel;
    }
}
