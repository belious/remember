<?php

namespace PhoneBack;

use Zend\Mvc\MvcEvent;
use Zend\Stdlib\Hydrator\ClassMethods;
use Zend\Http\Request as HttpRequest;
use Zend\View\Model\ViewModel;

class Module
{

    public function onBootstrap(MvcEvent $e)
    {
        $request = $e->getRequest();
        $eventManager = $e->getApplication()->getEventManager();

        // We check if the request is http. If it's not just, functions aren't launched
        if ($request instanceof HttpRequest) {
            $eventManager->attach(MvcEvent::EVENT_RENDER, array($this, 'attachCallBox'));
        }
    }

    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }

    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
                ),
            ),
        );
    }

    public function getServiceConfig()
    {
        return array(
            'factories' => array(
                'phone_back_mapper' => function ($sm) {
                    $mapper = new Mapper\PhoneBack();
                    $mapper->setDbAdapter($sm->get('Zend\Db\Adapter\Adapter'));
                    $mapper->setEntityPrototype(new Entity\PhoneBack());
                    $mapper->setHydrator(new ClassMethods());

                    return $mapper;
                },
            ),
        );
    }

    public function attachCallBox(MvcEvent $e)
    {
        $layout = $e->getViewModel();

        $callBoxView = new ViewModel();
        $callBoxView->setTemplate('phone-back/call-box');

        $layout->addChild($callBoxView, 'absoluteRightBar');
    }

}
