<?php

return array(
    'controllers' => array(
        'invokables' => array(
            'PhoneBack' => 'PhoneBack\Controller\PhoneBackController',
        ),
    ),
    'router' => array(
        'routes' => array(
            'phoneBack' => array(
                'type' => 'Literal',
                'options' => array(
                    'route' => '/phone-back',
                    'defaults' => array(
                        'controller' => 'PhoneBack',
                        'action' => 'create',
                    ),
                ),
            ),
        ),
    ),
    'view_manager' => array(
        'template_path_stack' => array(
            __DIR__ . '/../view',
        ),
    ),
);
