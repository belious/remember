<?php

return array(
    'modules' => array(
        'Basic',
        'StaticManager',
        'Mail',
        'Application',
        'Admin',
        'UniqueEntry',
        'PhoneBack',
        'LandingPage',
        'AstraZeneca',
        'TwbBundle'
    ),
    'module_listener_options' => array(
        'config_glob_paths' => array(
            'config/autoload/{,*.}{global,local}.php',
        ),
        'config_cache_enabled' => !__DEVMODE__,
        'cache_dir' => './cache',
        'module_paths' => array(
            './module',
            './vendor',
        ),
    ),
);
