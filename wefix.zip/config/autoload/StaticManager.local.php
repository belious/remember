<?php

return array(
    'static_path' => __DIR__ . '/../../subdomain/resources',
    'static_url' => '/static',
);
